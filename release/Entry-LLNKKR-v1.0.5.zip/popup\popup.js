(() => {
  "use strict";

  const SETTINGS_KEY = "entryLlnkSettings";
  const defaults = {
    darkMode: false,
    draft: true,
    liveRefresh: true,
    spaceshipMotion: true,
    fallModeRestoreSpaceshipMotion: true,
    fallMode: false,
    autoMore: true,
    imageSpoiler: true,
    shortenProjectLinks: true,
  };

  const storageGet = (keys) => new Promise((resolve) => chrome.storage.local.get(keys, resolve));
  const storageSet = (values) => new Promise((resolve, reject) => {
    chrome.storage.local.set(values, () => {
      const error = chrome.runtime.lastError;
      if (error) reject(error);
      else resolve();
    });
  });

  function syncThemeButton(enabled) {
    const button = document.querySelector("#themeButton");
    button.setAttribute("aria-pressed", String(enabled));
    button.setAttribute("aria-label", enabled ? "다크모드 끄기" : "다크모드 켜기");
    button.querySelector("span").textContent = enabled ? "light_mode" : "dark_mode";
  }

  function normalizeSettings(value) {
    const settings = { ...defaults, ...(value || {}) };
    if (settings.fallMode) settings.spaceshipMotion = false;
    return settings;
  }

  function syncSettingInputs(settings) {
    document.querySelectorAll("[data-setting]").forEach((input) => {
      input.checked = Boolean(settings[input.dataset.setting]);
      const disabled = input.dataset.setting === "spaceshipMotion" && settings.fallMode === true;
      input.disabled = disabled;
      input.closest(".setting-row")?.classList.toggle("is-disabled", disabled);
    });
  }

  async function saveSetting(name, value) {
    const saved = await storageGet([SETTINGS_KEY]);
    const settings = normalizeSettings(saved[SETTINGS_KEY]);
    const wasFallModeEnabled = settings.fallMode === true;

    if (name === "fallMode") {
      if (value && !wasFallModeEnabled) {
        settings.fallModeRestoreSpaceshipMotion = settings.spaceshipMotion === true;
        settings.spaceshipMotion = false;
      } else if (!value && wasFallModeEnabled) {
        settings.spaceshipMotion = settings.fallModeRestoreSpaceshipMotion === true;
      }
    } else if (name === "spaceshipMotion") {
      settings.fallModeRestoreSpaceshipMotion = value;
    }

    settings[name] = value;
    await storageSet({ [SETTINGS_KEY]: settings });
    syncSettingInputs(settings);
    syncThemeButton(settings.darkMode);
  }

  async function initialize() {
    const saved = await storageGet([SETTINGS_KEY]);
    const settings = normalizeSettings(saved[SETTINGS_KEY]);
    syncSettingInputs(settings);
    document.querySelectorAll("[data-setting]").forEach((input) => {
      input.addEventListener("change", () => saveSetting(input.dataset.setting, input.checked).catch(() => {}));
    });
    syncThemeButton(settings.darkMode);
    document.querySelector("#version").textContent = `v${chrome.runtime.getManifest().version}`;
  }

  document.querySelector("#themeButton").addEventListener("click", () => {
    const input = document.querySelector('[data-setting="darkMode"]');
    input.checked = !input.checked;
    saveSetting("darkMode", input.checked);
  });
  initialize().catch(() => {});
})();
