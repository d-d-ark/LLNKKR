(() => {
  "use strict";

  const Ringcl = window.EntryLlnk;
  if (!Ringcl || window.__entryLlnkEntryStoryLoaded || window.self !== window.top) return;
  window.__entryLlnkEntryStoryLoaded = true;

  const { $, $$, text, debounce, isVisible, safeHttpUrl } = Ringcl;
  const POST_SELECTOR = "li.css-tasfte.eqmdslz0, li[class~='eqmdslz0']";
  const BODY_SELECTOR = ".css-6wq60h.eqt5hs60, [class~='eqt5hs60']";
  const LIST_SELECTOR = ".css-1i5jedo.e1lgujxn5, [class~='e1lgujxn5']";
  const METRIC_SELECTOR = "a.like, a.reply, [data-entry-chat-live-like='1'], [data-entry-chat-live-reply='1']";
  const WRITER_SELECTOR = "textarea#Write, textarea[name='Write']";
  const MAX_POST_LENGTH = 500;
  const MAX_LINE_BREAKS = 10;
  const LINE_BREAK_MARKER = " ".repeat(3);
  const DRAFT_STORAGE_KEY = "entryLlnkEntryStoryDraftPersistent";
  const DRAFT_SUBMIT_SESSION_KEY = "entryLlnkEntryStoryDraftSubmitPending";
  const LIVE_REPLY_PENDING_SESSION_KEY = "entryLlnkEntryStoryLiveReplyPending";
  const DRAFT_TTL_MS = 24 * 60 * 60 * 1000;
  const DRAFT_SAVE_DELAY_MS = 240;
  const DRAFT_GUARD_INTERVAL_MS = 300;
  const SUBMIT_CONFIRM_TIMEOUT_MS = 12000;
  const LIVE_REFRESH_MS = 5000;
  const DEFAULT_STORY_FILTERS = Object.freeze({
    projectLinks: true,
    entryLinks: false,
    externalLinks: false,
    naverShortLinks: false,
    allLinks: false,
    images: false,
    entryEmoticons: false,
    blockedWords: Object.freeze([]),
    blockedNicknames: Object.freeze([]),
  });
  const STORY_FILTER_OPTIONS = Object.freeze([
    { key: "allLinks", label: "모든 링크", depth: 0, children: ["entryLinks", "externalLinks"] },
    { key: "entryLinks", label: "엔트리 링크", depth: 1, parent: "allLinks", children: ["projectLinks"] },
    { key: "projectLinks", label: "엔트리 작품 링크", depth: 2, parent: "entryLinks" },
    { key: "externalLinks", label: "엔트리 외부 링크", depth: 1, parent: "allLinks", children: ["naverShortLinks"] },
    { key: "naverShortLinks", label: "네이버 단축 링크", depth: 2, parent: "externalLinks" },
    { key: "images", label: "이미지", depth: 0, startsSection: true },
    { key: "entryEmoticons", label: "엔트리 이모티콘", depth: 0 },
  ]);
  const DEFAULT_PAGE_SETTINGS = Object.freeze({
    darkMode: false,
    draft: true,
    liveRefresh: true,
    spaceshipMotion: true,
    fallModeRestoreSpaceshipMotion: true,
    fallMode: false,
    autoMore: true,
    imageSpoiler: true,
    shortenProjectLinks: true,
  });
  const CUSTOM_MODE_LAYOUT_VERSION = 7;
  const DEFAULT_CUSTOM_MODE_LAYOUT = Object.freeze({
    version: CUSTOM_MODE_LAYOUT_VERSION,
    first: null,
    second: null,
    third: null,
    fourth: null,
    objects: {
      composer: null,
      filter: null,
      settings: null,
      sort: null,
      period: null,
    },
    front: "first",
  });
  const CUSTOM_MODE_POST_GRID_COLUMNS = 24;
  const CUSTOM_MODE_POST_ROLES = Object.freeze(["first", "second", "third", "fourth"]);
  const CUSTOM_MODE_LAYOUT_SAMPLES = Object.freeze([
    { id: "mini", label: "미니" },
    { id: "columns", label: "2열" },
    { id: "staggered", label: "엇갈림" },
    { id: "wide", label: "와이드" },
    { id: "left", label: "왼쪽" },
    { id: "right", label: "오른쪽" },
  ]);
  const STORY_SETTING_OPTIONS = Object.freeze([
    { key: "darkMode", label: "다크모드", icon: "dark_mode" },
    { key: "draft", label: "작성 내용 자동 저장", icon: "edit_note" },
    { key: "liveRefresh", label: "실시간 새 글", icon: "dynamic_feed" },
    { key: "spaceshipMotion", label: "우주선 모션", icon: "rocket_launch" },
    { key: "fallMode", label: "커스텀 모드", icon: "dashboard_customize", beta: true },
    { key: "autoMore", label: "자동 더보기", icon: "expand_circle_down" },
    { key: "imageSpoiler", label: "이미지 스포일러", icon: "hide_image" },
    { key: "shortenProjectLinks", label: "작품 링크 줄이기", icon: "link" },
  ]);
  const STORY_FILTER_OPTION_MAP = new Map(STORY_FILTER_OPTIONS.map((option) => [option.key, option]));
  const STORY_BLOCK_RULE_TYPES = Object.freeze({
    words: { key: "blockedWords", label: "단어", placeholder: "차단할 단어" },
    nicknames: { key: "blockedNicknames", label: "닉네임", placeholder: "차단할 닉네임" },
  });
  const state = {
    observer: null,
    draftObserver: null,
    lazyObserver: null,
    liveTimer: 0,
    liveAbort: null,
    liveTopId: "",
    liveDedupeQueued: false,
    autoMoreAt: 0,
    autoMoreClicking: false,
    autoMoreCheckTimer: 0,
    autoMoreReleaseTimer: 0,
    autoMoreWatchTimer: 0,
    scrollRaf: 0,
    writerPreviewTimer: 0,
    draftPersistTimer: 0,
    draftGuardTimer: 0,
    draftGuardRunning: false,
    draftRestoreCleanup: null,
    draftValue: "",
    draftSavedAt: 0,
    draftPersistentLoaded: false,
    draftOwnerId: "",
    draftOwnerCheckedAt: 0,
    draftOwnerVerification: null,
    draftSubmitPendingUntil: 0,
    draftSubmittedValue: "",
    draftSubmittedAt: 0,
    draftFailureWatchTimer: 0,
    uploadCleanup: null,
    storyFilters: { ...DEFAULT_STORY_FILTERS, blockedWords: [], blockedNicknames: [] },
    pageSettings: { ...DEFAULT_PAGE_SETTINGS },
    storyFilterEventsBound: false,
    composeMenuEventsBound: false,
    storyNativeSortEventsBound: false,
    storyToolbarOpenPanel: "",
    storyFilterView: "main",
    storyBlockRuleType: "words",
    replyFoldEventsBound: false,
    autoMoreEnabled: true,
    liveRefreshEnabled: true,
    livePosts: [],
    spaceshipMotionEnabled: true,
    fallModeEnabled: false,
    fallModeRunTimer: 0,
    fallModeFrame: 0,
    fallModeCleanupTimer: 0,
    fallModeToken: 0,
    fallModeActive: false,
    fallModeInteractionCleanup: null,
    fallModeEntries: new Map(),
    customModeLayout: { ...DEFAULT_CUSTOM_MODE_LAYOUT },
    customModeDraftLayout: null,
    customModeEditing: false,
    customModeComposeRestoreOpen: null,
    customModePersistTimer: 0,
    customModeCanvas: null,
    customModeGridMetrics: null,
    customModeList: null,
    customModeListStyles: null,
    liveArrivalCleanups: new Set(),
    liveUpdateLayouts: new Map(),
    liveRowPositions: new Map(),
    nativeRemovalPending: false,
    nativeArrivalPending: 0,
    nativeArrivalSequence: 0,
    nativeArrivalExpiresAt: 0,
    nativeArrivalScrollAnchor: null,
    imageSpoilerEnabled: true,
    shortenProjectLinksEnabled: true,
    draftEnabled: true,
    blouplaFrames: new Map(),
    pollSelections: null,
  };
  const metricAnimationTimers = new WeakMap();

  const IMAGE_SHORT_LINK_BASE = "https://Llnk.kr/i";
  const IMAGE_SHORT_LINK_RE = /https:\/\/llnk\.kr\/(?:i[a-z0-9]{4}|i\.php\?c=[a-z0-9]{4})\b/i;
  const POLL_SHORT_LINK_RE = /https:\/\/llnk\.kr\/[vq][a-z0-9]{7}\b/i;
  const POLL_SELECTION_STORAGE_KEY = "entryLlnkPollSelections";

  function getExtensionUrl(path) {
    try {
      if (typeof chrome === "undefined" || !chrome.runtime?.id) return "";
      return chrome.runtime.getURL(path);
    } catch {
      return "";
    }
  }

  function isEntryStoryPage() {
    return /^\/community\/entrystory(?:\/|$)/.test(location.pathname)
      || /^\/profile\/[a-f0-9]{24}\/community\/entrystory(?:\/|$)/i.test(location.pathname);
  }

  function isEntryStoryListPage() {
    return /^\/community\/entrystory(?:\/|$)/.test(location.pathname);
  }

  function isLiveEntryStoryPage() {
    if (location.pathname !== "/community/entrystory/list") return false;
    const params = new URLSearchParams(location.search);
    if (params.getAll("sort").length !== 1 || params.getAll("term").length !== 1) return false;
    const keys = [...params.keys()];
    return keys.length === 2
      && keys.every((key) => key === "sort" || key === "term")
      && params.get("sort") === "created"
      && params.get("term") === "all";
  }

  function isFallModePage() {
    return isEntryStoryListPage();
  }

  function fallModeAllowed() {
    return state.fallModeEnabled
      && isFallModePage();
  }

  function spaceshipMotionAllowed() {
    return state.spaceshipMotionEnabled && !state.fallModeEnabled;
  }

  function normalizeCustomModeAnchor(value, { includeWidth = false } = {}) {
    if (!value || typeof value !== "object") return null;
    const x = Number(value.x);
    const y = Number(value.y);
    if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
    const anchor = {
      x: Math.max(0, Math.min(240, Math.round(x))),
      y: Math.max(0, Math.min(480, Math.round(y))),
    };
    if (includeWidth) {
      const width = Number(value.w);
      anchor.w = Number.isFinite(width)
        ? Math.max(8, Math.min(96, Math.round(width)))
        : CUSTOM_MODE_POST_GRID_COLUMNS;
    }
    return anchor;
  }

  function normalizeCustomModeLayout(value) {
    const candidate = value && typeof value === "object" && !Array.isArray(value) ? value : {};
    const candidateVersion = Number(candidate.version);
    const layout = candidateVersion === CUSTOM_MODE_LAYOUT_VERSION || candidateVersion === 6 ? candidate : {};
    return {
      version: CUSTOM_MODE_LAYOUT_VERSION,
      first: normalizeCustomModeAnchor(layout.first, { includeWidth: true }),
      second: normalizeCustomModeAnchor(layout.second, { includeWidth: true }),
      third: normalizeCustomModeAnchor(layout.third, { includeWidth: true }),
      fourth: normalizeCustomModeAnchor(layout.fourth, { includeWidth: true }),
      objects: {
        composer: normalizeCustomModeAnchor(layout.objects?.composer),
        filter: normalizeCustomModeAnchor(layout.objects?.filter),
        settings: normalizeCustomModeAnchor(layout.objects?.settings),
        sort: normalizeCustomModeAnchor(layout.objects?.sort),
        period: normalizeCustomModeAnchor(layout.objects?.period),
      },
      front: [...CUSTOM_MODE_POST_ROLES, "composer", "filter", "settings", "sort", "period"].includes(layout.front)
        ? layout.front
        : "first",
    };
  }

  function cloneCustomModeLayout(value = state.customModeLayout) {
    const layout = normalizeCustomModeLayout(value);
    return {
      ...layout,
      first: layout.first ? { ...layout.first } : null,
      second: layout.second ? { ...layout.second } : null,
      third: layout.third ? { ...layout.third } : null,
      fourth: layout.fourth ? { ...layout.fourth } : null,
      objects: Object.fromEntries(
        Object.entries(layout.objects).map(([key, anchor]) => [key, anchor ? { ...anchor } : null])
      ),
    };
  }

  function getActiveCustomModeLayout() {
    return state.customModeEditing
      ? normalizeCustomModeLayout(state.customModeDraftLayout)
      : normalizeCustomModeLayout(state.customModeLayout);
  }

  function hasSavedCustomModeLayout(layout = state.customModeLayout) {
    const normalized = normalizeCustomModeLayout(layout);
    return Boolean(normalized.first && normalized.second);
  }

  function getCustomModeRows(list = getList()) {
    return getLiveRows(list).filter((row) => isVisible(row) && !isStoryPostFiltered(row));
  }

  function getCustomModeCanvas() {
    return document.body;
  }

  function getStorySortToolbarContainer() {
    return $$('[class~="e1lgujxn8"]')
      .find((element) => isVisible(element)
        && !element.closest(".entry-chat-root")
        && $$(':scope > [class~="elhpwdj0"]', element).some((wrapper) => isVisible(wrapper)));
  }

  function getCustomModeObjectSources() {
    const composer = $(".entry-chat-compose-shell");
    const filter = $("[data-entry-llnk-link-filter='1']");
    const settings = $("[data-entry-llnk-story-settings='1']");
    const toolbar = getStorySortToolbarContainer() || filter?.parentElement || settings?.parentElement;
    const nativeButtons = toolbar
      ? $$(':scope > [class~="elhpwdj0"]', toolbar).filter((element) => isVisible(element)).slice(0, 2)
      : [];
    return [
      { key: "composer", source: composer },
      { key: "filter", source: filter },
      { key: "settings", source: settings },
      { key: "sort", source: nativeButtons[0] },
      { key: "period", source: nativeButtons[1] },
    ].filter(({ source }) => source instanceof HTMLElement && source.isConnected);
  }

  function getCustomModeWorkspaceTop(list = getList(), objects = getCustomModeObjectSources()) {
    const candidates = [list, ...objects.map(({ source }) => source)]
      .filter((source) => source instanceof HTMLElement && source.isConnected)
      .map((source) => state.fallModeEntries.get(source)?.naturalY ?? source.getBoundingClientRect().top + window.scrollY)
      .filter(Number.isFinite);
    return Math.max(0, Math.floor(candidates.length ? Math.min(...candidates) : window.scrollY));
  }

  function getCustomModeGridMetrics(list = getList(), rows = getCustomModeRows(list), objects = getCustomModeObjectSources()) {
    const firstRect = rows[0]?.getBoundingClientRect();
    const firstEntry = rows[0] ? state.fallModeEntries.get(rows[0]) : null;
    const baseWidth = Math.max(240, Math.round(firstEntry?.baseWidth || firstRect?.width || list?.getBoundingClientRect().width || 720));
    const cellX = Math.max(12, baseWidth / CUSTOM_MODE_POST_GRID_COLUMNS);
    const viewportWidth = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
    const top = getCustomModeWorkspaceTop(list, objects);
    return {
      left: 0,
      top,
      width: viewportWidth,
      cellX,
      cellY: cellX,
      columns: Math.max(CUSTOM_MODE_POST_GRID_COLUMNS, Math.floor(viewportWidth / cellX)),
    };
  }

  function customModeAnchorFromPosition(position, metrics) {
    return {
      x: Math.round(position.x / metrics.cellX),
      y: Math.round(position.y / metrics.cellY),
    };
  }

  function customModePositionFromAnchor(anchor, metrics) {
    return {
      x: Math.round(anchor.x * metrics.cellX),
      y: Math.round(anchor.y * metrics.cellY),
    };
  }

  function ensureCustomModeEntry(source) {
    let entry = state.fallModeEntries.get(source);
    if (entry) return entry;
    const rect = source.getBoundingClientRect();
    entry = {
      originalPosition: source.style.position,
      originalTranslate: source.style.translate,
      originalScale: source.style.scale,
      originalZIndex: source.style.zIndex,
      originalTransformOrigin: source.style.transformOrigin,
      originalWidth: source.style.width,
      originalMaxWidth: source.style.maxWidth,
      baseWidth: Math.max(1, Math.round(rect.width)),
      naturalX: Math.round(rect.left + window.scrollX),
      naturalY: Math.round(rect.top + window.scrollY),
      x: 0,
      y: 0,
    };
    state.fallModeEntries.set(source, entry);
    return entry;
  }

  function restoreCustomModeSource(source, entry) {
    if (!(source instanceof HTMLElement) || !entry) return;
    source.style.position = entry.originalPosition;
    source.style.translate = entry.originalTranslate;
    source.style.scale = entry.originalScale;
    source.style.zIndex = entry.originalZIndex;
    source.style.transformOrigin = entry.originalTransformOrigin;
    source.style.width = entry.originalWidth;
    source.style.maxWidth = entry.originalMaxWidth;
    source.removeAttribute("data-entry-llnk-custom-source");
    source.removeAttribute("data-entry-llnk-custom-role");
    source.removeAttribute("data-entry-llnk-custom-object");
    source.removeAttribute("data-entry-llnk-custom-version");
    $("[data-entry-llnk-custom-interaction-shield='1']", source)?.remove();
    $("[data-entry-llnk-custom-number='1']", source)?.remove();
    source.classList.remove("entry-llnk-custom-draggable", "entry-llnk-custom-dragging", "entry-llnk-custom-resizing", "entry-llnk-custom-front", "entry-llnk-custom-settling");
  }

  function saveCustomModeLayout() {
    window.clearTimeout(state.customModePersistTimer);
    state.customModePersistTimer = window.setTimeout(async () => {
      state.customModePersistTimer = 0;
      const saved = await Ringcl.storageGet(["entryLlnkSettings"]).catch(() => ({}));
      await Ringcl.storageSet({
        entryLlnkSettings: {
          ...(saved.entryLlnkSettings || {}),
          customModeLayout: state.customModeLayout,
        },
      }).catch(() => {});
    }, 80);
  }

  function removeCustomModeControls() {
    $$('[data-entry-llnk-custom-controls="1"], [data-entry-llnk-custom-drag-handle="1"], [data-entry-llnk-custom-resize="1"], [data-entry-llnk-custom-interaction-shield="1"], [data-entry-llnk-custom-edit-actions="1"], [data-entry-llnk-custom-number="1"]').forEach((controls) => controls.remove());
  }

  function clearStaleCustomModeSources() {
    $$('[data-entry-llnk-custom-source="1"]').forEach((source) => {
      if (source.dataset.entryLlnkCustomVersion === String(CUSTOM_MODE_LAYOUT_VERSION)) return;
      source.style.position = "";
      source.style.translate = "";
      source.style.scale = "";
      source.style.zIndex = "";
      source.style.transformOrigin = "";
      source.style.width = "";
      source.style.maxWidth = "";
      source.removeAttribute("data-entry-llnk-custom-source");
      source.removeAttribute("data-entry-llnk-custom-role");
      source.removeAttribute("data-entry-llnk-custom-object");
      source.removeAttribute("data-entry-llnk-custom-version");
      source.classList.remove("entry-llnk-custom-draggable", "entry-llnk-custom-dragging", "entry-llnk-custom-resizing", "entry-llnk-custom-front", "entry-llnk-custom-settling");
    });
    $$('[data-entry-llnk-custom-controls="1"], [data-entry-llnk-custom-drag-handle="1"], [data-entry-llnk-custom-resize="1"], [data-entry-llnk-custom-interaction-shield="1"], [data-entry-llnk-custom-edit-actions="1"], [data-entry-llnk-custom-grid="1"], [data-entry-llnk-custom-number="1"]').forEach((node) => node.remove());
  }

  function ensureCustomModeCanvas(metrics) {
    let grid = $("[data-entry-llnk-custom-grid='1']", document.body);
    if (!grid) {
      grid = document.createElement("span");
      grid.className = "entry-llnk-custom-grid";
      grid.dataset.entryLlnkCustomGrid = "1";
      grid.setAttribute("aria-hidden", "true");
      document.body.appendChild(grid);
    }
    const height = Math.max(
      window.innerHeight,
      document.documentElement.scrollHeight - metrics.top,
      document.body.scrollHeight - metrics.top
    );
    grid.style.left = `${metrics.left}px`;
    grid.style.top = `${metrics.top}px`;
    grid.style.width = `${metrics.width}px`;
    grid.style.height = `${Math.ceil(height)}px`;
    grid.style.setProperty("--entry-llnk-custom-grid-cell-x", `${metrics.cellX}px`);
    grid.style.setProperty("--entry-llnk-custom-grid-cell-y", `${metrics.cellY}px`);
    state.customModeCanvas = document.body;
    state.customModeGridMetrics = metrics;
    return grid;
  }

  function removeCustomModeCanvas() {
    $("[data-entry-llnk-custom-grid='1']", document.body)?.remove();
    state.customModeCanvas = null;
    state.customModeGridMetrics = null;
  }

  function captureCustomModeListStyles(list) {
    if (!(list instanceof HTMLElement)) return null;
    return ["position", "height", "min-height", "overflow-anchor"].map((property) => ({
      property,
      value: list.style.getPropertyValue(property),
      priority: list.style.getPropertyPriority(property),
    }));
  }

  function restoreCustomModeListStyles() {
    const list = state.customModeList;
    if (!(list instanceof HTMLElement) || !Array.isArray(state.customModeListStyles)) return;
    state.customModeListStyles.forEach(({ property, value, priority }) => {
      if (value) list.style.setProperty(property, value, priority);
      else list.style.removeProperty(property);
    });
  }

  function removeFallModeStage({ preserveEditing = false } = {}) {
    state.fallModeToken += 1;
    window.clearTimeout(state.fallModeRunTimer);
    window.clearTimeout(state.fallModeCleanupTimer);
    if (state.fallModeFrame) window.cancelAnimationFrame(state.fallModeFrame);
    state.fallModeInteractionCleanup?.();
    state.fallModeInteractionCleanup = null;
    state.fallModeRunTimer = 0;
    state.fallModeCleanupTimer = 0;
    state.fallModeFrame = 0;
    state.fallModeActive = false;
    state.fallModeEntries.forEach((entry, source) => {
      restoreCustomModeSource(source, entry);
    });
    state.fallModeEntries.clear();
    restoreCustomModeListStyles();
    state.customModeList = null;
    state.customModeListStyles = null;
    removeCustomModeControls();
    removeCustomModeCanvas();
    document.documentElement.classList.remove("entry-llnk-custom-mode-active", "entry-llnk-custom-mode-editing");
    const scrollTopButton = $(".entry-chat-entry-story-scroll-top[data-entry-llnk-owned='1']");
    scrollTopButton?.style.removeProperty("left");
    window.requestAnimationFrame(updateScrollUi);
    if (!preserveEditing) {
      releaseCustomModeComposeMenu();
      state.customModeEditing = false;
      state.customModeDraftLayout = null;
    }
  }

  function measureCustomModeSources(sources) {
    return sources.map((source) => {
      const entry = ensureCustomModeEntry(source);
      const rect = source.getBoundingClientRect();
      entry.naturalX = Math.round(rect.left + window.scrollX - entry.x);
      entry.naturalY = Math.round(rect.top + window.scrollY - entry.y);
      return {
        source,
        entry,
        x: entry.naturalX,
        y: entry.naturalY,
        width: Math.max(1, Math.round(rect.width)),
        height: Math.max(1, Math.round(rect.height)),
      };
    });
  }

  function getCustomModeGridPresets() {
    return [
      { columns: 1, rows: 1, label: "1 x 1" },
      { columns: 2, rows: 2, label: "2 x 2" },
      { columns: 3, rows: 2, label: "3 x 2" },
      { columns: 3, rows: 3, label: "3 x 3" },
    ];
  }

  function ensureCustomModeObjectHandle(source, key) {
    if (!(source instanceof HTMLElement)) return;
    let handle = $("[data-entry-llnk-custom-drag-handle='1']", source);
    if (!handle) {
      handle = document.createElement("span");
      handle.className = `entry-llnk-custom-drag-handle entry-llnk-custom-drag-handle-${key}`;
      handle.dataset.entryLlnkCustomDragHandle = "1";
      handle.setAttribute("aria-hidden", "true");
      handle.title = "\uc774\ub3d9";
      handle.innerHTML = '<span class="material-symbols-outlined" aria-hidden="true">drag_indicator</span>';
      source.appendChild(handle);
    }
  }

  function ensureCustomModeInteractionShield(source) {
    if (!(source instanceof HTMLElement)) return;
    let shield = $("[data-entry-llnk-custom-interaction-shield='1']", source);
    if (shield) return;
    shield = document.createElement("span");
    shield.className = "entry-llnk-custom-interaction-shield";
    shield.dataset.entryLlnkCustomInteractionShield = "1";
    shield.setAttribute("aria-hidden", "true");
    source.appendChild(shield);
  }

  function forceCustomModeComposeMenuOpen() {
    if (!state.customModeEditing) return;
    const menu = $("[data-entry-chat-compose-more='1']");
    if (!menu) return;
    if (state.customModeComposeRestoreOpen === null) {
      state.customModeComposeRestoreOpen = menu.classList.contains("is-open");
    }
    if (!menu.classList.contains("is-open")) openComposeMoreMenu(menu);
  }

  function releaseCustomModeComposeMenu() {
    const restoreOpen = state.customModeComposeRestoreOpen;
    state.customModeComposeRestoreOpen = null;
    const menu = $("[data-entry-chat-compose-more='1']");
    if (restoreOpen === false && menu?.classList.contains("is-open")) closeComposeMoreMenu(menu, false);
  }

  function ensureCustomModeControls(first) {
    if (!(first instanceof HTMLElement)) return;
    $$("[data-entry-llnk-custom-controls='1']").forEach((controls) => {
      if (!first.contains(controls)) controls.remove();
    });
    let controls = $("[data-entry-llnk-custom-controls='1']", first);
    if (controls) return;
    controls = document.createElement("span");
    controls.className = "entry-llnk-custom-controls";
    controls.dataset.entryLlnkCustomControls = "1";

    const gridButton = document.createElement("button");
    gridButton.type = "button";
    gridButton.className = "entry-llnk-custom-control";
    gridButton.setAttribute("aria-label", "게시글 배열");
    gridButton.title = "게시글 배열";
    gridButton.innerHTML = '<span class="material-symbols-outlined" aria-hidden="true">grid_view</span>';

    const sizeButton = document.createElement("button");
    sizeButton.type = "button";
    sizeButton.className = "entry-llnk-custom-control";
    sizeButton.setAttribute("aria-label", "게시글 크기");
    sizeButton.title = "게시글 크기";
    sizeButton.innerHTML = '<span class="material-symbols-outlined" aria-hidden="true">aspect_ratio</span>';

    const gridPanel = document.createElement("span");
    gridPanel.className = "entry-llnk-custom-grid-panel";
    gridPanel.hidden = true;
    getCustomModeGridPresets().forEach((preset) => {
      const choice = document.createElement("button");
      choice.type = "button";
      choice.className = "entry-llnk-custom-grid-choice";
      choice.textContent = preset.label;
      choice.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        state.customModeLayout = {
          ...state.customModeLayout,
          columns: preset.columns,
          rows: preset.rows,
        };
        gridPanel.hidden = true;
        saveCustomModeLayout();
        applyCustomModeLayout();
      });
      gridPanel.appendChild(choice);
    });
    gridButton.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      gridPanel.hidden = !gridPanel.hidden;
    });
    sizeButton.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      const sequence = ["compact", "normal", "wide"];
      const index = sequence.indexOf(state.customModeLayout.size);
      state.customModeLayout = {
        ...state.customModeLayout,
        size: sequence[(index + 1) % sequence.length],
      };
      saveCustomModeLayout();
      applyCustomModeLayout();
    });
    controls.append(gridButton, sizeButton, gridPanel);
    first.appendChild(controls);
  }

  function getCustomModeSearchControl() {
    const input = $$("input#search, input[name='search']").find((element) => isVisible(element));
    return input?.closest("label") || input?.parentElement || input || null;
  }

  function createCustomModeActionButton(kind, label, iconName) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `entry-llnk-custom-edit-action is-${kind}`;
    button.dataset[`entryLlnkCustom${kind[0].toUpperCase()}${kind.slice(1)}`] = "1";
    button.innerHTML = `<span class="material-symbols-outlined" aria-hidden="true">${iconName}</span><span>${label}</span>`;
    return button;
  }

  function beginCustomModeEditing() {
    if (!fallModeAllowed()) return;
    state.customModeComposeRestoreOpen = null;
    closeStoryToolbarPanels();
    state.customModeDraftLayout = cloneCustomModeLayout(state.customModeLayout);
    state.customModeEditing = true;
    document.documentElement.classList.add("entry-llnk-custom-mode-editing");
    stopAutoMoreWatch();
    window.clearTimeout(state.autoMoreReleaseTimer);
    state.autoMoreReleaseTimer = 0;
    state.autoMoreClicking = false;
    forceCustomModeComposeMenuOpen();
    applyCustomModeLayout();
  }

  function cancelCustomModeEditing() {
    state.customModeDraftLayout = null;
    state.customModeEditing = false;
    document.documentElement.classList.remove("entry-llnk-custom-mode-editing");
    releaseCustomModeComposeMenu();
    applyCustomModeLayout();
    startAutoMoreWatch();
  }

  function commitCustomModeEditing() {
    if (!state.customModeEditing) return;
    state.customModeLayout = cloneCustomModeLayout(state.customModeDraftLayout);
    state.customModeDraftLayout = null;
    state.customModeEditing = false;
    document.documentElement.classList.remove("entry-llnk-custom-mode-editing");
    releaseCustomModeComposeMenu();
    saveCustomModeLayout();
    applyCustomModeLayout();
    startAutoMoreWatch();
  }

  function resetCustomModeEditing() {
    if (!state.customModeEditing) return;
    state.customModeDraftLayout = cloneCustomModeLayout(DEFAULT_CUSTOM_MODE_LAYOUT);
    removeFallModeStage({ preserveEditing: true });
    startFallMode();
  }

  function createCustomModeSamplePreview(sampleId) {
    const preview = document.createElement("span");
    preview.className = "entry-llnk-custom-sample-preview";
    preview.dataset.entryLlnkCustomSamplePreview = sampleId;
    preview.setAttribute("aria-hidden", "true");
    for (let index = 0; index < 4; index += 1) preview.appendChild(document.createElement("i"));
    return preview;
  }

  function applyCustomModeSample(sampleId) {
    if (!state.customModeEditing) return;
    const list = getList();
    const rows = getCustomModeRows(list);
    if (!list || !rows.length) return;
    const metrics = state.customModeGridMetrics || getCustomModeGridMetrics(list, rows, getCustomModeObjectSources());
    const columns = Math.max(CUSTOM_MODE_POST_GRID_COLUMNS, metrics.columns);
    const margin = Math.max(1, Math.min(4, Math.floor(columns * 0.04)));
    const gap = Math.max(1, Math.min(3, Math.round(columns * 0.025)));
    const available = Math.max(8, columns - margin * 2);
    const standardWidth = Math.max(8, Math.min(CUSTOM_MODE_POST_GRID_COLUMNS, available));
    const wideWidth = Math.max(8, Math.min(36, available));
    const columnWidth = Math.max(8, Math.min(CUSTOM_MODE_POST_GRID_COLUMNS, Math.floor((available - gap) / 2)));
    const centerX = (width) => Math.max(0, Math.floor((columns - width) / 2));
    const rightX = (width) => Math.max(margin, columns - margin - width);
    const anchor = (x, y, width) => clampCustomModePostAnchor({ x, y, w: width }, metrics);
    const layout = cloneCustomModeLayout(state.customModeDraftLayout);
    const objectSources = getCustomModeObjectSources();
    const objectMeasurements = measureCustomModeSources(objectSources.map(({ source }) => source));
    const objectMeasurementFor = (key) => {
      const source = objectSources.find((item) => item.key === key)?.source;
      return objectMeasurements.find((measurement) => measurement.source === source) || null;
    };
    const sampleGap = Math.max(12, Math.round(metrics.cellY * 0.6));
    const samplePostY = objectSources.reduce((maximum, { key, source }) => {
      const measurement = objectMeasurements.find((item) => item.source === source);
      if (!measurement) return maximum;
      const objectAnchor = layout.objects[key] || customModeAnchorFromMeasurement(measurement, metrics);
      return Math.max(
        maximum,
        objectAnchor.y + Math.max(1, Math.ceil((measurement.height + sampleGap) / metrics.cellY))
      );
    }, 0);
    const single = (x, width) => {
      layout.first = anchor(x, samplePostY, width);
      layout.second = anchor(x, samplePostY + 1, width);
      layout.third = null;
      layout.fourth = null;
    };

    if (sampleId === "mini") {
      const miniWidth = Math.max(8, Math.min(11, columnWidth));
      const miniGap = Math.max(2, gap);
      const miniGroupWidth = miniWidth * 2 + miniGap;
      const left = centerX(miniGroupWidth);
      const right = left + miniWidth + miniGap;
      const composerHeight = objectMeasurementFor("composer")?.height || metrics.cellY * 6;
      const toolbarHeight = Math.max(
        metrics.cellY,
        ...["filter", "settings", "sort", "period"]
          .map((key) => objectMeasurementFor(key)?.height || 0)
      );
      const toolbarY = Math.max(1, Math.ceil((composerHeight + sampleGap) / metrics.cellY));
      const postY = toolbarY + Math.max(1, Math.ceil((toolbarHeight + sampleGap) / metrics.cellY));
      const objectWidth = (key) => Math.max(
        1,
        Math.round((objectMeasurementFor(key)?.width || metrics.cellX * 3) / metrics.cellX)
      );
      const periodX = right + miniWidth - objectWidth("period");
      const sortX = periodX - objectWidth("sort");

      layout.first = anchor(left, postY, miniWidth);
      layout.second = anchor(right, postY, miniWidth);
      layout.third = anchor(left, postY + 1, miniWidth);
      layout.fourth = anchor(right, postY + 1, miniWidth);
      layout.objects.composer = { x: left, y: 0 };
      layout.objects.filter = { x: left, y: toolbarY };
      layout.objects.settings = { x: left + objectWidth("filter"), y: toolbarY };
      layout.objects.sort = { x: sortX, y: toolbarY };
      layout.objects.period = { x: periodX, y: toolbarY };
    } else if (sampleId === "columns" || sampleId === "staggered") {
      const left = margin;
      const right = rightX(columnWidth);
      const offset = sampleId === "staggered" ? 4 : 0;
      layout.first = anchor(left, samplePostY, columnWidth);
      layout.second = anchor(right, samplePostY + offset, columnWidth);
      layout.third = anchor(left, samplePostY + 1, columnWidth);
      layout.fourth = anchor(right, samplePostY + offset + 1, columnWidth);
    } else if (sampleId === "wide") {
      single(centerX(wideWidth), wideWidth);
    } else if (sampleId === "left") {
      single(margin, standardWidth);
    } else if (sampleId === "right") {
      single(rightX(standardWidth), standardWidth);
    } else {
      single(centerX(standardWidth), standardWidth);
    }
    layout.front = "first";
    state.customModeDraftLayout = layout;
    applyCustomModeLayout();
  }

  function ensureCustomModeEditActions() {
    let actions = $("[data-entry-llnk-custom-edit-actions='1']", document.body);
    if (!actions) {
      actions = document.createElement("span");
      actions.className = "entry-llnk-custom-edit-actions";
      actions.dataset.entryLlnkCustomEditActions = "1";
      document.body.appendChild(actions);
    }
    const mode = state.customModeEditing ? "editing" : "view";
    if (actions.dataset.entryLlnkCustomEditMode !== mode) {
      actions.dataset.entryLlnkCustomEditMode = mode;
      actions.replaceChildren();
      if (state.customModeEditing) {
        const sample = createCustomModeActionButton("sample", "\uc0d8\ud50c", "dashboard");
        const reset = createCustomModeActionButton("reset", "\ucd08\uae30\ud654", "restart_alt");
        const cancel = createCustomModeActionButton("cancel", "\ucde8\uc18c", "close");
        const save = createCustomModeActionButton("save", "\uc800\uc7a5", "save");
        const samplePanel = document.createElement("span");
        samplePanel.className = "entry-llnk-custom-sample-panel";
        samplePanel.dataset.entryLlnkCustomSamplePanel = "1";
        samplePanel.hidden = true;
        CUSTOM_MODE_LAYOUT_SAMPLES.forEach(({ id, label }) => {
          const choice = document.createElement("button");
          choice.type = "button";
          choice.className = "entry-llnk-custom-sample-choice";
          choice.dataset.entryLlnkCustomSample = id;
          choice.append(createCustomModeSamplePreview(id), document.createTextNode(label));
          choice.addEventListener("click", () => {
            applyCustomModeSample(id);
            samplePanel.hidden = true;
            sample.setAttribute("aria-expanded", "false");
          });
          samplePanel.appendChild(choice);
        });
        sample.setAttribute("aria-haspopup", "menu");
        sample.setAttribute("aria-expanded", "false");
        sample.addEventListener("click", () => {
          samplePanel.hidden = !samplePanel.hidden;
          sample.setAttribute("aria-expanded", String(!samplePanel.hidden));
        });
        reset.addEventListener("click", resetCustomModeEditing);
        cancel.addEventListener("click", cancelCustomModeEditing);
        save.addEventListener("click", commitCustomModeEditing);
        actions.append(sample, samplePanel, reset, cancel, save);
      } else {
        const edit = createCustomModeActionButton("edit", "\ud3b8\uc9d1", "edit");
        edit.addEventListener("click", beginCustomModeEditing);
        actions.append(edit);
      }
    }
    const search = getCustomModeSearchControl();
    const rect = search?.getBoundingClientRect();
    const width = Math.max(72, actions.offsetWidth || (state.customModeEditing ? 318 : 72));
    const height = Math.max(34, actions.offsetHeight || 36);
    const searchLeft = rect ? rect.left + window.scrollX : window.scrollX + window.innerWidth - 16;
    const searchTop = rect ? rect.top + window.scrollY : window.scrollY + 16;
    actions.style.left = `${Math.max(8, Math.round(searchLeft - width - 10))}px`;
    actions.style.top = `${Math.max(8, Math.round(searchTop + ((rect?.height || height) - height) / 2))}px`;
  }

  function ensureCustomModeResizeHandles(source, role) {
    if (!(source instanceof HTMLElement) || !CUSTOM_MODE_POST_ROLES.includes(role)) return;
    ["nw", "ne", "sw", "se"].forEach((corner) => {
      let handle = $(`[data-entry-llnk-custom-resize="${corner}"]`, source);
      if (!handle) {
        handle = document.createElement("span");
        handle.className = `entry-llnk-custom-resize is-${corner}`;
        handle.dataset.entryLlnkCustomResize = corner;
        handle.setAttribute("aria-hidden", "true");
        source.appendChild(handle);
      }
    });
  }

  function syncCustomModePostNumber(source, index, editablePostCount) {
    if (!(source instanceof HTMLElement)) return;
    let badge = $("[data-entry-llnk-custom-number='1']", source);
    if (!state.customModeEditing || index >= editablePostCount || index >= 4) {
      badge?.remove();
      return;
    }
    if (!badge) {
      badge = document.createElement("span");
      badge.className = "entry-llnk-custom-post-number";
      badge.dataset.entryLlnkCustomNumber = "1";
      badge.setAttribute("aria-hidden", "true");
      source.appendChild(badge);
    }
    badge.textContent = String(index + 1);
    badge.style.setProperty("color", "#191000", "important");
    badge.style.setProperty("-webkit-text-fill-color", "#191000", "important");
  }

  function applyLegacyCustomModeLayout() {
    if (!fallModeAllowed()) return;
    const list = getList();
    const canvas = getCustomModeCanvas(list);
    if (!list || !canvas) return;
    const rows = getCustomModeRows(list);
    if (!rows.length) return;
    const grid = ensureCustomModeCanvas(canvas);
    const metrics = getCustomModeGridMetrics(canvas);
    grid?.style.setProperty("--entry-llnk-custom-grid-cell", `${metrics.cellX}px`);
    const measurements = measureCustomModeSources(rows, canvas);
    const objects = getCustomModeObjectSources(canvas);
    objects.forEach(({ source, key }) => ensureCustomModeObjectHandle(source, key));
    const objectMeasurements = measureCustomModeSources(objects.map(({ source }) => source), canvas);
    const layout = normalizeCustomModeLayout(state.customModeLayout);
    const firstMeasurement = measurements[0];
    const secondMeasurement = measurements[1] || {
      ...firstMeasurement,
      y: firstMeasurement.y + firstMeasurement.height + metrics.cellY,
    };
    let layoutChanged = false;
    if (!layout.first) {
      layout.first = customModeAnchorFromPosition(firstMeasurement, metrics);
      layoutChanged = true;
    }
    if (!layout.second) {
      layout.second = customModeAnchorFromPosition(secondMeasurement, metrics);
      layoutChanged = true;
    }
    const first = customModePositionFromAnchor(layout.first, metrics);
    const second = customModePositionFromAnchor(layout.second, metrics);
    const requestedScale = customModeScale(layout.size);
    const maxWidth = Math.max(...measurements.map((item) => item.width));
    const gap = Math.max(12, metrics.cellY);
    const fitScale = layout.columns > 1
      ? Math.max(0.34, Math.min(1, (metrics.width - gap * (layout.columns - 1)) / (maxWidth * layout.columns)))
      : 1;
    const scale = Math.min(requestedScale, fitScale);
    const delta = { x: second.x - first.x, y: second.y - first.y };
    const horizontal = Math.abs(delta.x) > Math.abs(delta.y);
    const columnVector = horizontal
      ? (Math.abs(delta.x) + Math.abs(delta.y) < metrics.cellX ? { x: maxWidth * scale + gap, y: 0 } : delta)
      : { x: maxWidth * scale + gap, y: 0 };
    const maxHeight = Math.max(...measurements.map((item) => item.height));
    const rowVector = horizontal
      ? { x: 0, y: maxHeight * scale + gap }
      : (Math.abs(delta.x) + Math.abs(delta.y) < metrics.cellY ? { x: 0, y: firstMeasurement.height * scale + gap } : delta);
    const flowVector = Math.abs(delta.x) + Math.abs(delta.y) < metrics.cellY
      ? { x: 0, y: Math.max(firstMeasurement.height, secondMeasurement.height) * scale + gap }
      : delta;
    const flowMagnitude = Math.hypot(flowVector.x, flowVector.y) || 1;
    const flowDirection = { x: flowVector.x / flowMagnitude, y: flowVector.y / flowMagnitude };
    const flowIsHorizontal = Math.abs(flowDirection.x) > Math.abs(flowDirection.y);
    let flowPosition = { ...second };
    let flowPreviousMeasurement = secondMeasurement;
    state.customModeLayout = layout;

    objectMeasurements.forEach((measurement) => {
      const key = objects.find(({ source }) => source === measurement.source)?.key;
      if (!key) return;
      const { source, entry } = measurement;
      const anchor = layout.objects[key];
      const target = anchor ? customModePositionFromAnchor(anchor, metrics) : null;
      entry.x = target ? Math.round(target.x - measurement.x) : 0;
      entry.y = target ? Math.round(target.y - measurement.y) : 0;
      entry.scale = 1;
      source.dataset.entryLlnkCustomSource = "1";
      source.dataset.entryLlnkCustomObject = key;
      source.dataset.entryLlnkCustomVersion = String(CUSTOM_MODE_LAYOUT_VERSION);
      source.classList.add("entry-llnk-custom-draggable");
      source.classList.toggle("entry-llnk-custom-front", layout.front === key);
      source.style.position = "relative";
      source.style.transformOrigin = "top left";
      source.style.translate = `${entry.x}px ${entry.y}px`;
      source.style.scale = "1";
      source.style.zIndex = layout.front === key ? "30" : "20";
    });

    measurements.forEach((measurement, index) => {
      const source = measurement.source;
      const entry = measurement.entry;
      let target;
      if (index === 0) {
        target = first;
      } else if (index === 1) {
        target = second;
        flowPosition = { ...target };
        flowPreviousMeasurement = measurement;
      } else if (layout.columns === 1 && layout.rows === 1) {
        const minimumStep = (flowIsHorizontal ? flowPreviousMeasurement.width : flowPreviousMeasurement.height) * scale + gap;
        const step = Math.max(flowMagnitude, minimumStep);
        target = {
          x: Math.round(flowPosition.x + flowDirection.x * step),
          y: Math.round(flowPosition.y + flowDirection.y * step),
        };
        flowPosition = { ...target };
        flowPreviousMeasurement = measurement;
      } else if (horizontal) {
        const column = layout.columns === 1 ? index : index % layout.columns;
        const row = layout.columns === 1 ? 0 : Math.floor(index / layout.columns);
        target = {
          x: first.x + columnVector.x * column + rowVector.x * row,
          y: first.y + columnVector.y * column + rowVector.y * row,
        };
      } else {
        const row = layout.rows === 1 ? index : index % layout.rows;
        const column = layout.rows === 1 ? 0 : Math.floor(index / layout.rows);
        target = {
          x: first.x + columnVector.x * column + rowVector.x * row,
          y: first.y + columnVector.y * column + rowVector.y * row,
        };
      }
      entry.x = Math.round(target.x - measurement.x);
      entry.y = Math.round(target.y - measurement.y);
      entry.scale = scale;
      source.dataset.entryLlnkCustomSource = "1";
      source.dataset.entryLlnkCustomRole = index === 0 ? "first" : (index === 1 ? "second" : "auto");
      source.dataset.entryLlnkCustomVersion = String(CUSTOM_MODE_LAYOUT_VERSION);
      source.classList.toggle("entry-llnk-custom-draggable", index < 2);
      source.classList.toggle("entry-llnk-custom-front", layout.front === source.dataset.entryLlnkCustomRole);
      source.style.position = "relative";
      source.style.transformOrigin = "top left";
      source.style.translate = `${entry.x}px ${entry.y}px`;
      source.style.scale = String(scale);
      source.style.zIndex = layout.front === source.dataset.entryLlnkCustomRole ? "30" : (index < 2 ? "20" : "2");
    });
    state.fallModeEntries.forEach((entry, source) => {
      if (!source.isConnected || (!rows.includes(source) && !objects.some((object) => object.source === source))) {
        restoreCustomModeSource(source, entry);
        state.fallModeEntries.delete(source);
      }
    });
    ensureCustomModeControls(rows[0]);
    if (layoutChanged) saveCustomModeLayout();
  }

  function customModeAnchorFromMeasurement(measurement, metrics, includeWidth = false) {
    const anchor = {
      x: Math.round((measurement.x - metrics.left) / metrics.cellX),
      y: Math.round((measurement.y - metrics.top) / metrics.cellY),
    };
    if (includeWidth) anchor.w = Math.max(8, Math.round(measurement.width / metrics.cellX));
    return anchor;
  }

  function clampCustomModePostAnchor(anchor, metrics) {
    const width = Math.max(8, Math.min(metrics.columns, Math.round(anchor.w || CUSTOM_MODE_POST_GRID_COLUMNS)));
    return {
      x: Math.max(0, Math.min(metrics.columns - width, Math.round(anchor.x || 0))),
      y: Math.max(0, Math.round(anchor.y || 0)),
      w: width,
    };
  }

  function customModePostsUseSeparateColumns(layout) {
    if (!layout.first || !layout.second) return false;
    const firstRight = layout.first.x + layout.first.w;
    const secondRight = layout.second.x + layout.second.w;
    return firstRight <= layout.second.x || secondRight <= layout.first.x;
  }

  function resolveCustomModeTargetCollisions(targets, measurements, metrics, gap) {
    const placed = [];
    const snapY = (value) => metrics.top
      + Math.ceil((value - metrics.top) / metrics.cellY) * metrics.cellY;
    targets.forEach((target, index) => {
      const measurement = measurements[index];
      if (!target || !measurement) return;
      let y = target.y;
      if (index > 0) {
        let attempts = 0;
        while (attempts <= placed.length) {
          let nextY = y;
          placed.forEach((item) => {
            const overlapsX = target.x < item.x + item.width && target.x + measurement.width > item.x;
            const overlapsY = y < item.y + item.height + gap && y + measurement.height + gap > item.y;
            if (overlapsX && overlapsY) nextY = Math.max(nextY, item.y + item.height + gap);
          });
          if (nextY <= y) break;
          y = snapY(nextY);
          attempts += 1;
        }
        target.y = y;
      }
      placed.push({
        x: target.x,
        y: target.y,
        width: measurement.width,
        height: measurement.height,
      });
    });
  }

  function resolveCustomModeTargetCollisionsByLane(targets, measurements, metrics, gap, laneCount = 1) {
    const normalizedLaneCount = Math.max(1, Math.round(laneCount));
    if (normalizedLaneCount === 1) {
      resolveCustomModeTargetCollisions(targets, measurements, metrics, gap);
      return;
    }
    for (let lane = 0; lane < normalizedLaneCount; lane += 1) {
      const laneTargets = [];
      const laneMeasurements = [];
      for (let index = lane; index < targets.length; index += normalizedLaneCount) {
        if (!targets[index] || !measurements[index]) continue;
        laneTargets.push(targets[index]);
        laneMeasurements.push(measurements[index]);
      }
      resolveCustomModeTargetCollisions(laneTargets, laneMeasurements, metrics, gap);
    }
  }

  function moveCustomModeTargetsBelowBlockers(targets, measurements, blockers, metrics, gap) {
    const snapY = (value) => metrics.top
      + Math.ceil((value - metrics.top) / metrics.cellY) * metrics.cellY;
    targets.forEach((target, index) => {
      const measurement = measurements[index];
      if (!target || !measurement) return;
      let y = target.y;
      let attempts = 0;
      while (attempts <= blockers.length) {
        let nextY = y;
        blockers.forEach((item) => {
          const overlapsX = target.x < item.x + item.width && target.x + measurement.width > item.x;
          const overlapsY = y < item.y + item.height + gap && y + measurement.height + gap > item.y;
          if (overlapsX && overlapsY) nextY = Math.max(nextY, item.y + item.height + gap);
        });
        if (nextY <= y) break;
        y = snapY(nextY);
        attempts += 1;
      }
      target.y = y;
    });
  }

  function applyCustomModeSource(source, measurement, target, role, zIndex, width = null) {
    const entry = measurement.entry;
    if (Number.isFinite(width)) {
      source.style.setProperty("width", `${Math.max(1, Math.round(width))}px`, "important");
      source.style.setProperty("max-width", "none", "important");
    }
    entry.x = Math.round(target.x - measurement.x);
    entry.y = Math.round(target.y - measurement.y);
    source.dataset.entryLlnkCustomSource = "1";
    source.dataset.entryLlnkCustomVersion = String(CUSTOM_MODE_LAYOUT_VERSION);
    if ([...CUSTOM_MODE_POST_ROLES, "auto"].includes(role)) {
      source.dataset.entryLlnkCustomRole = role;
      source.removeAttribute("data-entry-llnk-custom-object");
    } else {
      source.dataset.entryLlnkCustomObject = role;
      source.removeAttribute("data-entry-llnk-custom-role");
    }
    source.classList.toggle("entry-llnk-custom-draggable", state.customModeEditing && role !== "auto");
    source.classList.toggle("entry-llnk-custom-front", getActiveCustomModeLayout().front === role);
    source.style.position = "relative";
    source.style.transformOrigin = "top left";
    source.style.setProperty("translate", `${entry.x}px ${entry.y}px`, "important");
    source.style.scale = "1";
    source.style.zIndex = String(zIndex);
  }

  function positionStoryToolbarPanel(panel, button) {
    if (!(panel instanceof HTMLElement) || !(button instanceof HTMLElement)) return;
    const buttonRect = button.getBoundingClientRect();
    const viewportWidth = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
    const fallbackWidth = panel.classList.contains("entry-chat-story-settings-panel") ? 260 : 272;
    const panelWidth = panel.getBoundingClientRect().width || Math.min(fallbackWidth, Math.max(0, viewportWidth - 32));
    const minimumLeft = window.scrollX + 8;
    const maximumLeft = Math.max(minimumLeft, window.scrollX + viewportWidth - panelWidth - 8);
    const preferredLeft = buttonRect.left + window.scrollX;
    panel.style.left = `${Math.round(Math.max(minimumLeft, Math.min(maximumLeft, preferredLeft)))}px`;
    panel.style.top = `${Math.round(buttonRect.bottom + window.scrollY + 8)}px`;
  }

  function positionCustomModeToolbarPanels() {
    [
      ["[data-entry-llnk-link-filter='1']", "[data-entry-llnk-story-filter-panel='1']"],
      ["[data-entry-llnk-story-settings='1']", "[data-entry-llnk-story-settings-panel='1']"],
    ].forEach(([buttonSelector, panelSelector]) => {
      const button = $(buttonSelector);
      const panel = $(panelSelector);
      if (!button || !panel) return;
      positionStoryToolbarPanel(panel, button);
    });
  }

  function applyCustomModeLayout() {
    if (!fallModeAllowed()) return;
    const list = getList();
    const rows = getCustomModeRows(list);
    if (!list || !rows.length) return;
    const objects = getCustomModeObjectSources();
    rows.forEach((source) => {
      ensureCustomModeEntry(source);
      if (state.customModeEditing) ensureCustomModeInteractionShield(source);
      else $$(`[data-entry-llnk-custom-interaction-shield='1']`, source).forEach((shield) => shield.remove());
    });
    objects.forEach(({ source, key }) => {
      ensureCustomModeEntry(source);
      if (state.customModeEditing) {
        ensureCustomModeInteractionShield(source);
        ensureCustomModeObjectHandle(source, key);
      } else {
        $$(`[data-entry-llnk-custom-interaction-shield='1']`, source).forEach((shield) => shield.remove());
        $$(`[data-entry-llnk-custom-drag-handle='1']`, source).forEach((handle) => handle.remove());
      }
    });
    const metrics = getCustomModeGridMetrics(list, rows, objects);
    const layout = cloneCustomModeLayout(getActiveCustomModeLayout());
    const objectMeasurements = measureCustomModeSources(objects.map(({ source }) => source));
    const objectLayouts = objectMeasurements.map((measurement) => {
      const key = objects.find(({ source }) => source === measurement.source)?.key;
      if (!key) return null;
      let anchor = layout.objects[key];
      if (!anchor) anchor = customModeAnchorFromMeasurement(measurement, metrics);
      const maxX = Math.max(0, Math.floor((metrics.width - measurement.width) / metrics.cellX));
      anchor = {
        x: Math.max(0, Math.min(maxX, Math.round(anchor.x))),
        y: Math.max(0, Math.round(anchor.y)),
      };
      if (layout.objects[key]) layout.objects[key] = anchor;
      const target = customModePositionFromAnchor(anchor, metrics);
      target.x += metrics.left;
      target.y += metrics.top;
      return { key, measurement, target };
    }).filter(Boolean);
    const objectBlockers = [];
    const postBlockers = [];
    const overlappingToolbarObjects = new Set(["filter", "settings", "sort", "period"]);
    objectLayouts.forEach(({ key, measurement, target }) => {
      moveCustomModeTargetsBelowBlockers([target], [measurement], objectBlockers, metrics, Math.max(12, Math.round(metrics.cellY * 0.6)));
      const blocker = {
        x: target.x,
        y: target.y,
        width: measurement.width,
        height: measurement.height,
      };
      postBlockers.push(blocker);
      if (!overlappingToolbarObjects.has(key)) objectBlockers.push(blocker);
    });
    let measurements = measureCustomModeSources(rows);
    if (!layout.first) layout.first = customModeAnchorFromMeasurement(measurements[0], metrics, true);
    if (!layout.second) {
      const fallback = measurements[1] || {
        ...measurements[0],
        y: measurements[0].y + measurements[0].height + metrics.cellY,
      };
      layout.second = customModeAnchorFromMeasurement(fallback, metrics, true);
    }
    layout.first = clampCustomModePostAnchor(layout.first, metrics);
    layout.second = clampCustomModePostAnchor(layout.second, metrics);
    if (layout.second.y < layout.first.y) layout.second.y = layout.first.y;
    const rowGap = Math.max(12, Math.round(metrics.cellY * 0.6));
    const separateColumns = customModePostsUseSeparateColumns(layout);
    if (separateColumns) {
      if (!layout.third) {
        layout.third = {
          x: layout.first.x,
          y: layout.first.y + Math.max(1, Math.ceil((measurements[0].height + rowGap) / metrics.cellY)),
          w: layout.first.w,
        };
      }
      if (!layout.fourth) {
        const secondMeasurement = measurements[1] || measurements[0];
        layout.fourth = {
          x: layout.second.x,
          y: layout.second.y + Math.max(1, Math.ceil((secondMeasurement.height + rowGap) / metrics.cellY)),
          w: layout.second.w,
        };
      }
      layout.third = clampCustomModePostAnchor(layout.third, metrics);
      layout.fourth = clampCustomModePostAnchor(layout.fourth, metrics);
    }

    const splitAnchors = [layout.first, layout.second, layout.third, layout.fourth];
    const anchorForIndex = (index) => {
      if (!separateColumns) return index % 2 === 0 ? layout.first : layout.second;
      return splitAnchors[index % splitAnchors.length];
    };

    rows.forEach((source, index) => {
      const anchor = anchorForIndex(index);
      source.style.setProperty("width", `${Math.round(anchor.w * metrics.cellX)}px`, "important");
      source.style.setProperty("max-width", "none", "important");
    });
    measurements = measureCustomModeSources(rows);
    const gap = Math.max(12, Math.round(metrics.cellY * 0.6));
    const firstX = metrics.left + layout.first.x * metrics.cellX;
    const secondX = metrics.left + layout.second.x * metrics.cellX;
    const firstY = metrics.top + layout.first.y * metrics.cellY;
    const targets = [];
    if (separateColumns) {
      const minimumThirdY = layout.first.y + Math.max(1, Math.ceil((measurements[0].height + rowGap) / metrics.cellY));
      const minimumFourthY = layout.second.y + Math.max(1, Math.ceil(((measurements[1]?.height || measurements[0].height) + rowGap) / metrics.cellY));
      const effectiveThirdY = Math.max(layout.third.y, minimumThirdY);
      const effectiveFourthY = Math.max(layout.fourth.y, minimumFourthY);
      const thirdX = metrics.left + layout.third.x * metrics.cellX;
      const fourthX = metrics.left + layout.fourth.x * metrics.cellX;
      const secondY = metrics.top + layout.second.y * metrics.cellY;
      const thirdY = metrics.top + effectiveThirdY * metrics.cellY;
      const fourthY = metrics.top + effectiveFourthY * metrics.cellY;
      const leftGap = Math.max(rowGap, thirdY - (firstY + measurements[0].height));
      const rightGap = Math.max(rowGap, fourthY - (secondY + (measurements[1]?.height || 0)));
      const splitXs = [firstX, secondX, thirdX, fourthX];
      if (measurements[0]) targets[0] = { x: firstX, y: firstY };
      if (measurements[1]) targets[1] = { x: secondX, y: secondY };
      if (measurements[2]) targets[2] = { x: thirdX, y: thirdY };
      if (measurements[3]) targets[3] = { x: fourthX, y: fourthY };
      for (let index = 4; index < measurements.length; index += 1) {
        const previousIndex = index - 2;
        const patternIndex = index % splitXs.length;
        targets[index] = {
          x: splitXs[patternIndex],
          y: targets[previousIndex].y
            + measurements[previousIndex].height
            + (index % 2 === 0 ? leftGap : rightGap),
        };
      }
    } else {
      const requestedSecondY = metrics.top + layout.second.y * metrics.cellY;
      const secondY = Math.max(requestedSecondY, firstY + measurements[0].height + rowGap);
      const sequenceGap = Math.max(rowGap, secondY - (firstY + measurements[0].height));
      targets[0] = { x: firstX, y: firstY };
      if (measurements[1]) targets[1] = { x: secondX, y: secondY };
      for (let index = 2; index < measurements.length; index += 1) {
        targets[index] = {
          x: index % 2 === 0 ? firstX : secondX,
          y: targets[index - 1].y + measurements[index - 1].height + sequenceGap,
        };
      }
    }

    const editablePostCount = separateColumns ? 4 : 2;
    moveCustomModeTargetsBelowBlockers(targets, measurements, postBlockers, metrics, gap);
    resolveCustomModeTargetCollisionsByLane(targets, measurements, metrics, gap, separateColumns ? 2 : 1);

    measurements.forEach((measurement, index) => {
      const role = index < editablePostCount ? CUSTOM_MODE_POST_ROLES[index] : "auto";
      const anchor = anchorForIndex(index);
      const zIndex = layout.front === role ? 60 : index < editablePostCount ? 50 : 40;
      applyCustomModeSource(measurement.source, measurement, targets[index], role, zIndex, anchor.w * metrics.cellX);
      syncCustomModePostNumber(measurement.source, index, editablePostCount);
      if (state.customModeEditing && index < editablePostCount) ensureCustomModeResizeHandles(measurement.source, role);
      else $$('[data-entry-llnk-custom-resize]', measurement.source).forEach((handle) => handle.remove());
    });

    objectLayouts.forEach(({ key, measurement, target }) => {
      const toolbarObject = ["filter", "settings", "sort", "period"].includes(key);
      const zIndex = toolbarObject
        ? (layout.front === key ? 220 : 210)
        : (layout.front === key ? 80 : 70);
      applyCustomModeSource(measurement.source, measurement, target, key, zIndex);
    });

    state.fallModeEntries.forEach((entry, source) => {
      if (!source.isConnected || (!rows.includes(source) && !objects.some((object) => object.source === source))) {
        restoreCustomModeSource(source, entry);
        state.fallModeEntries.delete(source);
      }
    });
    if (state.customModeList !== list) {
      restoreCustomModeListStyles();
      state.customModeList = list;
      state.customModeListStyles = captureCustomModeListStyles(list);
    }
    const lastBottom = targets.reduce((maximum, target, index) => Math.max(maximum, target.y + measurements[index].height), metrics.top);
    const listTop = list.getBoundingClientRect().top + window.scrollY;
    const visualHeight = Math.max(1, Math.ceil(lastBottom - listTop + gap));
    list.style.setProperty("position", "relative");
    list.style.setProperty("height", `${visualHeight}px`, "important");
    list.style.setProperty("min-height", `${visualHeight}px`, "important");
    list.style.setProperty("overflow-anchor", "none", "important");

    if (state.customModeEditing) {
      state.customModeDraftLayout = layout;
      ensureCustomModeCanvas(metrics);
      document.documentElement.classList.add("entry-llnk-custom-mode-editing");
    } else {
      state.customModeLayout = layout;
      removeCustomModeCanvas();
      document.documentElement.classList.remove("entry-llnk-custom-mode-editing");
    }
    ensureCustomModeEditActions();
    forceCustomModeComposeMenuOpen();
    positionCustomModeToolbarPanels();
  }

  function startLegacyFallMode() {
    state.fallModeRunTimer = 0;
    if (!fallModeAllowed() || state.fallModeActive) return;
    removeFallModeStage();
    clearStaleCustomModeSources();
    document.documentElement.classList.add("entry-llnk-custom-mode-active");
    state.fallModeActive = true;
    const token = ++state.fallModeToken;
    let drag = null;
    const controlSelector = "button, a[href], [role='button'], input, textarea, select, label";
    const queueLayout = () => {
      if (state.fallModeFrame) return;
      state.fallModeFrame = window.requestAnimationFrame(() => {
        state.fallModeFrame = 0;
        if (!drag && token === state.fallModeToken && fallModeAllowed()) applyCustomModeLayout();
      });
    };
    const getDraggableSource = (target) => {
      if (!(target instanceof Element)) return null;
      const handle = target.closest("[data-entry-llnk-custom-drag-handle='1']");
      if (!handle && target.closest(controlSelector)) return null;
      const source = target.closest("[data-entry-llnk-custom-source='1']");
      if (!(source instanceof HTMLElement)) return null;
      const key = source.dataset.entryLlnkCustomRole || source.dataset.entryLlnkCustomObject;
      return ["first", "second", "composer", "toolbar"].includes(key) ? source : null;
    };
    const releaseDrag = (event) => {
      if (!drag || (event && event.pointerId !== drag.pointerId)) return;
      const { source, entry, role, pointerId, canvas, naturalX, naturalY } = drag;
      const metrics = getCustomModeGridMetrics(canvas);
      const anchor = customModeAnchorFromPosition({ x: naturalX + entry.x, y: naturalY + entry.y }, metrics);
      const layout = normalizeCustomModeLayout(state.customModeLayout);
      if (role === "composer" || role === "toolbar") {
        layout.objects[role] = anchor;
      } else {
        layout[role] = anchor;
      }
      layout.front = role;
      state.customModeLayout = layout;
      source.classList.remove("entry-llnk-custom-dragging");
      source.releasePointerCapture?.(pointerId);
      drag = null;
      saveCustomModeLayout();
      queueLayout();
    };
    const onPointerDown = (event) => {
      if (event.button !== 0 || drag) return;
      const source = getDraggableSource(event.target);
      if (!source) return;
      const entry = state.fallModeEntries.get(source);
      const canvas = getCustomModeCanvas();
      if (!entry || !canvas) return;
      const measurement = measureCustomModeSources([source], canvas)[0];
      drag = {
        source,
        entry,
        role: source.dataset.entryLlnkCustomRole,
        canvas,
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        baseX: entry.x,
        baseY: entry.y,
        width: Math.round(measurement.width * entry.scale),
        height: Math.round(measurement.height * entry.scale),
        naturalX: measurement.x,
        naturalY: measurement.y,
      };
      if (!drag.role) drag.role = source.dataset.entryLlnkCustomObject;
      source.classList.add("entry-llnk-custom-dragging");
      source.style.zIndex = "1000";
      source.setPointerCapture?.(event.pointerId);
      event.preventDefault();
    };
    const onPointerMove = (event) => {
      if (!drag || event.pointerId !== drag.pointerId) return;
      const minX = 8 - drag.naturalX;
      const maxX = Math.max(minX, drag.canvas.clientWidth - drag.width - 8 - drag.naturalX);
      const minY = 8 - drag.naturalY;
      const maxY = Math.max(minY, drag.canvas.clientHeight - drag.height - 8 - drag.naturalY);
      drag.entry.x = Math.max(minX, Math.min(maxX, drag.baseX + event.clientX - drag.startX));
      drag.entry.y = Math.max(minY, Math.min(maxY, drag.baseY + event.clientY - drag.startY));
      drag.source.style.translate = `${Math.round(drag.entry.x)}px ${Math.round(drag.entry.y)}px`;
      event.preventDefault();
    };
    const onPointerUp = (event) => {
      if (!drag || event.pointerId !== drag.pointerId) return;
      releaseDrag(event);
      event.preventDefault();
    };
    const observer = new MutationObserver(queueLayout);
    observer.observe(getList() || document.body, { childList: true });
    window.addEventListener("pointerdown", onPointerDown, true);
    window.addEventListener("pointermove", onPointerMove, true);
    window.addEventListener("pointerup", onPointerUp, true);
    window.addEventListener("pointercancel", onPointerUp, true);
    window.addEventListener("resize", queueLayout, { passive: true });
    state.fallModeInteractionCleanup = () => {
      window.removeEventListener("pointerdown", onPointerDown, true);
      window.removeEventListener("pointermove", onPointerMove, true);
      window.removeEventListener("pointerup", onPointerUp, true);
      window.removeEventListener("pointercancel", onPointerUp, true);
      window.removeEventListener("resize", queueLayout);
      observer.disconnect();
    };
    applyCustomModeLayout();
  }

  function startFallMode() {
    state.fallModeRunTimer = 0;
    if (!fallModeAllowed() || state.fallModeActive) return;
    removeFallModeStage({ preserveEditing: true });
    clearStaleCustomModeSources();
    state.fallModeActive = true;
    if (!hasSavedCustomModeLayout() && !state.customModeEditing) {
      state.customModeComposeRestoreOpen = null;
      state.customModeDraftLayout = cloneCustomModeLayout(state.customModeLayout);
      state.customModeEditing = true;
    }
    document.documentElement.classList.add("entry-llnk-custom-mode-active");
    document.documentElement.classList.toggle("entry-llnk-custom-mode-editing", state.customModeEditing);
    forceCustomModeComposeMenuOpen();
    const token = ++state.fallModeToken;
    let drag = null;
    let liveDragFrame = 0;
    let suppressClickSource = null;
    let suppressClickUntil = 0;
    let resizeObserver = null;
    let layoutPendingWhileHidden = false;
    let layoutApplying = false;
    let layoutReleaseFrame = 0;
    const resizeObservedSources = new Set();
    const interactiveSelector = "button, a[href], [role='button'], input, textarea, select, label";
    const movableRoles = new Set([...CUSTOM_MODE_POST_ROLES, "composer", "filter", "settings", "sort", "period"]);
    const queueLayout = () => {
      if (drag) return;
      if (document.visibilityState !== "visible") {
        layoutPendingWhileHidden = true;
        if (state.fallModeFrame) {
          window.cancelAnimationFrame(state.fallModeFrame);
          state.fallModeFrame = 0;
        }
        return;
      }
      if (state.fallModeFrame) return;
      state.fallModeFrame = window.requestAnimationFrame(() => {
        state.fallModeFrame = 0;
        if (document.visibilityState !== "visible") {
          layoutPendingWhileHidden = true;
          return;
        }
        if (!drag && token === state.fallModeToken && fallModeAllowed()) {
          applyLayoutNow();
        }
      });
    };
    const onVisibilityChange = () => {
      if (document.visibilityState !== "visible") {
        layoutPendingWhileHidden = true;
        if (state.fallModeFrame) {
          window.cancelAnimationFrame(state.fallModeFrame);
          state.fallModeFrame = 0;
        }
        return;
      }
      if (!layoutPendingWhileHidden) return;
      layoutPendingWhileHidden = false;
      queueLayout();
    };
    const syncResizeObserver = () => {
      if (!resizeObserver) return;
      const list = getList();
      const objectSources = getCustomModeObjectSources().map(({ source }) => source);
      const nextSources = new Set([list, ...getCustomModeRows(list), ...objectSources].filter((source) => source instanceof HTMLElement));
      resizeObservedSources.forEach((source) => {
        if (nextSources.has(source)) return;
        resizeObserver.unobserve(source);
        resizeObservedSources.delete(source);
      });
      nextSources.forEach((source) => {
        if (resizeObservedSources.has(source)) return;
        resizeObservedSources.add(source);
        resizeObserver.observe(source);
      });
    };
    const applyLayoutNow = () => {
      layoutApplying = true;
      applyCustomModeLayout();
      syncResizeObserver();
      if (layoutReleaseFrame) window.cancelAnimationFrame(layoutReleaseFrame);
      layoutReleaseFrame = window.requestAnimationFrame(() => {
        layoutReleaseFrame = 0;
        layoutApplying = false;
      });
    };
    if (typeof ResizeObserver === "function") {
      resizeObserver = new ResizeObserver((entries) => {
        if (layoutApplying) return;
        const changedSources = new Set();
        entries.forEach(({ target }) => {
          if (!(target instanceof Element)) return;
          if (target.matches(POST_SELECTOR) || target.dataset.entryLlnkCustomObject === "composer") {
            changedSources.add(target);
          }
        });
        if (changedSources.size) queueLayout();
      });
    }
    const customModeMutationAffectsLayout = (mutations) => {
      if (getList() !== state.customModeList) {
        return { affected: true, animateAll: true, sources: new Set() };
      }
      const list = state.customModeList;
      const customInternalSelector = [
        "[data-entry-llnk-custom-controls]",
        "[data-entry-llnk-custom-drag-handle]",
        "[data-entry-llnk-custom-resize]",
        "[data-entry-llnk-custom-interaction-shield]",
        "[data-entry-llnk-custom-edit-actions]",
        "[data-entry-llnk-custom-number]",
        "[data-entry-llnk-custom-grid]",
      ].join(",");
      const sources = new Set();
      let animateAll = false;
      const composer = $(".entry-chat-compose-shell");
      const findOwningTopLevelPost = (node) => {
        if (!(node instanceof Element) || !(list instanceof Element)) return null;
        let post = node.matches(POST_SELECTOR) ? node : node.closest(POST_SELECTOR);
        while (post instanceof Element && post.parentElement !== list) {
          post = post.parentElement?.closest(POST_SELECTOR) || null;
        }
        return post instanceof HTMLElement && post.parentElement === list ? post : null;
      };
      const collectSource = (node, structural = false) => {
        if (!(node instanceof Element)) return;
        if (node.matches(customInternalSelector) || node.closest(customInternalSelector)) return;
        const topLevelPost = findOwningTopLevelPost(node);
        if (topLevelPost) {
          if (structural) animateAll = true;
          sources.add(topLevelPost);
          return;
        }
        if (structural) {
          animateAll = true;
          return;
        }
        if (!(composer instanceof Element)) return;
        if (node === composer || composer.contains(node) || node.contains(composer)) sources.add(composer);
      };
      mutations.forEach((mutation) => {
        collectSource(mutation.target);
        mutation.addedNodes.forEach((node) => {
          const structural = mutation.target === list && node instanceof Element && node.matches(POST_SELECTOR);
          collectSource(node, structural);
        });
        mutation.removedNodes.forEach((node) => {
          const structural = mutation.target === list && node instanceof Element && node.matches(POST_SELECTOR);
          collectSource(node, structural);
        });
      });
      return { affected: animateAll || sources.size > 0, animateAll, sources };
    };
    const updateDraftAnchor = (role, anchor) => {
      const layout = cloneCustomModeLayout(state.customModeDraftLayout);
      if (CUSTOM_MODE_POST_ROLES.includes(role)) layout[role] = anchor;
      else layout.objects[role] = anchor;
      layout.front = role;
      state.customModeDraftLayout = layout;
    };
    const calculateDragAnchor = (activeDrag, clientX, clientY) => {
      const deltaX = clientX - activeDrag.startX;
      const deltaY = clientY - activeDrag.startY;
      const layout = cloneCustomModeLayout(state.customModeDraftLayout);
      let anchor = { ...activeDrag.anchor };
      if (activeDrag.resizeCorner) {
        const horizontalCells = Math.round(deltaX / activeDrag.metrics.cellX);
        if (activeDrag.resizeCorner.endsWith("e")) anchor.w += horizontalCells;
        else {
          anchor.x += horizontalCells;
          anchor.w -= horizontalCells;
        }
        return clampCustomModePostAnchor(anchor, activeDrag.metrics);
      }
      anchor.x += Math.round(deltaX / activeDrag.metrics.cellX);
      anchor.y += Math.round(deltaY / activeDrag.metrics.cellY);
      if (CUSTOM_MODE_POST_ROLES.includes(activeDrag.role)) {
        anchor = clampCustomModePostAnchor(anchor, activeDrag.metrics);
        if (activeDrag.role === "first" && layout.second) anchor.y = Math.min(anchor.y, layout.second.y);
        if (activeDrag.role === "second" && layout.first) anchor.y = Math.max(anchor.y, layout.first.y);
        if (activeDrag.role === "third" && layout.first) anchor.y = Math.max(anchor.y, layout.first.y);
        if (activeDrag.role === "fourth" && layout.second) anchor.y = Math.max(anchor.y, layout.second.y);
        return anchor;
      }
      const maxX = Math.max(0, Math.floor((activeDrag.metrics.width - activeDrag.width) / activeDrag.metrics.cellX));
      anchor.x = Math.max(0, Math.min(maxX, anchor.x));
      anchor.y = Math.max(0, anchor.y);
      return anchor;
    };
    const queueLivePostLayout = (activeDrag, anchor) => {
      activeDrag.previewAnchor = anchor;
      if (liveDragFrame) return;
      liveDragFrame = window.requestAnimationFrame(() => {
        liveDragFrame = 0;
        if (drag !== activeDrag || !activeDrag.previewAnchor) return;
        updateDraftAnchor(activeDrag.role, activeDrag.previewAnchor);
        applyLayoutNow();
        activeDrag.source.style.zIndex = "1400";
      });
    };
    const sourceFromEvent = (target) => {
      if (!(target instanceof Element)) return null;
      const source = target.closest("[data-entry-llnk-custom-source='1']");
      if (!(source instanceof HTMLElement)) return null;
      const role = source.dataset.entryLlnkCustomRole || source.dataset.entryLlnkCustomObject;
      if (!movableRoles.has(role)) return null;
      const toolbarObject = ["filter", "settings", "sort", "period"].includes(role);
      if (!toolbarObject && !target.closest("[data-entry-llnk-custom-resize]") && target.closest(interactiveSelector)) return null;
      return { source, role };
    };
    const onPointerDown = (event) => {
      if (!state.customModeEditing || event.button !== 0 || drag) return;
      const matched = sourceFromEvent(event.target);
      if (!matched) return;
      const { source, role } = matched;
      const entry = state.fallModeEntries.get(source);
      if (!entry) return;
      const metrics = state.customModeGridMetrics || getCustomModeGridMetrics();
      const measurement = measureCustomModeSources([source])[0];
      const layout = cloneCustomModeLayout(state.customModeDraftLayout);
      const resizeCorner = event.target.closest("[data-entry-llnk-custom-resize]")?.dataset.entryLlnkCustomResize || "";
      const anchor = CUSTOM_MODE_POST_ROLES.includes(role)
        ? { ...(layout[role] || customModeAnchorFromMeasurement(measurement, metrics, true)) }
        : { ...(layout.objects[role] || customModeAnchorFromMeasurement(measurement, metrics)) };
      drag = {
        source,
        role,
        entry,
        metrics,
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        anchor,
        width: measurement.width,
        height: measurement.height,
        baseTranslateX: entry.x,
        baseTranslateY: entry.y,
        resizeCorner,
        moved: Boolean(resizeCorner),
      };
      if (resizeCorner) {
        source.classList.add("entry-llnk-custom-resizing");
        source.style.zIndex = "1400";
        source.setPointerCapture?.(event.pointerId);
        event.preventDefault();
      }
    };
    const onPointerMove = (event) => {
      if (!drag || event.pointerId !== drag.pointerId) return;
      const deltaX = event.clientX - drag.startX;
      const deltaY = event.clientY - drag.startY;
      if (!drag.moved && Math.hypot(deltaX, deltaY) < 5) return;
      if (!drag.moved) {
        drag.moved = true;
        drag.source.classList.add("entry-llnk-custom-dragging");
        drag.source.style.zIndex = "1400";
        drag.source.setPointerCapture?.(event.pointerId);
      }
      const { metrics, resizeCorner } = drag;
      const livePostDrag = !resizeCorner && CUSTOM_MODE_POST_ROLES.includes(drag.role);
      if (livePostDrag) {
        queueLivePostLayout(drag, calculateDragAnchor(drag, event.clientX, event.clientY));
        event.preventDefault();
        return;
      }
      if (resizeCorner) {
        const west = resizeCorner.endsWith("w");
        const rawWidth = Math.max(metrics.cellX * 8, drag.width + (west ? -deltaX : deltaX));
        drag.source.style.setProperty("width", `${Math.round(rawWidth)}px`, "important");
        drag.source.style.setProperty("max-width", "none", "important");
        if (west) {
          drag.source.style.setProperty(
            "translate",
            `${Math.round(drag.baseTranslateX + deltaX)}px ${Math.round(drag.baseTranslateY)}px`,
            "important",
          );
        }
      } else {
        drag.source.style.setProperty(
          "translate",
          `${Math.round(drag.baseTranslateX + deltaX)}px ${Math.round(drag.baseTranslateY + deltaY)}px`,
          "important",
        );
      }
      event.preventDefault();
    };
    const releaseDrag = (event) => {
      if (!drag || (event && event.pointerId !== drag.pointerId)) return;
      const finished = drag;
      drag = null;
      finished.source.classList.remove("entry-llnk-custom-dragging", "entry-llnk-custom-resizing");
      finished.source.releasePointerCapture?.(finished.pointerId);
      if (finished.moved) {
        const livePostDrag = !finished.resizeCorner && CUSTOM_MODE_POST_ROLES.includes(finished.role);
        if (liveDragFrame) {
          window.cancelAnimationFrame(liveDragFrame);
          liveDragFrame = 0;
        }
        const anchor = calculateDragAnchor(
          finished,
          event?.clientX ?? finished.startX,
          event?.clientY ?? finished.startY,
        );
        if (!livePostDrag) {
          finished.source.style.setProperty(
            "translate",
            `${Math.round(finished.baseTranslateX)}px ${Math.round(finished.baseTranslateY)}px`,
            "important",
          );
        }
        updateDraftAnchor(finished.role, anchor);
        suppressClickSource = finished.source;
        suppressClickUntil = Date.now() + 450;
        applyLayoutNow();
        event?.preventDefault();
      }
    };
    const onClick = (event) => {
      if (state.customModeEditing && event.target instanceof Element) {
        const blockedSource = event.target.closest("[data-entry-llnk-custom-source='1']");
        const editControl = event.target.closest("[data-entry-llnk-custom-resize], [data-entry-llnk-custom-drag-handle]");
        if (blockedSource && !editControl) {
          event.preventDefault();
          event.stopImmediatePropagation();
          return;
        }
      }
      if (Date.now() > suppressClickUntil || !suppressClickSource?.contains(event.target)) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      suppressClickSource = null;
      suppressClickUntil = 0;
    };
    const observer = new MutationObserver((mutations) => {
      if (layoutApplying) return;
      const change = customModeMutationAffectsLayout(mutations);
      if (change.affected) queueLayout();
    });
    observer.observe(document.body, { childList: true, subtree: true });
    window.addEventListener("pointerdown", onPointerDown, true);
    window.addEventListener("pointermove", onPointerMove, true);
    window.addEventListener("pointerup", releaseDrag, true);
    window.addEventListener("pointercancel", releaseDrag, true);
    window.addEventListener("click", onClick, true);
    window.addEventListener("resize", queueLayout, { passive: true });
    document.addEventListener("visibilitychange", onVisibilityChange);
    state.fallModeInteractionCleanup = () => {
      window.removeEventListener("pointerdown", onPointerDown, true);
      window.removeEventListener("pointermove", onPointerMove, true);
      window.removeEventListener("pointerup", releaseDrag, true);
      window.removeEventListener("pointercancel", releaseDrag, true);
      window.removeEventListener("click", onClick, true);
      window.removeEventListener("resize", queueLayout);
      document.removeEventListener("visibilitychange", onVisibilityChange);
      if (liveDragFrame) window.cancelAnimationFrame(liveDragFrame);
      if (layoutReleaseFrame) window.cancelAnimationFrame(layoutReleaseFrame);
      layoutReleaseFrame = 0;
      layoutApplying = false;
      resizeObserver?.disconnect();
      resizeObservedSources.clear();
      observer.disconnect();
    };
    if (document.visibilityState === "visible") {
      applyLayoutNow();
    } else {
      layoutPendingWhileHidden = true;
    }
  }

  function syncFallMode({ replay = false } = {}) {
    if (!fallModeAllowed()) {
      removeFallModeStage();
      return;
    }
    if (replay) removeFallModeStage({ preserveEditing: true });
    if (state.fallModeActive || state.fallModeRunTimer) return;
    state.fallModeRunTimer = window.setTimeout(startFallMode, 120);
  }

  function syncLiveStoryToolbarScope() {
    document.documentElement.classList.toggle("entry-llnk-live-story-toolbar", isLiveEntryStoryPage());
  }

  function getImageShortLinkCode(value) {
    try {
      const url = value instanceof URL ? value : new URL(text(value).trim());
      if (url.protocol !== "https:") return "";
      if (url.hostname !== "llnk.kr") return "";
      const compactMatch = url.pathname.match(/^\/i([a-z0-9]{4})\/?$/i);
      const code = text(
        compactMatch?.[1] || (url.pathname === "/i.php" ? url.searchParams.get("c") : "") || ""
      ).toLowerCase();
      return /^[a-z0-9]{4}$/.test(code) ? code : "";
    } catch (_) {
      return "";
    }
  }

  function getBlouplaImageUrl(value) {
    try {
      const url = value instanceof URL ? new URL(value.href) : new URL(text(value).trim());
      if (url.protocol !== "https:" || url.hostname !== "img.bloupla.net" || url.port) return "";
      if (!/^\/[a-z0-9_-]{4,64}\/?$/i.test(url.pathname)) return "";
      url.pathname = url.pathname.replace(/\/$/, "");
      url.search = "";
      url.searchParams.set("raw", "1");
      url.hash = "";
      return url.href;
    } catch (_) {
      return "";
    }
  }

  function limitLineBreakMarkers(value) {
    const source = text(value);
    let output = "";
    let index = 0;
    let markerCount = 0;
    let consecutiveCount = 0;
    let inCode = false;
    while (index < source.length) {
      if (source[index] === "`" && source[index - 1] !== "\\") {
        inCode = !inCode;
        output += source[index];
        index += 1;
        consecutiveCount = 0;
        continue;
      }
      const isSpaceMarker = !inCode && source.startsWith(LINE_BREAK_MARKER, index);
      const isNewline = !inCode && (source[index] === "\n" || source[index] === "\r");
      const markerLength = isSpaceMarker
        ? LINE_BREAK_MARKER.length
        : (isNewline && source[index] === "\r" && source[index + 1] === "\n" ? 2 : (isNewline ? 1 : 0));
      if (markerLength) {
        markerCount += 1;
        consecutiveCount += 1;
        if (markerCount <= MAX_LINE_BREAKS && consecutiveCount <= 4) {
          output += source.slice(index, index + markerLength);
        } else {
          output += " ";
        }
        index += markerLength;
        continue;
      }
      output += source[index];
      index += 1;
      consecutiveCount = 0;
    }
    return output;
  }

  function appendPlainText(nodes, value) {
    if (!value) return;
    const previous = nodes[nodes.length - 1];
    if (previous?.nodeType === Node.TEXT_NODE) previous.textContent += value;
    else nodes.push(document.createTextNode(value));
  }

  function parseInline(source, context = null) {
    const value = text(source);
    const nodes = [];
    const renderContext = context || {};
    let index = 0;
    const specs = [
      ["__***", "***__", "ubi"], ["__**", "**__", "ub"], ["__*", "*__", "ui"],
      ["***", "***", "bi"], ["**", "**", "b"], ["__", "__", "u"],
      ["~~", "~~", "s"], ["||", "||", "spoiler"], ["`", "`", "code"], ["*", "*", "i"],
    ];
    while (index < value.length) {
      if (value[index] === " ") {
        let spaceEnd = index + 1;
        while (value[spaceEnd] === " ") spaceEnd += 1;
        const runLength = spaceEnd - index;
        const breakCount = Math.floor(runLength / LINE_BREAK_MARKER.length);
        const remainingSpaces = runLength % LINE_BREAK_MARKER.length;
        for (let count = 0; count < breakCount; count += 1) nodes.push(document.createElement("br"));
        appendPlainText(nodes, " ".repeat(remainingSpaces));
        index = spaceEnd;
        continue;
      }
      if (value[index] === "\n") {
        nodes.push(document.createElement("br"));
        index += 1;
        continue;
      }
      const disabledLabelLink = value.slice(index).match(/^\[[^\]\n]+\]\s*\(https?:\/\/[^\s)]+\)/i);
      if (disabledLabelLink) {
        appendPlainText(nodes, disabledLabelLink[0]);
        index += disabledLabelLink[0].length;
        continue;
      }
      const urlMatch = value.slice(index).match(/^https?:\/\/[^\s<>"']+/i);
      if (urlMatch) {
        let raw = urlMatch[0];
        const trailing = raw.match(/[.,!?;:)\]}]+$/)?.[0] || "";
        if (trailing) raw = raw.slice(0, -trailing.length);
        const url = safeHttpUrl(raw);
        if (url) {
          const pollCode = getPollShortLinkCode(url);
          if (pollCode) {
            nodes.push(createPublicPollCard({ code: pollCode, fallbackUrl: url.href }));
            if (trailing) appendPlainText(nodes, trailing);
            index += urlMatch[0].length;
            continue;
          }
          const imageCode = getImageShortLinkCode(url);
          if (imageCode) {
            nodes.push(createImageCard({ code: imageCode, fallbackUrl: url.href, source: "llnk" }));
            if (trailing) appendPlainText(nodes, trailing);
            index += urlMatch[0].length;
            continue;
          }
          const blouplaImageUrl = getBlouplaImageUrl(url);
          if (blouplaImageUrl) {
            nodes.push(createImageCard({ directUrl: blouplaImageUrl, fallbackUrl: url.href, source: "bloupla" }));
            if (trailing) appendPlainText(nodes, trailing);
            index += urlMatch[0].length;
            continue;
          }
          const link = document.createElement("a");
          link.className = "entry-chat-md-link entry-chat-message-link";
          link.href = url.href;
          link.target = "_blank";
          link.rel = "noopener noreferrer";
          link.textContent = isProjectUrl(url) ? "[작품 링크]" : raw;
          nodes.push(link);
          if (trailing) appendPlainText(nodes, trailing);
          index += urlMatch[0].length;
          continue;
        }
      }
      let formatted = false;
      for (const [open, close, type] of specs) {
        if (!value.startsWith(open, index)) continue;
        const end = value.indexOf(close, index + open.length);
        if (end <= index + open.length) continue;
        const element = document.createElement(type === "code" ? "code" : "span");
        element.className = `entry-chat-md-${type}`;
        const inner = value.slice(index + open.length, end);
        if (type === "code") element.textContent = inner;
        else parseInline(inner, renderContext).forEach((child) => element.appendChild(child));
        if (type === "spoiler") {
          element.tabIndex = 0;
          element.setAttribute("role", "button");
          element.setAttribute("aria-label", "스포일러 보기");
          const reveal = () => element.classList.add("is-revealed");
          element.addEventListener("click", reveal);
          element.addEventListener("keydown", (event) => {
            if (event.key === "Enter" || event.key === " ") {
              event.preventDefault();
              reveal();
            }
          });
        }
        nodes.push(element);
        index = end + close.length;
        formatted = true;
        break;
      }
      if (formatted) continue;
      appendPlainText(nodes, value[index]);
      index += 1;
    }
    return nodes;
  }

  function createImageCard(marker) {
    const card = document.createElement("span");
    card.className = "entry-chat-image-card";
    card.dataset.entryLlnkOwned = "1";
    card.dataset.entryLlnkLazyType = "image";
    card.dataset.entryLlnkCode = marker.code || "";
    card.dataset.entryLlnkDirectUrl = marker.directUrl || "";
    card.dataset.entryLlnkFallbackUrl = marker.fallbackUrl || marker.directUrl || "";
    card.dataset.entryLlnkSource = marker.source || "";
    const loading = document.createElement("span");
    loading.className = "entry-chat-image-loading";
    loading.textContent = "이미지 불러오는 중…";
    card.appendChild(loading);
    observeLazyCard(card);
    return card;
  }

  function getPollShortLinkCode(value) {
    try {
      const url = value instanceof URL ? value : new URL(text(value).trim());
      if (url.protocol !== "https:" || url.hostname.toLowerCase() !== "llnk.kr") return "";
      return url.pathname.match(/^\/([vq][a-z0-9]{7})\/?$/i)?.[1]?.toLowerCase() || "";
    } catch (_) {
      return "";
    }
  }

  function createPublicPollCard(marker) {
    const card = document.createElement("span");
    card.className = "entry-chat-poll-card";
    card.dataset.entryLlnkOwned = "1";
    card.dataset.entryLlnkLazyType = "poll";
    card.dataset.entryLlnkCode = marker.code || "";
    card.dataset.entryLlnkFallbackUrl = marker.fallbackUrl || "";
    const loading = document.createElement("span");
    loading.className = "entry-chat-poll-loading";
    loading.textContent = marker.code?.startsWith("q") ? "퀴즈 불러오는 중…" : "투표 불러오는 중…";
    card.appendChild(loading);
    observeLazyCard(card);
    return card;
  }

  function showImageFallbackLink(card) {
    if (!card) return false;
    const original = text(card.dataset.entryLlnkFallbackUrl).trim();
    const safe = safeHttpUrl(original);
    if (!safe) return false;
    const link = document.createElement("a");
    link.className = "entry-chat-md-link entry-chat-message-link entry-chat-image-fallback-link";
    link.href = safe.href;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = original;
    link.addEventListener("click", (event) => event.stopPropagation());
    card.className = "entry-chat-image-fallback";
    card.style.removeProperty("width");
    card.replaceChildren(link);
    return true;
  }

  function createImageSourceBadge(source) {
    const badge = document.createElement("span");
    const isBloupla = source === "bloupla";
    const label = isBloupla ? "Bloupla" : "Llnkkr";
    badge.className = `entry-chat-image-source-badge ${isBloupla ? "is-bloupla" : "is-llnk"}`;
    badge.textContent = label;
    badge.setAttribute("aria-label", `${label} 이미지`);
    return badge;
  }

  async function loadPollSelections() {
    if (state.pollSelections) return state.pollSelections;
    const saved = await Ringcl.storageGet([POLL_SELECTION_STORAGE_KEY]).catch(() => ({}));
    const value = saved?.[POLL_SELECTION_STORAGE_KEY];
    state.pollSelections = value && typeof value === "object" && !Array.isArray(value) ? { ...value } : {};
    return state.pollSelections;
  }

  async function rememberPollSelection(code, optionId) {
    const selections = await loadPollSelections();
    selections[code] = Number(optionId);
    await Ringcl.storageSet({ [POLL_SELECTION_STORAGE_KEY]: selections }).catch(() => {});
  }

  function showPollFallbackLink(card) {
    const original = text(card?.dataset?.entryLlnkFallbackUrl).trim();
    const safe = safeHttpUrl(original);
    if (!card || !safe) return false;
    const link = document.createElement("a");
    link.className = "entry-chat-md-link entry-chat-message-link entry-chat-poll-fallback-link";
    link.href = safe.href;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = original;
    link.addEventListener("click", (event) => event.stopPropagation());
    card.className = "entry-chat-poll-fallback";
    card.replaceChildren(link);
    return true;
  }

  async function renderPublicPoll(card, poll, message = "") {
    if (!card || !poll?.code || !Array.isArray(poll.options)) return;
    const isQuiz = poll.type === "quiz" || text(poll.code).startsWith("q");
    const contentLabel = isQuiz ? "퀴즈" : "투표";
    const selections = await loadPollSelections();
    const hasServerSelection = Object.prototype.hasOwnProperty.call(poll, "selected_option_id");
    const selectedOptionId = hasServerSelection
      ? Number(poll.selected_option_id || 0)
      : Number(selections[poll.code] || 0);
    const showResults = Boolean(poll.has_voted && selectedOptionId > 0);
    const legacyVote = Boolean(poll.has_voted && selectedOptionId < 1);
    const correctOptionId = Number(poll.correct_option_id || 0);
    let requestPending = false;
    const shell = document.createElement("span");
    shell.className = "entry-chat-poll-shell";
    const heading = document.createElement("span");
    heading.className = "entry-chat-poll-heading";
    const icon = createComposeIcon(isQuiz ? "quiz" : "how_to_vote", "entry-chat-poll-heading-icon");
    const question = document.createElement("strong");
    question.textContent = text(poll.question);
    const open = document.createElement("a");
    open.className = "entry-chat-poll-open";
    open.href = safeHttpUrl(poll.short_url)?.href || card.dataset.entryLlnkFallbackUrl;
    open.target = "_blank";
    open.rel = "noopener noreferrer";
    open.title = `${contentLabel} 페이지 열기`;
    open.setAttribute("aria-label", `${contentLabel} 페이지 열기`);
    open.appendChild(createComposeIcon("open_in_new", "entry-chat-poll-open-icon"));
    open.addEventListener("click", (event) => event.stopPropagation());
    heading.append(icon, question, open);
    const options = document.createElement("span");
    options.className = "entry-chat-poll-options";
    const status = document.createElement("span");
    status.className = "entry-chat-poll-status";
    const totalVotes = Math.max(0, Number(poll.total_votes) || 0);
    poll.options.forEach((option) => {
      const optionId = Number(option.id);
      const isCorrect = isQuiz && correctOptionId === optionId;
      const isIncorrect = isQuiz && correctOptionId > 0 && correctOptionId !== optionId;
      const button = document.createElement("button");
      button.type = "button";
      button.className = "entry-chat-poll-option";
      button.disabled = legacyVote || (isQuiz && Boolean(poll.has_voted));
      button.classList.toggle("has-results", showResults);
      button.classList.toggle("is-selected", selectedOptionId === optionId);
      button.classList.toggle("is-correct", isCorrect);
      button.classList.toggle("is-incorrect", isIncorrect);
      button.setAttribute("aria-pressed", selectedOptionId === optionId ? "true" : "false");
      const percentage = totalVotes > 0 ? Math.round((Number(option.votes) || 0) / totalVotes * 100) : 0;
      const bar = document.createElement("span");
      bar.className = "entry-chat-poll-option-bar";
      bar.style.width = showResults ? `${percentage}%` : "0";
      const marker = document.createElement("span");
      marker.className = "entry-chat-poll-option-marker";
      marker.setAttribute("aria-hidden", "true");
      if (isCorrect || isIncorrect) {
        marker.classList.add("is-quiz-result", isCorrect ? "is-correct" : "is-incorrect");
        marker.appendChild(createComposeIcon(isCorrect ? "circle" : "close", "entry-chat-poll-result-icon"));
      }
      const label = document.createElement("span");
      label.className = "entry-chat-poll-option-label";
      label.textContent = text(option.label);
      const count = document.createElement("span");
      count.className = "entry-chat-poll-option-count";
      count.textContent = `${percentage}% · ${Number(option.votes) || 0}표`;
      button.append(bar, marker, label, count);
      button.addEventListener("click", async (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (button.disabled || requestPending) return;
        if (isQuiz && poll.has_voted) {
          status.textContent = "이미 참여했습니다.";
          status.classList.remove("is-error");
          return;
        }
        if (selectedOptionId === Number(option.id)) {
          status.textContent = "이미 참여했습니다.";
          status.classList.remove("is-error");
          return;
        }
        requestPending = true;
        $$(".entry-chat-poll-option", options).forEach((item) => { item.disabled = true; });
        status.textContent = isQuiz ? "정답 확인 중…" : (selectedOptionId > 0 ? "선택 변경 중…" : "투표 중…");
        status.classList.remove("is-error");
        try {
          const payload = await Ringcl.api("polls.php", {
            method: "POST",
            body: { action: "vote", code: poll.code, option_id: Number(option.id) },
          });
          await rememberPollSelection(poll.code, Number(option.id));
          const resultMessage = isQuiz
            ? (payload.poll?.is_correct ? "정답입니다." : "오답입니다.")
            : (selectedOptionId > 0 ? "선택을 변경했습니다." : "투표했습니다.");
          await renderPublicPoll(card, payload.poll, resultMessage);
        } catch (error) {
          if (error?.status === 409) {
            const payload = await Ringcl.api(`polls.php?code=${encodeURIComponent(poll.code)}`);
            await renderPublicPoll(card, payload.poll, "이미 참여했습니다.");
            return;
          }
          requestPending = false;
          $$(".entry-chat-poll-option", options).forEach((item) => { item.disabled = false; });
          status.textContent = error?.message || `${contentLabel}에 참여하지 못했습니다.`;
          status.classList.add("is-error");
        }
      });
      options.appendChild(button);
    });
    if (message) status.textContent = message;
    else if (isQuiz && poll.has_voted && correctOptionId > 0) status.textContent = poll.is_correct ? "정답입니다." : "오답입니다.";
    else if (legacyVote) status.textContent = "이미 참여했습니다.";
    else if (showResults) status.textContent = `총 ${totalVotes}표`;
    else status.textContent = `총 ${totalVotes}표`;
    shell.append(heading, options, status);
    card.replaceChildren(shell);
    card.dataset.entryLlnkPollRendered = "1";
  }

  function renderContent(source) {
    const value = limitLineBreakMarkers(source);
    return parseInline(value);
  }

  function hasRenderableSyntax(value) {
    return IMAGE_SHORT_LINK_RE.test(value)
      || POLL_SHORT_LINK_RE.test(value)
      || /( {3}|\*[^*\n]+\*|\*\*|__|~~|`|\|\||https?:\/\/)/iu.test(value);
  }

  function imageShortLinkFromAnchor(anchor) {
    try {
      const href = text(anchor?.getAttribute?.("href") || "").trim();
      if (!href) return "";
      const url = new URL(href, location.origin);
      const target = url.hostname === "playentry.org" && url.pathname === "/redirect"
        ? new URL(text(url.searchParams.get("external") || "").trim())
        : url;
      return getImageShortLinkCode(target) || getBlouplaImageUrl(target) ? target.href : "";
    } catch (_) {
      return "";
    }
  }

  function postBodySource(body) {
    const ownsRenderedBody = body?.dataset?.entryLlnkOwned === "1"
      || body?.classList?.contains("entry-chat-markdown-rendered");
    const saved = ownsRenderedBody
      ? text(body?.dataset?.entryChatLiveRaw || body?.dataset?.entryLlnkOriginal || "").trim()
      : "";
    if (saved) return saved;
    const clone = body?.cloneNode?.(true);
    if (!clone) return "";
    $$('a[href]', clone).forEach((anchor) => {
      const shortLink = imageShortLinkFromAnchor(anchor);
      if (shortLink) anchor.textContent = shortLink;
      if (anchor.dataset.entryLlnkProjectLink === "1") {
        anchor.textContent = anchor.dataset.entryLlnkProjectOriginalText || anchor.getAttribute("href") || anchor.textContent;
      }
    });
    return text(clone.textContent).trim();
  }

  function isExtensionOwnedPostBody(body) {
    return body?.dataset?.entryLlnkOwned === "1"
      || body?.dataset?.entryChatLiveBody === "1";
  }

  function nativePostRenderLayer(body) {
    body.style.removeProperty("--entry-llnk-native-color");
    let layer = body.querySelector(":scope > .entry-llnk-native-render-layer");
    if (layer) return layer;
    const computed = getComputedStyle(body);
    body.style.setProperty("--entry-llnk-native-font-size", computed.fontSize || "14px");
    body.style.setProperty("--entry-llnk-native-line-height", computed.lineHeight === "normal" ? "1.5" : computed.lineHeight);
    layer = document.createElement("span");
    layer.className = "entry-llnk-native-render-layer";
    layer.dataset.entryLlnkOwned = "1";
    body.appendChild(layer);
    return layer;
  }

  function renderNativePostBody(body, value) {
    const layer = nativePostRenderLayer(body);
    layer.replaceChildren(...renderContent(value));
    body.classList.add("entry-chat-markdown-rendered", "entry-llnk-native-render-host");
  }

  function renderPostBody(body, source, force = false) {
    const value = text(source).trim();
    if (!body || !value) return false;
    const signature = `${value.length}:${value.slice(0, 80)}:${value.slice(-40)}`;
    const ownedBody = isExtensionOwnedPostBody(body);
    const nativeLayer = ownedBody ? null : body.querySelector(":scope > .entry-llnk-native-render-layer");
    if (
      body.dataset.entryLlnkSignature === signature
      && body.dataset.entryChatLiveRaw === value
      && (ownedBody || nativeLayer || !hasRenderableSyntax(value))
    ) return false;
    body.dataset.entryLlnkSignature = signature;
    body.dataset.entryChatLiveRaw = value;
    if (hasRenderableSyntax(value)) {
      body.dataset.entryLlnkOriginal = value;
      if (ownedBody) {
        body.replaceChildren(...renderContent(value));
        body.classList.add("entry-chat-markdown-rendered");
      } else {
        renderNativePostBody(body, value);
      }
    } else if (force) {
      if (ownedBody) {
        body.textContent = value;
        body.classList.remove("entry-chat-markdown-rendered");
        delete body.dataset.entryLlnkOriginal;
      } else {
        renderNativePostBody(body, value);
        body.dataset.entryLlnkOriginal = value;
      }
    }
    return true;
  }

  function scheduleWriterPreview(delay = 90) {
    window.clearTimeout(state.writerPreviewTimer);
    state.writerPreviewTimer = window.setTimeout(renderWriterPreview, delay);
  }

  function ensureWriterPreview(writer) {
    const holder = writer?.closest?.(".css-11v8s45, [class~='ed0ret11']") || writer?.parentElement;
    if (!holder) return null;
    let preview = $(".entry-chat-md-preview", holder);
    if (!preview) {
      preview = document.createElement("div");
      preview.className = "entry-chat-md-preview";
      preview.dataset.entryLlnkOwned = "1";
      holder.appendChild(preview);
    }
    preview.classList.add("entry-rich-unified-preview");
    return preview;
  }

  function hideWriterPreview(preview) {
    if (!preview) return;
    if (!preview.classList.contains("is-visible") && !preview.childNodes.length) {
      delete preview.dataset.entryChatPreviewValue;
      delete preview.dataset.entryRichOwned;
      return;
    }
    preview.replaceChildren();
    preview.classList.remove("is-visible");
    delete preview.dataset.entryChatPreviewValue;
    delete preview.dataset.entryRichOwned;
  }

  function renderWriterPreview() {
    const writer = getWriter();
    if (!writer || writer.closest(".entry-chat-root")) return;
    const preview = ensureWriterPreview(writer);
    if (!preview) return;
    const value = encodedPostValue(writer.value);
    if (!value || !hasRenderableSyntax(value)) {
      hideWriterPreview(preview);
      return;
    }
    const previewValue = value;
    if (!previewValue || !hasRenderableSyntax(previewValue)) {
      hideWriterPreview(preview);
      return;
    }
    if (preview.dataset.entryChatPreviewValue === previewValue && preview.classList.contains("is-visible")) return;
    preview.dataset.entryRichOwned = "1";
    preview.dataset.entryChatPreviewValue = previewValue;
    preview.replaceChildren(...renderContent(previewValue));
    preview.classList.add("is-visible");
  }

  function processStoryBody(body) {
    if (!body || body.closest("[data-entry-llnk-owned='1']")) return false;
    const source = postBodySource(body);
    if (!source) return false;
    return renderPostBody(body, source);
  }

  function processPost(post) {
    if (!(post instanceof Element) || post.closest(".entry-chat-root")) return;
    const bodies = post.matches(BODY_SELECTOR) ? [post] : $$(BODY_SELECTOR, post);
    if (!bodies.length) return;
    bodies.forEach(processStoryBody);
    shortenProjectLinks(post);
    applyStoryFilters(post);
  }

  function processRoot(root = document, options = {}) {
    syncLiveStoryToolbarScope();
    if (!isEntryStoryPage()) {
      removeScrollTopButton();
      removeFallModeStage();
      document.documentElement.classList.remove("entry-chat-image-spoiler-enabled");
      stopLiveRefresh();
      return;
    }
    if (!isFallModePage()) removeFallModeStage();
    document.documentElement.classList.add("entry-chat-page-entrystory", "entry-chat-image-spoiler-enabled");
    const posts = [];
    if (root instanceof Element) {
      const owner = root.matches(POST_SELECTOR) ? root : root.closest(POST_SELECTOR);
      if (owner) posts.push(owner);
    }
    posts.push(...$$(POST_SELECTOR, root));
    [...new Set(posts)].slice(0, 160).forEach(processPost);
    syncMetricCounters(root);
    openPendingLiveReply();
    if (!options.skipPageUi) {
      ensureWriterTools();
      ensureScrollTopButton();
      ensureStoryFilterMenu();
      if (state.fallModeEnabled) syncFallMode();
      if (isEntryStoryListPage()) startLiveRefresh();
      else stopLiveRefresh();
    }
  }

  function isProjectUrl(url) {
    return url?.hostname === "playentry.org" && /^\/project\/[a-f0-9]{24}(?:\/|$)/i.test(url.pathname);
  }

  function shortenProjectLinks(root = document) {
    if (!state.shortenProjectLinksEnabled) {
      $$('a[href]', root).slice(0, 200).forEach((link) => {
        const url = safeHttpUrl(link.getAttribute("href"));
        const wasShortened = link.dataset.entryLlnkProjectLink === "1" || text(link.textContent).trim() === "[작품 링크]";
        if (!isProjectUrl(url) || !wasShortened) return;
        const original = text(link.dataset.entryLlnkProjectOriginalText).trim();
        link.textContent = original && original !== "[작품 링크]" ? original : (url?.href || link.textContent);
        link.classList.remove("entry-chat-short-project-link", "entry-chat-md-link");
        if (link.dataset.entryLlnkProjectHadTarget === "1") link.setAttribute("target", link.dataset.entryLlnkProjectOriginalTarget || "");
        else link.removeAttribute("target");
        if (link.dataset.entryLlnkProjectHadRel === "1") link.setAttribute("rel", link.dataset.entryLlnkProjectOriginalRel || "");
        else link.removeAttribute("rel");
      });
      return;
    }
    $$('a[href]', root).slice(0, 200).forEach((link) => {
      const url = safeHttpUrl(link.getAttribute("href"));
      if (!isProjectUrl(url) || link.querySelector("img, video, canvas, button")) return;
      if (link.dataset.entryLlnkProjectLink === "1") {
        link.textContent = "[작품 링크]";
        link.classList.add("entry-chat-short-project-link", "entry-chat-md-link");
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        return;
      }
      const label = text(link.textContent).trim();
      if (label !== "[작품 링크]" && !/(?:https?:\/\/)?(?:www\.)?playentry\.org\/project\//i.test(label) && !/^\/project\//i.test(label)) return;
      link.dataset.entryLlnkProjectLink = "1";
      link.dataset.entryLlnkProjectOriginalText = label === "[작품 링크]" ? url.href : (link.textContent || "");
      link.dataset.entryLlnkProjectHadTarget = link.hasAttribute("target") ? "1" : "0";
      link.dataset.entryLlnkProjectOriginalTarget = link.getAttribute("target") || "";
      link.dataset.entryLlnkProjectHadRel = link.hasAttribute("rel") ? "1" : "0";
      link.dataset.entryLlnkProjectOriginalRel = link.getAttribute("rel") || "";
      link.textContent = "[작품 링크]";
      link.classList.add("entry-chat-short-project-link", "entry-chat-md-link");
      link.target = "_blank";
      link.rel = "noopener noreferrer";
    });
  }

  function normalizeStoryFilterRule(value) {
    return text(value).normalize("NFC").replace(/\s+/g, " ").trim().slice(0, 50);
  }

  function normalizeStoryFilterRuleList(value) {
    if (!Array.isArray(value)) return [];
    const seen = new Set();
    return value.reduce((rules, item) => {
      const rule = normalizeStoryFilterRule(item);
      const comparable = rule.toLocaleLowerCase("ko-KR");
      if (!rule || seen.has(comparable) || rules.length >= 50) return rules;
      seen.add(comparable);
      rules.push(rule);
      return rules;
    }, []);
  }

  function storyFilterComparable(value) {
    return text(value).normalize("NFC").replace(/\s+/g, " ").trim().toLocaleLowerCase("ko-KR");
  }

  function normalizeStoryFilters(value, legacyHidePromotions = true) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      return {
        ...DEFAULT_STORY_FILTERS,
        projectLinks: legacyHidePromotions !== false,
        blockedWords: [],
        blockedNicknames: [],
      };
    }
    const filters = Object.fromEntries(STORY_FILTER_OPTIONS.map(({ key }) => [key, value[key] === true]));
    filters.blockedWords = normalizeStoryFilterRuleList(value.blockedWords);
    filters.blockedNicknames = normalizeStoryFilterRuleList(value.blockedNicknames);
    if (filters.allLinks) {
      filters.entryLinks = true;
      filters.projectLinks = true;
      filters.externalLinks = true;
      filters.naverShortLinks = true;
    } else if (filters.entryLinks) {
      filters.projectLinks = true;
    } else if (filters.externalLinks) {
      filters.naverShortLinks = true;
    }
    return filters;
  }

  function hasActiveStoryFilters() {
    return STORY_FILTER_OPTIONS.some(({ key }) => state.storyFilters[key])
      || state.storyFilters.blockedWords.length > 0
      || state.storyFilters.blockedNicknames.length > 0;
  }

  function normalizePageSettings(value) {
    const settings = value && typeof value === "object" && !Array.isArray(value) ? value : {};
    const normalized = Object.fromEntries(Object.entries(DEFAULT_PAGE_SETTINGS).map(([key, defaultValue]) => [
      key,
      typeof settings[key] === "boolean" ? settings[key] : defaultValue,
    ]));
    if (normalized.fallMode) normalized.spaceshipMotion = false;
    return normalized;
  }

  function storyFilterUrlFromAnchor(link) {
    const url = safeHttpUrl(link?.getAttribute?.("href"));
    if (!url) return null;
    if ((url.hostname === "playentry.org" || url.hostname.endsWith(".playentry.org")) && url.pathname === "/redirect") {
      return safeHttpUrl(url.searchParams.get("external")) || url;
    }
    return url;
  }

  function storyFilterContent(post) {
    const body = $(BODY_SELECTOR, post) || $("[data-entry-chat-live-body='1']", post) || post;
    const urls = $$('a[href]', body)
      .filter((link) => !(
        link.matches(".entry-chat-image-link")
        || link.closest(".entry-chat-image-card")
        || link.querySelector("img, .entry-chat-bloupla-image-host")
      ))
      .map(storyFilterUrlFromAnchor)
      .filter(Boolean);
    const hasProjectLink = urls.some(isProjectUrl);
    const hasEntryLink = urls.some((url) => url.hostname === "playentry.org" || url.hostname.endsWith(".playentry.org"));
    const hasExternalLink = urls.some((url) => url.hostname !== "playentry.org" && !url.hostname.endsWith(".playentry.org"));
    const hasNaverShortLink = urls.some((url) => url.hostname === "naver.me" || url.hostname.endsWith(".naver.me"));
    const hasImage = Boolean(
      $(".entry-chat-image-card", body)
      || $("[data-entry-chat-live-media='1']:not(.is-native-reaction) img", post)
      || $(".entry-chat-live-entry-story-media:not(.is-native-reaction) img", post)
    );
    const hasEntryEmoticon = Boolean(
      $("[data-entry-chat-live-media='1'].is-native-reaction img", post)
      || $(".entry-chat-live-entry-story-media.is-native-reaction img", post)
      || $("img[alt='sticker']", post)
    );
    const author = $("[data-entry-chat-live-nickname='1']", post)
      || $("[class~='e143sozh0'] > a[href*='/profile/']", post)
      || $$('a[href*="/profile/"]', post).find((link) => !link.closest(BODY_SELECTOR) && text(link.textContent).trim());
    return {
      hasProjectLink,
      hasEntryLink,
      hasExternalLink,
      hasNaverShortLink,
      hasLink: urls.length > 0,
      hasImage,
      hasEntryEmoticon,
      bodyText: storyFilterComparable(body.textContent),
      authorNickname: storyFilterComparable(author?.textContent),
    };
  }

  function applyStoryFilters(post) {
    if (!isLiveEntryStoryPage()) {
      post?.classList?.remove("entry-chat-entry-story-link-filtered");
      return false;
    }
    const content = storyFilterContent(post);
    const shouldHide = Boolean(
      (state.storyFilters.projectLinks && content.hasProjectLink)
      || (state.storyFilters.entryLinks && content.hasEntryLink)
      || (state.storyFilters.externalLinks && content.hasExternalLink)
      || (state.storyFilters.naverShortLinks && content.hasNaverShortLink)
      || (state.storyFilters.allLinks && content.hasLink)
      || (state.storyFilters.images && content.hasImage)
      || (state.storyFilters.entryEmoticons && content.hasEntryEmoticon)
      || state.storyFilters.blockedWords.some((rule) => content.bodyText.includes(storyFilterComparable(rule)))
      || state.storyFilters.blockedNicknames.some((rule) => content.authorNickname === storyFilterComparable(rule))
    );
    post.classList.toggle("entry-chat-entry-story-link-filtered", shouldHide);
    $(":scope > .entry-chat-link-filter-placeholder", post)?.remove();
    return shouldHide;
  }

  function isStoryPostFiltered(post) {
    return isLiveEntryStoryPage()
      && post?.classList?.contains("entry-chat-entry-story-link-filtered") === true;
  }

  async function saveStoryFilters() {
    const saved = await Ringcl.storageGet(["entryLlnkSettings"]).catch(() => ({}));
    await Ringcl.storageSet({
      entryLlnkSettings: {
        ...(saved.entryLlnkSettings || {}),
        storyFilters: { ...state.storyFilters },
        hidePromotions: state.storyFilters.projectLinks,
      },
    }).catch(() => {});
  }

  function storyFilterDescendants(key) {
    const descendants = [];
    const visit = (parentKey) => {
      const children = STORY_FILTER_OPTION_MAP.get(parentKey)?.children || [];
      children.forEach((childKey) => {
        descendants.push(childKey);
        visit(childKey);
      });
    };
    visit(key);
    return descendants;
  }

  function storyFilterAncestors(key) {
    const ancestors = [];
    let parent = STORY_FILTER_OPTION_MAP.get(key)?.parent || "";
    while (parent) {
      ancestors.push(parent);
      parent = STORY_FILTER_OPTION_MAP.get(parent)?.parent || "";
    }
    return ancestors;
  }

  function setStoryFilterEnabled(key, enabled) {
    state.storyFilters[key] = enabled;
    storyFilterDescendants(key).forEach((childKey) => {
      state.storyFilters[childKey] = enabled;
    });
    if (!enabled) {
      storyFilterAncestors(key).forEach((parentKey) => {
        state.storyFilters[parentKey] = false;
      });
    }
  }

  function setStoryToolbarPanelOpen(panel, button, open) {
    panel.hidden = !open;
    panel.classList.toggle("is-open", open);
    button.classList.toggle("entry-llnk-toolbar-menu-open", open);
    button.setAttribute("aria-expanded", open ? "true" : "false");
    if (open) {
      positionStoryToolbarPanel(panel, button);
      window.requestAnimationFrame(() => {
        if (!panel.hidden && panel.isConnected && button.isConnected) positionStoryToolbarPanel(panel, button);
      });
    }
    const kind = button.matches?.("[data-entry-llnk-link-filter='1']")
      ? "filter"
      : button.matches?.("[data-entry-llnk-story-settings='1']") ? "settings" : "";
    if (open && kind) state.storyToolbarOpenPanel = kind;
    else if (!open && state.storyToolbarOpenPanel === kind) state.storyToolbarOpenPanel = "";
  }

  function isStoryToolbarMenuOpen() {
    if ($(
      "[data-entry-llnk-link-filter='1'][aria-expanded='true'], "
      + "[data-entry-llnk-story-settings='1'][aria-expanded='true']",
    )) return true;
    return $$('[class~="e7o4zqs0"]').some((panel) => {
      if (!panel.closest('[class~="e1lgujxn8"]') || panel.closest(".entry-chat-root")) return false;
      const style = window.getComputedStyle(panel);
      return !panel.hidden && style.display !== "none" && style.visibility !== "hidden";
    });
  }

  function closeStoryToolbarPanels(exceptButton = null) {
    [
      ["[data-entry-llnk-story-filter-panel='1']", "[data-entry-llnk-link-filter='1']"],
      ["[data-entry-llnk-story-settings-panel='1']", "[data-entry-llnk-story-settings='1']"],
    ].forEach(([panelSelector, buttonSelector]) => {
      const panel = $(panelSelector);
      const button = $(buttonSelector);
      if (!panel || !button || button === exceptButton || panel.hidden) return;
      setStoryToolbarPanelOpen(panel, button, false);
    });
  }

  function bindStoryFilterMenuEvents() {
    if (state.storyFilterEventsBound) return;
    state.storyFilterEventsBound = true;
    document.addEventListener("pointerdown", (event) => {
      const insideToolbarMenu = event.target.closest?.(
        "[data-entry-llnk-story-filter-panel='1'], [data-entry-llnk-story-settings-panel='1'], "
        + "[data-entry-llnk-link-filter='1'], [data-entry-llnk-story-settings='1']",
      );
      if (!insideToolbarMenu) closeStoryToolbarPanels();
    }, true);
    document.addEventListener("keydown", (event) => {
      if (event.key !== "Escape") return;
      const openButton = [
        $("[data-entry-llnk-link-filter='1'][aria-expanded='true']"),
        $("[data-entry-llnk-story-settings='1'][aria-expanded='true']"),
      ].find(Boolean);
      if (!openButton) return;
      closeStoryToolbarPanels();
      openButton.focus();
    });
  }

  function syncNativeStorySortOpenState() {
    if (!isEntryStoryListPage()) return;
    const toolbar = getStorySortToolbarContainer();
    if (!toolbar) return;
    $$('[class~="elhpwdj0"]', toolbar).forEach((wrapper) => {
      const button = $(':scope > [class~="elhpwdj1"]', wrapper);
      const panel = $(':scope > [class~="e7o4zqs0"]', wrapper);
      if (!button || !panel) return;
      const panelStyle = window.getComputedStyle(panel);
      const open = !panel.hidden && panelStyle.display !== "none" && panelStyle.visibility !== "hidden";
      wrapper.classList.toggle("entry-llnk-native-sort-open", open);
      wrapper.classList.toggle("entry-llnk-toolbar-menu-open", open);
      button.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  function bindNativeStorySortEvents() {
    if (state.storyNativeSortEventsBound) return;
    state.storyNativeSortEventsBound = true;
    const scheduleSync = () => {
      window.requestAnimationFrame(() => {
        syncNativeStorySortOpenState();
        window.setTimeout(syncNativeStorySortOpenState, 40);
      });
    };
    document.addEventListener("click", scheduleSync, true);
    document.addEventListener("keyup", (event) => {
      if (event.key === "Enter" || event.key === " " || event.key === "Escape") scheduleSync();
    }, true);
  }

  function bindReplyFoldScrollStabilizer() {
    if (state.replyFoldEventsBound) return;
    state.replyFoldEventsBound = true;
    document.addEventListener("click", (event) => {
      const button = event.target.closest?.('a[class~="e1qasnlc3"]');
      const post = button?.closest?.('li[class~="eqmdslz0"]');
      if (!button || !post || !isVisible(button)) return;
      const anchorTop = post.getBoundingClientRect().top;
      const correct = () => {
        if (!post.isConnected) return;
        const delta = post.getBoundingClientRect().top - anchorTop;
        if (Math.abs(delta) > 0.5) window.scrollBy(0, delta);
      };
      window.requestAnimationFrame(() => {
        correct();
        window.requestAnimationFrame(correct);
      });
      [80, 180, 320].forEach((delay) => window.setTimeout(correct, delay));
    }, true);
  }

  function createStoryToolbarButton(className, dataKey, label, iconName) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `entry-chat-story-toolbar-toggle ${className}`;
    button.dataset[dataKey] = "1";
    button.dataset.entryLlnkOwned = "1";
    button.setAttribute("aria-haspopup", "dialog");
    button.setAttribute("aria-expanded", "false");

    const icon = document.createElement("span");
    icon.className = "material-symbols-outlined entry-chat-story-toolbar-icon";
    icon.setAttribute("aria-hidden", "true");
    icon.textContent = iconName;
    const textNode = document.createElement("span");
    textNode.className = "entry-chat-story-toolbar-label";
    textNode.textContent = label;
    const caret = document.createElement("span");
    caret.className = "entry-chat-story-toolbar-caret";
    caret.setAttribute("aria-hidden", "true");
    button.append(icon, textNode, caret);
    return button;
  }

  function createStoryFilterHeading(titleText, backView = "", reset = false) {
    const heading = document.createElement("div");
    heading.className = "entry-chat-story-filter-heading";
    if (backView) {
      const back = document.createElement("button");
      back.type = "button";
      back.className = "entry-chat-story-filter-heading-button";
      back.dataset.storyFilterBack = backView;
      back.setAttribute("aria-label", "뒤로");
      const icon = document.createElement("span");
      icon.className = "material-symbols-outlined";
      icon.setAttribute("aria-hidden", "true");
      icon.textContent = "arrow_back";
      back.appendChild(icon);
      heading.appendChild(back);
    }
    const title = document.createElement("strong");
    title.textContent = titleText;
    heading.appendChild(title);
    if (reset) {
      const resetButton = document.createElement("button");
      resetButton.type = "button";
      resetButton.className = "entry-chat-story-filter-heading-button entry-chat-story-filter-reset";
      resetButton.dataset.storyFilterReset = "1";
      resetButton.setAttribute("aria-label", "필터 초기화");
      resetButton.title = "필터 초기화";
      const icon = document.createElement("span");
      icon.className = "material-symbols-outlined";
      icon.setAttribute("aria-hidden", "true");
      icon.textContent = "restart_alt";
      resetButton.appendChild(icon);
      heading.appendChild(resetButton);
    }
    return heading;
  }

  function createStoryFilterSwitchRow(key, label, depth = 0, startsSection = false) {
    const row = document.createElement("button");
    row.type = "button";
    row.className = "entry-chat-story-filter-option";
    row.classList.toggle("starts-section", startsSection);
    row.classList.add(`is-depth-${Math.max(0, Math.min(2, depth))}`);
    row.dataset.storyFilterKey = key;
    row.dataset.storyFilterDepth = String(depth);
    row.setAttribute("role", "switch");
    const copy = document.createElement("span");
    copy.className = "entry-chat-story-filter-copy";
    const name = document.createElement("strong");
    name.textContent = label;
    copy.appendChild(name);
    const control = document.createElement("span");
    control.className = "entry-chat-story-filter-switch";
    control.setAttribute("aria-hidden", "true");
    control.appendChild(document.createElement("i"));
    row.append(copy, control);
    row.addEventListener("click", async () => {
      setStoryFilterEnabled(key, !state.storyFilters[key]);
      syncStoryFilterMenu();
      $$(POST_SELECTOR).forEach(applyStoryFilters);
      await saveStoryFilters();
    });
    return row;
  }

  function createStoryFilterNavigationRow(label, view, summaryKey) {
    const row = document.createElement("button");
    row.type = "button";
    row.className = "entry-chat-story-filter-option entry-chat-story-filter-navigation";
    row.dataset.storyFilterOpen = view;
    const copy = document.createElement("span");
    copy.className = "entry-chat-story-filter-copy";
    const name = document.createElement("strong");
    name.textContent = label;
    copy.appendChild(name);
    const side = document.createElement("span");
    side.className = "entry-chat-story-filter-navigation-side";
    const summary = document.createElement("span");
    summary.className = "entry-chat-story-filter-summary";
    summary.dataset.storyFilterSummary = summaryKey;
    const icon = document.createElement("span");
    icon.className = "material-symbols-outlined entry-chat-story-filter-navigation-icon";
    icon.setAttribute("aria-hidden", "true");
    icon.textContent = "chevron_right";
    side.append(summary, icon);
    row.append(copy, side);
    return row;
  }

  function showStoryFilterView(panel, view) {
    if (!panel) return;
    const nextView = panel.querySelector(`[data-story-filter-view="${CSS.escape(view)}"]`) ? view : "main";
    state.storyFilterView = nextView;
    panel.dataset.storyFilterCurrentView = nextView;
    $$('[data-story-filter-view]', panel).forEach((section) => {
      section.hidden = section.dataset.storyFilterView !== nextView;
    });
    if (nextView === "blocked") {
      const type = panel.dataset.storyBlockRuleType || "words";
      syncStoryBlockRuleType(panel, type);
      window.requestAnimationFrame(() => panel.querySelector(`[data-story-block-rule-input="${type}"]`)?.focus());
    }
  }

  function storyLinkFilterSummary() {
    if (state.storyFilters.allLinks) return "전체";
    let count = 0;
    if (state.storyFilters.entryLinks || state.storyFilters.projectLinks) count += 1;
    if (state.storyFilters.externalLinks || state.storyFilters.naverShortLinks) count += 1;
    return count ? `${count}개` : "꺼짐";
  }

  function storyBlockedRuleSummary() {
    const words = state.storyFilters.blockedWords.length;
    const nicknames = state.storyFilters.blockedNicknames.length;
    if (!words && !nicknames) return "꺼짐";
    if (words && nicknames) return `단어 ${words} · 닉네임 ${nicknames}`;
    return words ? `단어 ${words}` : `닉네임 ${nicknames}`;
  }

  function syncStoryBlockRuleList(panel, type) {
    const config = STORY_BLOCK_RULE_TYPES[type];
    const list = panel?.querySelector?.(`[data-story-block-rule-list="${type}"]`);
    if (!config || !list) return;
    const rules = state.storyFilters[config.key];
    const signature = JSON.stringify(rules);
    if (list.dataset.storyFilterRuleSignature === signature) return;
    list.dataset.storyFilterRuleSignature = signature;
    list.replaceChildren();
    if (!rules.length) {
      const empty = document.createElement("span");
      empty.className = "entry-chat-story-filter-rule-empty";
      empty.textContent = "등록된 항목 없음";
      list.appendChild(empty);
      return;
    }
    rules.forEach((rule) => {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "entry-chat-story-filter-rule-chip";
      chip.title = `${rule} 삭제`;
      const label = document.createElement("span");
      label.textContent = rule;
      const icon = document.createElement("span");
      icon.className = "material-symbols-outlined";
      icon.setAttribute("aria-hidden", "true");
      icon.textContent = "close";
      chip.append(label, icon);
      chip.addEventListener("click", async () => {
        state.storyFilters[config.key] = state.storyFilters[config.key].filter((item) => item !== rule);
        syncStoryFilterMenu();
        $$(POST_SELECTOR).forEach(applyStoryFilters);
        await saveStoryFilters();
      });
      list.appendChild(chip);
    });
  }

  function syncStoryBlockRuleType(panel, type) {
    const nextType = STORY_BLOCK_RULE_TYPES[type] ? type : "words";
    panel.dataset.storyBlockRuleType = nextType;
    $$('[data-story-block-rule-tab]', panel).forEach((tab) => {
      const active = tab.dataset.storyBlockRuleTab === nextType;
      tab.classList.toggle("entry-chat-story-filter-rule-tab-selected", active);
      tab.setAttribute("aria-selected", active ? "true" : "false");
    });
    $$('[data-story-block-rule-section]', panel).forEach((section) => {
      section.hidden = section.dataset.storyBlockRuleSection !== nextType;
    });
  }

  function createStoryBlockRuleSection(type) {
    const config = STORY_BLOCK_RULE_TYPES[type];
    const section = document.createElement("div");
    section.className = "entry-chat-story-filter-rule-section";
    section.dataset.storyBlockRuleSection = type;
    const form = document.createElement("form");
    form.className = "entry-chat-story-filter-rule-form";
    const input = document.createElement("input");
    input.type = "text";
    input.maxLength = 50;
    input.autocomplete = "off";
    input.spellcheck = false;
    input.placeholder = config.placeholder;
    input.dataset.storyBlockRuleInput = type;
    input.setAttribute("aria-label", config.placeholder);
    const add = document.createElement("button");
    add.type = "submit";
    add.className = "entry-chat-story-filter-rule-add";
    add.setAttribute("aria-label", `${config.label} 추가`);
    const icon = document.createElement("span");
    icon.className = "material-symbols-outlined";
    icon.setAttribute("aria-hidden", "true");
    icon.textContent = "add";
    add.appendChild(icon);
    form.append(input, add);
    const list = document.createElement("div");
    list.className = "entry-chat-story-filter-rule-list";
    list.dataset.storyBlockRuleList = type;
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const rule = normalizeStoryFilterRule(input.value);
      if (!rule || state.storyFilters[config.key].length >= 50) return;
      const comparable = storyFilterComparable(rule);
      if (!state.storyFilters[config.key].some((item) => storyFilterComparable(item) === comparable)) {
        state.storyFilters[config.key] = [...state.storyFilters[config.key], rule];
      }
      input.value = "";
      syncStoryFilterMenu();
      $$(POST_SELECTOR).forEach(applyStoryFilters);
      await saveStoryFilters();
      input.focus();
    });
    section.append(form, list);
    return section;
  }

  function createStoryFilterPanel() {
    const panel = document.createElement("div");
    panel.className = "entry-chat-story-filter-panel";
    panel.dataset.entryLlnkStoryFilterPanel = "1";
    panel.dataset.entryLlnkOwned = "1";
    panel.hidden = true;
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", "게시글 필터");
    panel.dataset.storyFilterCurrentView = "main";
    panel.dataset.storyBlockRuleType = "words";

    const mainView = document.createElement("section");
    mainView.className = "entry-chat-story-filter-view";
    mainView.dataset.storyFilterView = "main";
    mainView.append(
      createStoryFilterHeading("게시글 필터", "", true),
      createStoryFilterNavigationRow("링크", "links", "links"),
      createStoryFilterSwitchRow("images", "이미지"),
      createStoryFilterSwitchRow("entryEmoticons", "엔트리 이모티콘"),
      createStoryFilterNavigationRow("차단 단어", "blocked", "blocked"),
    );

    const linkView = document.createElement("section");
    linkView.className = "entry-chat-story-filter-view";
    linkView.dataset.storyFilterView = "links";
    linkView.hidden = true;
    linkView.appendChild(createStoryFilterHeading("링크", "main"));
    STORY_FILTER_OPTIONS.filter(({ key }) => !["images", "entryEmoticons"].includes(key)).forEach((option) => {
      linkView.appendChild(createStoryFilterSwitchRow(option.key, option.label, option.depth, option.startsSection));
    });

    const blockedView = document.createElement("section");
    blockedView.className = "entry-chat-story-filter-view";
    blockedView.dataset.storyFilterView = "blocked";
    blockedView.hidden = true;
    blockedView.appendChild(createStoryFilterHeading("차단 관리", "main"));
    const tabs = document.createElement("div");
    tabs.className = "entry-chat-story-filter-rule-tabs";
    tabs.setAttribute("role", "tablist");
    Object.entries(STORY_BLOCK_RULE_TYPES).forEach(([type, config]) => {
      const tab = document.createElement("button");
      tab.type = "button";
      tab.className = "entry-chat-story-filter-rule-tab";
      tab.dataset.storyBlockRuleTab = type;
      tab.setAttribute("role", "tab");
      const label = document.createElement("span");
      label.textContent = config.label;
      const count = document.createElement("span");
      count.className = "entry-chat-story-filter-rule-count";
      count.dataset.storyBlockRuleCount = type;
      tab.append(label, count);
      tab.addEventListener("click", () => {
        state.storyBlockRuleType = type;
        syncStoryBlockRuleType(panel, type);
        window.requestAnimationFrame(() => panel.querySelector(`[data-story-block-rule-input="${type}"]`)?.focus());
      });
      tabs.appendChild(tab);
    });
    blockedView.append(tabs, createStoryBlockRuleSection("words"), createStoryBlockRuleSection("nicknames"));
    panel.append(mainView, linkView, blockedView);

    panel.addEventListener("click", async (event) => {
      const navigation = event.target.closest?.("[data-story-filter-open]");
      if (navigation) {
        showStoryFilterView(panel, navigation.dataset.storyFilterOpen);
        return;
      }
      const back = event.target.closest?.("[data-story-filter-back]");
      if (back) {
        showStoryFilterView(panel, back.dataset.storyFilterBack);
        return;
      }
      if (!event.target.closest?.("[data-story-filter-reset='1']")) return;
      state.storyFilters = {
        ...Object.fromEntries(STORY_FILTER_OPTIONS.map(({ key }) => [key, false])),
        blockedWords: [],
        blockedNicknames: [],
      };
      syncStoryFilterMenu();
      $$(POST_SELECTOR).forEach(applyStoryFilters);
      await saveStoryFilters();
    });
    syncStoryBlockRuleType(panel, "words");
    return panel;
  }

  async function saveStorySetting(key, enabled) {
    const wasFallModeEnabled = state.pageSettings.fallMode === true;
    if (key === "spaceshipMotion" && state.pageSettings.fallMode) enabled = false;
    if (key === "fallMode") {
      if (enabled && !wasFallModeEnabled) {
        state.pageSettings.fallModeRestoreSpaceshipMotion = state.pageSettings.spaceshipMotion === true;
        state.pageSettings.spaceshipMotion = false;
        state.customModeComposeRestoreOpen = null;
        state.customModeDraftLayout = cloneCustomModeLayout(state.customModeLayout);
        state.customModeEditing = true;
      } else if (!enabled && wasFallModeEnabled) {
        state.pageSettings.spaceshipMotion = state.pageSettings.fallModeRestoreSpaceshipMotion === true;
      }
    } else if (key === "spaceshipMotion") {
      state.pageSettings.fallModeRestoreSpaceshipMotion = enabled;
    }
    state.pageSettings[key] = enabled;
    state.fallModeEnabled = state.pageSettings.fallMode === true;
    state.spaceshipMotionEnabled = state.pageSettings.spaceshipMotion === true;
    if (!spaceshipMotionAllowed()) clearSpaceshipMotionEffects();
    const saved = await Ringcl.storageGet(["entryLlnkSettings"]).catch(() => ({}));
    const nextSettings = {
      ...(saved.entryLlnkSettings || {}),
      ...state.pageSettings,
    };
    await Ringcl.storageSet({
      entryLlnkSettings: nextSettings,
    }).catch(() => {});

    if (state.fallModeEnabled) syncFallMode({ replay: key === "fallMode" && !wasFallModeEnabled });
    else if (key === "fallMode" && wasFallModeEnabled) removeFallModeStage();
  }

  function createStorySettingsPanel() {
    const panel = document.createElement("div");
    panel.className = "entry-chat-story-filter-panel entry-chat-story-settings-panel";
    panel.dataset.entryLlnkStorySettingsPanel = "1";
    panel.dataset.entryLlnkOwned = "1";
    panel.hidden = true;
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", "링클 설정");

    const heading = document.createElement("div");
    heading.className = "entry-chat-story-filter-heading";
    const title = document.createElement("strong");
    title.textContent = "설정";
    heading.appendChild(title);
    panel.appendChild(heading);

    STORY_SETTING_OPTIONS.forEach(({ key, label, icon, beta }) => {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "entry-chat-story-filter-option entry-chat-story-setting-option";
      row.dataset.storySettingKey = key;
      row.setAttribute("role", "switch");
      const rowIcon = document.createElement("span");
      rowIcon.className = "material-symbols-outlined entry-chat-story-setting-icon";
      rowIcon.setAttribute("aria-hidden", "true");
      rowIcon.textContent = icon;
      const copy = document.createElement("span");
      copy.className = "entry-chat-story-filter-copy";
      const name = document.createElement("strong");
      name.textContent = label;
      copy.appendChild(name);
      let badge = null;
      if (beta) {
        badge = document.createElement("b");
        badge.className = "entry-chat-story-setting-beta";
        badge.textContent = "BETA";
      }
      const control = document.createElement("span");
      control.className = "entry-chat-story-filter-switch";
      control.setAttribute("aria-hidden", "true");
      control.appendChild(document.createElement("i"));
      row.append(rowIcon, copy, ...(badge ? [badge] : []), control);
      row.addEventListener("click", async () => {
        if (row.disabled) return;
        const enabled = state.pageSettings[key] !== true;
        if (key === "shortenProjectLinks") {
          state.shortenProjectLinksEnabled = enabled;
          shortenProjectLinks(document);
        }
        await saveStorySetting(key, enabled);
        syncStorySettingsMenu();
      });
      panel.appendChild(row);
    });
    return panel;
  }

  function ensureStoryFilterMenu() {
    syncLiveStoryToolbarScope();
    if (!isLiveEntryStoryPage()) {
      $("[data-entry-llnk-link-filter='1']")?.remove();
      $("[data-entry-llnk-story-filter-panel='1']")?.remove();
      $("[data-entry-llnk-story-settings='1']")?.remove();
      $("[data-entry-llnk-story-settings-panel='1']")?.remove();
      state.storyToolbarOpenPanel = "";
      state.storyFilterView = "main";
      state.storyBlockRuleType = "words";
      return;
    }
    const container = getStorySortToolbarContainer();
    if (!container) return;
    let button = $("[data-entry-llnk-link-filter='1']");
    if (!button) {
      button = createStoryToolbarButton("entry-chat-story-link-filter-toggle", "entryLlnkLinkFilter", "필터", "filter_alt");
      button.addEventListener("click", () => {
        const panel = $("[data-entry-llnk-story-filter-panel='1']");
        if (!panel) return;
        const open = panel.hidden;
        closeStoryToolbarPanels(button);
        if (open) showStoryFilterView(panel, "main");
        setStoryToolbarPanelOpen(panel, button, open);
      });
    }
    if (button.parentElement !== container || button !== container.firstElementChild) container.insertBefore(button, container.firstElementChild);
    let settingsButton = $("[data-entry-llnk-story-settings='1']");
    if (!settingsButton) {
      settingsButton = createStoryToolbarButton("entry-chat-story-settings-toggle", "entryLlnkStorySettings", "설정", "settings");
      settingsButton.addEventListener("click", () => {
        const panel = $("[data-entry-llnk-story-settings-panel='1']");
        if (!panel) return;
        const open = panel.hidden;
        closeStoryToolbarPanels(settingsButton);
        setStoryToolbarPanelOpen(panel, settingsButton, open);
      });
    }
    if (settingsButton.parentElement !== container || settingsButton.previousElementSibling !== button) {
      container.insertBefore(settingsButton, button.nextSibling);
    }
    let panel = $("[data-entry-llnk-story-filter-panel='1']");
    const createdFilterPanel = !panel;
    if (!panel) panel = createStoryFilterPanel();
    if (panel.parentElement !== document.body) document.body.appendChild(panel);
    let settingsPanel = $("[data-entry-llnk-story-settings-panel='1']");
    if (!settingsPanel) settingsPanel = createStorySettingsPanel();
    if (settingsPanel.parentElement !== document.body) document.body.appendChild(settingsPanel);
    panel.dataset.entryLlnkToolbarPortal = "1";
    settingsPanel.dataset.entryLlnkToolbarPortal = "1";
    positionStoryToolbarPanel(panel, button);
    positionStoryToolbarPanel(settingsPanel, settingsButton);
    bindStoryFilterMenuEvents();
    bindNativeStorySortEvents();
    syncNativeStorySortOpenState();
    syncStoryFilterMenu(button, panel);
    syncStorySettingsMenu(settingsButton, settingsPanel);
    if (state.storyToolbarOpenPanel === "filter" && (createdFilterPanel || panel.hidden)) {
      syncStoryBlockRuleType(panel, state.storyBlockRuleType);
      showStoryFilterView(panel, state.storyFilterView);
      setStoryToolbarPanelOpen(panel, button, true);
    } else if (state.storyToolbarOpenPanel === "settings" && settingsPanel.hidden) {
      setStoryToolbarPanelOpen(settingsPanel, settingsButton, true);
    }
  }

  function syncStoryFilterMenu(
    button = $("[data-entry-llnk-link-filter='1']"),
    panel = $("[data-entry-llnk-story-filter-panel='1']"),
  ) {
    if (!button) return;
    const active = hasActiveStoryFilters();
    button.classList.toggle("is-active", active);
    button.setAttribute("aria-pressed", active ? "true" : "false");
    button.setAttribute("aria-expanded", panel && !panel.hidden ? "true" : "false");
    button.title = active ? "필터 사용 중" : "게시글 필터";
    if (!panel) return;
    $$('[data-story-filter-key]', panel).forEach((row) => {
      const enabled = state.storyFilters[row.dataset.storyFilterKey] === true;
      row.classList.toggle("is-active", enabled);
      row.setAttribute("aria-checked", enabled ? "true" : "false");
    });
    const linkSummary = panel.querySelector('[data-story-filter-summary="links"]');
    const blockedSummary = panel.querySelector('[data-story-filter-summary="blocked"]');
    if (linkSummary) linkSummary.textContent = storyLinkFilterSummary();
    if (blockedSummary) blockedSummary.textContent = storyBlockedRuleSummary();
    Object.entries(STORY_BLOCK_RULE_TYPES).forEach(([type, config]) => {
      const count = panel.querySelector(`[data-story-block-rule-count="${type}"]`);
      if (count) count.textContent = String(state.storyFilters[config.key].length);
      syncStoryBlockRuleList(panel, type);
    });
    const reset = panel.querySelector('[data-story-filter-reset="1"]');
    if (reset) reset.disabled = !active;
  }

  function syncStorySettingsMenu(
    button = $("[data-entry-llnk-story-settings='1']"),
    panel = $("[data-entry-llnk-story-settings-panel='1']"),
  ) {
    if (!button) return;
    button.setAttribute("aria-expanded", panel && !panel.hidden ? "true" : "false");
    button.title = "링클 설정";
    if (!panel) return;
    $$('[data-story-setting-key]', panel).forEach((row) => {
      const key = row.dataset.storySettingKey;
      const disabled = key === "spaceshipMotion" && state.pageSettings.fallMode === true;
      const enabled = state.pageSettings[key] === true;
      row.disabled = disabled;
      row.classList.toggle("is-disabled", disabled);
      row.classList.toggle("is-active", enabled);
      row.setAttribute("aria-checked", enabled ? "true" : "false");
      row.setAttribute("aria-disabled", disabled ? "true" : "false");
    });
  }

  function getList() {
    return $$(LIST_SELECTOR).find((element) => !element.closest(".entry-chat-root")) || $(POST_SELECTOR)?.parentElement || null;
  }

  function findAutoMoreButton() {
    return $$('button.css-1cmqu6s.e1lgujxn6, button[class~="css-1cmqu6s"][class~="e1lgujxn6"]')
      .filter((candidate) => (
        !candidate.closest(".entry-chat-root")
        && isVisible(candidate)
        && !candidate.disabled
        && candidate.getAttribute("aria-disabled") !== "true"
        && text(candidate.textContent).replace(/\s+/g, "") === "더보기"
      ))
      .map((candidate) => ({ candidate, rect: candidate.getBoundingClientRect() }))
      .filter(({ rect }) => rect.width > 0 && rect.height > 0)
      .sort((left, right) => right.rect.top - left.rect.top)[0]?.candidate || null;
  }

  function scheduleAutoMoreCheck(delay = 0) {
    window.clearTimeout(state.autoMoreCheckTimer);
    state.autoMoreCheckTimer = window.setTimeout(() => {
      state.autoMoreCheckTimer = 0;
      checkAutoMore();
    }, Math.max(0, delay));
  }

  function stopAutoMoreWatch() {
    window.clearInterval(state.autoMoreWatchTimer);
    state.autoMoreWatchTimer = 0;
    window.clearTimeout(state.autoMoreCheckTimer);
    state.autoMoreCheckTimer = 0;
  }

  function startAutoMoreWatch() {
    stopAutoMoreWatch();
    if (!state.autoMoreEnabled || state.customModeEditing) return;
    state.autoMoreWatchTimer = window.setInterval(() => {
      if (document.visibilityState === "visible") checkAutoMore();
    }, 600);
    scheduleAutoMoreCheck();
  }

  function checkAutoMore() {
    if (!state.autoMoreEnabled || state.customModeEditing || !isEntryStoryListPage() || document.visibilityState === "hidden" || state.autoMoreClicking || Date.now() - state.autoMoreAt < 1100) return;
    const button = findAutoMoreButton();
    if (!button) return;
    const scrolling = document.scrollingElement || document.documentElement || document.body;
    const scrollHeight = Number(scrolling?.scrollHeight || document.documentElement.scrollHeight || 0);
    const viewportHeight = Number(window.innerHeight || scrolling?.clientHeight || 0);
    const buttonRect = button.getBoundingClientRect();
    const prefetchDistance = Math.max(480, Math.min(900, viewportHeight * 0.9));
    if (buttonRect.top > viewportHeight + prefetchDistance) return;
    const beforeHeight = scrollHeight;
    const list = getList();
    const beforeCount = list ? [...list.children].filter((element) => element.matches?.(POST_SELECTOR)).length : 0;
    state.autoMoreClicking = true;
    state.autoMoreAt = Date.now();
    try {
      button.click();
      waitForAutoMoreGrowth(beforeHeight, beforeCount);
    } catch (_) {
      state.autoMoreClicking = false;
      scheduleAutoMoreCheck(900);
    }
  }

  function waitForAutoMoreGrowth(beforeHeight, beforeCount, startedAt = Date.now()) {
    window.clearTimeout(state.autoMoreReleaseTimer);
    state.autoMoreReleaseTimer = window.setTimeout(() => {
      if (state.customModeEditing) {
        state.autoMoreClicking = false;
        state.autoMoreReleaseTimer = 0;
        return;
      }
      if (!isEntryStoryListPage()) {
        state.autoMoreClicking = false;
        return;
      }
      const scrolling = document.scrollingElement || document.documentElement || document.body;
      const currentHeight = Number(scrolling?.scrollHeight || document.documentElement.scrollHeight || 0);
      const list = getList();
      const currentCount = list ? [...list.children].filter((element) => element.matches?.(POST_SELECTOR)).length : 0;
      const grew = currentHeight > beforeHeight + 80 || currentCount > beforeCount;
      if (grew || Date.now() - startedAt >= 5000) {
        state.autoMoreClicking = false;
        state.autoMoreReleaseTimer = 0;
        scheduleAutoMoreCheck(grew ? 120 : 700);
        return;
      }
      waitForAutoMoreGrowth(beforeHeight, beforeCount, startedAt);
    }, 180);
  }

  function removeScrollTopButton() {
    $$(".entry-chat-entry-story-scroll-top[data-entry-llnk-owned='1']").forEach((button) => button.remove());
  }

  function isIndicatorEligibleStoryPost(post) {
    return post instanceof Element
      && !post.hidden
      && !isStoryPostFiltered(post)
      && window.getComputedStyle(post).display !== "none";
  }

  function isNewestEntryStoryPostVisible() {
    const firstPost = getLiveRows(getList()).find(isIndicatorEligibleStoryPost);
    if (!firstPost) return window.scrollY <= 80;
    const rect = firstPost.getBoundingClientRect();
    return rect.bottom > 0 && rect.top < window.innerHeight;
  }

  function updateNewPostIndicator(button = $(".entry-chat-entry-story-scroll-top[data-entry-llnk-owned='1']")) {
    if (!button) return;
    if (isNewestEntryStoryPostVisible()) button.classList.remove("has-new-post");
    else button.classList.add("has-new-post");
  }

  function updateNewPostIndicatorForArrivals(detail = {}, remainingFrames = 4) {
    const ids = Array.isArray(detail.ids) ? detail.ids.map((id) => text(id).trim()).filter(Boolean) : [];
    if (!ids.length) return;
    const list = getList();
    if (!list) return;
    const posts = parseNativeLivePosts(detail);
    const candidates = getLiveRows(list);
    const rows = ids.map((id) => {
      const post = posts.find((item) => text(item?.id).trim() === id);
      const postKey = getLivePostKeyFromData(post);
      const postIdentity = getLivePostIdentityFromData(post);
      const row = list.querySelector(`[data-entry-chat-live-post-id="${CSS.escape(id)}"]`)
        || candidates.find((candidate) => postKey && getLivePostKeyFromElement(candidate) === postKey)
        || candidates.find((candidate) => postIdentity && getLivePostIdentityFromElement(candidate) === postIdentity);
      if (row && !row.dataset.entryChatLivePostId) row.dataset.entryChatLivePostId = id;
      return row;
    }).filter(Boolean);
    if (rows.length < ids.length && remainingFrames > 0) {
      window.requestAnimationFrame(() => updateNewPostIndicatorForArrivals(detail, remainingFrames - 1));
      return;
    }
    rows.forEach(applyStoryFilters);
    if (rows.some(isIndicatorEligibleStoryPost)) updateNewPostIndicator();
  }

  function ensureScrollTopButton() {
    if (!isEntryStoryListPage()) {
      removeScrollTopButton();
      return;
    }
    if ($(".entry-chat-entry-story-scroll-top[data-entry-llnk-owned='1']")) return;
    Ringcl.ensureIconFont?.();
    const button = document.createElement("button");
    button.type = "button";
    button.className = "entry-chat-entry-story-scroll-top";
    button.dataset.entryLlnkOwned = "1";
    button.title = "맨 위로";
    button.setAttribute("aria-label", "맨 위로");
    const icon = document.createElement("span");
    icon.className = "material-symbols-outlined entry-chat-symbol";
    icon.setAttribute("aria-hidden", "true");
    icon.textContent = "arrow_upward";
    button.appendChild(icon);
    button.addEventListener("click", () => {
      button.classList.remove("has-new-post");
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
    document.body.appendChild(button);
  }

  function updateScrollUi() {
    if (!isEntryStoryListPage()) {
      removeScrollTopButton();
      return;
    }
    const button = $(".entry-chat-entry-story-scroll-top[data-entry-llnk-owned='1']");
    if (button) {
      const customModeActive = state.fallModeEnabled
        && document.documentElement.classList.contains("entry-llnk-custom-mode-active");
      const list = getList();
      if (customModeActive) {
        button.style.left = "50%";
      } else if (list) {
        const rect = list.getBoundingClientRect();
        const width = button.offsetWidth || 44;
        const gap = window.innerWidth <= 720 ? 8 : 14;
        const left = Math.max(12, Math.min(window.innerWidth - width - 12, rect.right + gap));
        button.style.left = `${Math.round(left)}px`;
      }
      if (button.classList.contains("has-new-post") && isNewestEntryStoryPostVisible()) {
        button.classList.remove("has-new-post");
      }
      button.classList.toggle("is-visible", window.scrollY > Math.max(520, window.innerHeight * 0.7));
    }
    checkAutoMore();
  }

  function onScroll() {
    if (state.scrollRaf) return;
    state.scrollRaf = requestAnimationFrame(() => {
      state.scrollRaf = 0;
      updateScrollUi();
    });
  }

  function ensureLazyObserver() {
    if (state.lazyObserver) return state.lazyObserver;
    state.lazyObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        state.lazyObserver.unobserve(entry.target);
        loadLazyCard(entry.target);
      });
    }, { rootMargin: "240px" });
    return state.lazyObserver;
  }

  function observeLazyCard(card) {
    ensureLazyObserver().observe(card);
  }

  function ensureBlouplaFrameListener() {
    if (state.blouplaFrameListener) return;
    const extensionRoot = getExtensionUrl("/");
    if (!extensionRoot) return;
    state.blouplaFrameListener = true;
    const extensionOrigin = new URL(extensionRoot).origin;
    window.addEventListener("message", (event) => {
      const payload = event.data;
      if (event.origin !== extensionOrigin || payload?.type !== "entry-llnkkR-bloupla-image") return;
      const token = text(payload.token).trim();
      const entry = state.blouplaFrames.get(token);
      if (!entry || event.source !== entry.frame.contentWindow) return;
      state.blouplaFrames.delete(token);
      const card = entry.host.closest(".entry-chat-image-card");
      if (payload.error) {
        if (card && !showImageFallbackLink(card)) {
          card.textContent = "이미지를 불러오지 못했습니다.";
          card.classList.add("is-error");
        }
        return;
      }
      const width = Math.max(1, Number(payload.width) || 1);
      const height = Math.max(1, Number(payload.height) || 1);
      const ratio = Math.max(0.25, Math.min(4, width / height));
      entry.host.style.aspectRatio = String(ratio);
      sizeImageCardForRatio(card, ratio);
    });
  }

  function sizeImageCardForRatio(card, ratio) {
    if (!card) return;
    const normalizedRatio = Math.max(0.25, Math.min(4, Number(ratio) || 1));
    const width = normalizedRatio < 1
      ? Math.max(110, Math.round(440 * normalizedRatio))
      : 420;
    card.style.width = `min(${width}px, 100%)`;
    card.classList.toggle("is-portrait", normalizedRatio < 1);
  }

  function createBlouplaImageHost(imageUrl) {
    const url = new URL(imageUrl);
    const code = url.pathname.slice(1);
    const token = crypto.randomUUID();
    const host = document.createElement("span");
    host.className = "entry-chat-bloupla-image-host";
    const root = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = ":host{display:block;width:100%;aspect-ratio:16/9;background:#0f1115;overflow:hidden}iframe{display:block;width:100%;height:100%;border:0;pointer-events:none}";
    const frame = document.createElement("iframe");
    frame.title = "Bloupla 이미지";
    frame.tabIndex = -1;
    frame.setAttribute("aria-hidden", "true");
    root.append(style, frame);
    const frameUrl = getExtensionUrl("src/bloupla-image-frame.html");
    if (!frameUrl) return host;
    state.blouplaFrames.set(token, { frame, host });
    ensureBlouplaFrameListener();
    const source = `${frameUrl}?code=${encodeURIComponent(code)}&token=${encodeURIComponent(token)}`;
    const navigate = () => {
      frame.removeAttribute("srcdoc");
      if (frame.getAttribute("src") !== source) frame.setAttribute("src", source);
    };
    navigate();
    requestAnimationFrame(navigate);
    return host;
  }

  async function loadLazyCard(card) {
    if (card.dataset.entryLlnkLazyLoaded === "1") return;
    card.dataset.entryLlnkLazyLoaded = "1";
    if (card.dataset.entryLlnkLazyType === "poll") {
      try {
        const code = text(card.dataset.entryLlnkCode).trim().toLowerCase();
        const payload = await Ringcl.api(`polls.php?code=${encodeURIComponent(code)}`);
        if (!payload.poll) throw new Error("투표를 찾지 못했습니다.");
        await renderPublicPoll(card, payload.poll);
      } catch (_) {
        showPollFallbackLink(card);
      }
      return;
    }
    if (card.dataset.entryLlnkLazyType === "image") {
      try {
        let remote = card.dataset.entryLlnkDirectUrl;
        if (!remote && card.dataset.entryLlnkSource === "llnk") {
          const payload = await Ringcl.api(`images.php?code=${encodeURIComponent(`i${card.dataset.entryLlnkCode || ""}`)}`);
          if (!payload.image?.url) throw new Error("이미지 주소를 찾지 못했습니다.");
          remote = payload.image.url;
        }
        if (!remote) throw new Error("이미지 주소를 찾지 못했습니다.");
        const safe = safeHttpUrl(remote, "https://playentry.org");
        const entryUploadUrl = safe?.hostname === "playentry.org" && safe.pathname.startsWith("/uploads/")
          ? safe.href
          : "";
        const blouplaImageUrl = card.dataset.entryLlnkSource === "bloupla"
          ? getBlouplaImageUrl(safe)
          : "";
        const imageUrl = entryUploadUrl || blouplaImageUrl;
        if (!imageUrl) throw new Error("이미지 주소가 올바르지 않습니다.");
        const wrapper = document.createElement("span");
        wrapper.className = "entry-chat-image-spoiler";
        const link = document.createElement("a");
        link.className = "entry-chat-image-link";
        const fallbackUrl = safeHttpUrl(card.dataset.entryLlnkFallbackUrl);
        const llnkViewerUrl = card.dataset.entryLlnkSource === "llnk"
          && fallbackUrl?.protocol === "https:"
          && fallbackUrl.hostname === "llnk.kr"
          ? fallbackUrl.href
          : "";
        link.href = llnkViewerUrl || imageUrl;
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        link.addEventListener("click", (event) => {
          event.stopPropagation();
        });
        if (blouplaImageUrl) {
          link.appendChild(createBlouplaImageHost(blouplaImageUrl));
        } else {
          const image = document.createElement("img");
          image.src = imageUrl;
          image.alt = "이미지";
          image.loading = "lazy";
          image.decoding = "async";
          image.addEventListener("error", () => showImageFallbackLink(card), { once: true });
          link.appendChild(image);
        }
        const cover = document.createElement("button");
        cover.type = "button";
        cover.className = "entry-chat-image-spoiler-cover";
        cover.textContent = "이미지 보기";
        cover.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          wrapper.classList.add("is-revealed");
          card.classList.remove("has-spoiler");
        });
        wrapper.appendChild(link);
        if (state.imageSpoilerEnabled) wrapper.appendChild(cover);
        else wrapper.classList.add("is-revealed");
        wrapper.appendChild(createImageSourceBadge(card.dataset.entryLlnkSource));
        card.replaceChildren(wrapper);
        card.dataset.imageLoaded = "1";
        card.classList.toggle("has-spoiler", state.imageSpoilerEnabled);
      } catch (error) {
        if (!showImageFallbackLink(card)) {
          card.textContent = error.message || "이미지를 불러오지 못했습니다.";
          card.classList.add("is-error");
        }
      }
      return;
    }
  }

  function getWriter() {
    return $$(WRITER_SELECTOR).find((element) => (
      !element.closest(".entry-chat-root")
      && !element.closest(".css-1cyfuwa.ed0ret0, [class~='css-1cyfuwa'][class~='ed0ret0']")
    )) || null;
  }

  function getSubmit(writer = getWriter()) {
    if (!writer) return null;
    const form = writer.closest(".css-1uvivr9.ed0ret1, [class~='css-1uvivr9'][class~='ed0ret1'], .css-cbwem1.e1lgujxn2, [class~='css-cbwem1'][class~='e1lgujxn2'], form") || writer.parentElement?.parentElement || document;
    return $$('button, a[data-testid="button"], a.css-c0d46e, a[class~="e1lwjzl20"]', form).find((button) => (
      !button.closest(".css-1cyfuwa.ed0ret0, [class~='css-1cyfuwa'][class~='ed0ret0']")
      && text(button.textContent).replace(/\s+/g, "") === "등록"
    )) || null;
  }

  function insertAtSelection(writer, insertion) {
    const value = writer.value || "";
    const start = Number.isFinite(writer.selectionStart) ? writer.selectionStart : value.length;
    const end = Number.isFinite(writer.selectionEnd) ? writer.selectionEnd : value.length;
    const prefix = start > 0 && !/[\s\n]$/.test(value.slice(0, start)) ? " " : "";
    const next = `${prefix}${insertion}`;
    if (typeof writer.setRangeText === "function") writer.setRangeText(next, start, end, "end");
    else writer.value = `${value.slice(0, start)}${next}${value.slice(end)}`;
    writer.dispatchEvent(new Event("input", { bubbles: true }));
    writer.dispatchEvent(new Event("change", { bubbles: true }));
    writer.focus();
  }

  function ensureWriterTools() {
    const writer = getWriter();
    if (!writer) return;
    Ringcl.ensureIconFont?.();
    bindWriter(writer);
    ensureCounter(writer);
    renderWriterPreview();
    offerDraftRestore(writer);
    const submit = getSubmit(writer);
    bindSubmit(writer, submit);
    if (!submit) return;
    const form = writer.closest(".css-1uvivr9.ed0ret1, [class~='css-1uvivr9'][class~='ed0ret1'], .css-cbwem1.e1lgujxn2, [class~='css-cbwem1'][class~='e1lgujxn2'], form") || writer.parentElement?.parentElement;
    const submitArea = submit.closest(".css-11ofcmn.ed0ret4, [class~='css-11ofcmn'][class~='ed0ret4']") || submit.parentElement;
    if (!submitArea) return;
    form?.classList.add("entry-chat-compose-shell");
    submitArea.classList.add("entry-chat-compose-action-row");
    if ($("[data-entry-chat-compose-more='1']", submitArea)) {
      syncImageControlState();
      syncPollControlState();
      return;
    }
    $$('[data-entry-chat-image-control="1"][data-entry-llnk-owned="1"]', submitArea).forEach((control) => control.remove());
    const composeMenu = createComposeMoreMenu(writer);
    composeMenu.dataset.entryLlnkOwned = "1";
    submitArea.insertBefore(composeMenu, submit);
    syncImageControlState();
    syncPollControlState();
  }

  function createComposeIcon(name, extraClass = "entry-chat-compose-icon") {
    const icon = document.createElement("span");
    icon.className = `material-symbols-outlined entry-chat-symbol ${extraClass}`.trim();
    icon.setAttribute("aria-hidden", "true");
    icon.textContent = name;
    return icon;
  }

  function setupEntryStoryComposeCarousel(menu, panel) {
    if (!menu || !panel || document.documentElement.classList.contains("entry-chat-iframe-viewer")) return;
    if (panel.dataset.entryChatComposeCarousel === "1") return;
    const existingControls = Array.from(panel.children);
    const previousButton = document.createElement("button");
    previousButton.type = "button";
    previousButton.className = "entry-chat-compose-carousel-nav is-previous";
    previousButton.setAttribute("aria-label", "\uc774\uc804 \uae30\ub2a5");
    previousButton.appendChild(createComposeIcon("keyboard_arrow_up"));
    const viewport = document.createElement("span");
    viewport.className = "entry-chat-compose-carousel-viewport";
    viewport.dataset.entryChatComposeCarouselViewport = "1";
    const track = document.createElement("span");
    track.className = "entry-chat-compose-carousel-track";
    track.dataset.entryChatComposeCarouselTrack = "1";
    const nextButton = document.createElement("button");
    nextButton.type = "button";
    nextButton.className = "entry-chat-compose-carousel-nav is-next";
    nextButton.setAttribute("aria-label", "\ub2e4\uc74c \uae30\ub2a5");
    nextButton.style.setProperty("background", "var(--entry-chat-carousel-next-background, transparent)", "important");
    nextButton.style.setProperty("background-color", "var(--entry-chat-carousel-next-background, transparent)", "important");
    nextButton.style.setProperty("background-image", "none", "important");
    nextButton.appendChild(createComposeIcon("keyboard_arrow_down"));
    track.append(...existingControls);
    viewport.appendChild(track);
    panel.replaceChildren(previousButton, viewport, nextButton);
    panel.classList.add("is-carousel");
    panel.dataset.entryChatComposeCarousel = "1";

    let busy = false;
    let dragging = false;
    let suppressClick = false;
    let startY = 0;
    let lastY = 0;
    let startTime = 0;
    let lastMoveTime = 0;
    let dragPosition = 0;
    let dragVelocity = 0;
    let activePointerId = null;
    let inertiaFrame = null;
    let transitionGhost = null;
    let transitionGhostDirection = 0;

    const stopInertia = () => {
      if (inertiaFrame === null) return false;
      window.cancelAnimationFrame(inertiaFrame);
      inertiaFrame = null;
      return true;
    };
    const removeTransitionGhost = () => {
      transitionGhost?.remove();
      transitionGhost = null;
      transitionGhostDirection = 0;
    };
    const getRealControls = () => Array.from(track.children).filter((element) => !element.classList.contains("entry-chat-compose-carousel-ghost"));
    const createTransitionGhost = (direction) => {
      const normalizedDirection = Math.sign(direction);
      if (!normalizedDirection) {
        removeTransitionGhost();
        return;
      }
      if (transitionGhost && transitionGhostDirection === normalizedDirection) return;
      removeTransitionGhost();
      const controls = getRealControls();
      if (!controls.length) return;
      const trackStyle = window.getComputedStyle(track);
      const gap = Number.parseFloat(trackStyle.rowGap || trackStyle.gap) || 8;
      const source = normalizedDirection > 0 ? controls[0] : controls[controls.length - 1];
      const ghostTop = normalizedDirection > 0
        ? controls[controls.length - 1].offsetTop + controls[controls.length - 1].getBoundingClientRect().height + gap
        : controls[0].offsetTop - source.getBoundingClientRect().height - gap;
      transitionGhost = source.cloneNode(true);
      transitionGhostDirection = normalizedDirection;
      transitionGhost.classList.add("entry-chat-compose-carousel-ghost");
      transitionGhost.setAttribute("aria-hidden", "true");
      transitionGhost.inert = true;
      [transitionGhost, ...transitionGhost.querySelectorAll("*")].forEach((element) => {
        element.removeAttribute("id");
        Array.from(element.attributes).forEach((attribute) => {
          if (attribute.name.startsWith("data-entry-")) element.removeAttribute(attribute.name);
        });
      });
      transitionGhost.querySelectorAll("button, input, textarea, select, a").forEach((element) => {
        element.setAttribute("tabindex", "-1");
      });
      transitionGhost.style.top = `${ghostTop}px`;
      track.appendChild(transitionGhost);
    };

    const getStep = () => {
      const first = track.firstElementChild;
      if (!first) return 42;
      const style = window.getComputedStyle(track);
      return Math.max(1, first.getBoundingClientRect().height + (Number.parseFloat(style.rowGap || style.gap) || 8));
    };
    const getCarouselMetrics = () => {
      const step = getStep();
      const trackStyle = window.getComputedStyle(track);
      const gap = Number.parseFloat(trackStyle.rowGap || trackStyle.gap) || 8;
      const controlCount = Array.from(track.children).filter((element) => !element.classList.contains("entry-chat-compose-carousel-ghost")).length;
      const visibleTrackHeight = controlCount > 1 ? Math.max(0, (controlCount - 1) * step - gap) : 0;
      const centerOffset = Math.max(0, (viewport.clientHeight - visibleTrackHeight) / 2);
      return { step, centerOffset };
    };
    const updateArrowPosition = () => {
      if (panel.classList.contains("is-static")) {
        panel.style.removeProperty("--entry-chat-carousel-arrow-inset");
        return;
      }
      const { centerOffset } = getCarouselMetrics();
      const arrowHeight = Math.max(previousButton.offsetHeight, nextButton.offsetHeight, 18);
      const inset = Math.max(0, centerOffset - arrowHeight);
      panel.style.setProperty("--entry-chat-carousel-arrow-inset", `${inset}px`);
    };
    const getBasePosition = () => {
      if (panel.classList.contains("is-static")) return 0;
      const { step, centerOffset } = getCarouselMetrics();
      return -step + centerOffset;
    };
    const setPosition = (value, animate = false) => {
      track.style.transition = animate ? "transform 240ms cubic-bezier(0.22, 1, 0.36, 1)" : "none";
      track.style.transform = `translate3d(0, ${value}px, 0)`;
    };
    const refresh = () => {
      if (panel.classList.contains("is-static")) {
        updateArrowPosition();
        setPosition(0);
        return;
      }
      if (track.children.length < 2) return;
      if (track.dataset.entryChatCarouselPrimed !== "1") {
        track.prepend(track.lastElementChild);
        track.dataset.entryChatCarouselPrimed = "1";
      }
      updateArrowPosition();
      if (!busy && !dragging) setPosition(getBasePosition());
    };
    const sortControls = () => {
      const current = Array.from(track.children);
      const sorted = [...current].sort((a, b) => Number(a.dataset.entryChatCarouselOrder || 999) - Number(b.dataset.entryChatCarouselOrder || 999));
      if (sorted.every((control, index) => control === current[index])) return;
      sorted.forEach((control) => track.appendChild(control));
    };
    const updateLayoutMode = () => {
      const controlCount = track.children.length;
      const availableHeight = menu.getBoundingClientRect().height;
      const requiredHeight = controlCount > 0 ? controlCount * 42 + 12 : Number.POSITIVE_INFINITY;
      const useStaticLayout = availableHeight >= requiredHeight;
      if (useStaticLayout === panel.classList.contains("is-static")) {
        if (useStaticLayout) {
          sortControls();
          setPosition(0);
        } else {
          refresh();
        }
        return;
      }
      busy = false;
      dragging = false;
      activePointerId = null;
      panel.classList.remove("is-dragging", "is-scrolling");
      panel.classList.toggle("is-static", useStaticLayout);
      if (useStaticLayout) {
        sortControls();
        delete track.dataset.entryChatCarouselPrimed;
        setPosition(0);
      } else {
        delete track.dataset.entryChatCarouselPrimed;
        refresh();
      }
    };
    const finishMove = (direction) => {
      removeTransitionGhost();
      if (direction > 0) track.appendChild(track.firstElementChild);
      else track.prepend(track.lastElementChild);
      setPosition(getBasePosition());
      busy = false;
      panel.classList.remove("is-scrolling");
    };
    const move = (direction) => {
      if (panel.classList.contains("is-static")) return;
      refresh();
      if (busy || track.children.length < 2) return;
      busy = true;
      panel.classList.add("is-scrolling");
      const step = getStep();
      const base = getBasePosition();
      createTransitionGhost(direction);
      window.requestAnimationFrame(() => {
        setPosition(direction > 0 ? base - step : base + step, true);
        window.setTimeout(() => finishMove(direction), 250);
      });
    };
    const snapBack = () => {
      busy = true;
      setPosition(getBasePosition(), true);
      window.setTimeout(() => {
        setPosition(getBasePosition());
        removeTransitionGhost();
        busy = false;
        panel.classList.remove("is-scrolling");
      }, 250);
    };
    const normalizeDragPosition = () => {
      const step = getStep();
      const base = getBasePosition();
      let wrapped = false;
      const ghostDirection = transitionGhostDirection;
      while (dragPosition <= base - step) {
        const first = getRealControls()[0];
        if (!first) break;
        track.appendChild(first);
        dragPosition += step;
        wrapped = true;
      }
      while (dragPosition >= base + step) {
        const controls = getRealControls();
        const last = controls[controls.length - 1];
        if (!last) break;
        track.prepend(last);
        dragPosition -= step;
        wrapped = true;
      }
      if (wrapped && ghostDirection) {
        removeTransitionGhost();
        createTransitionGhost(ghostDirection);
      }
      return { step, base };
    };
    const settleDragPosition = () => {
      stopInertia();
      const { step, base } = normalizeDragPosition();
      let direction = 0;
      let target = base;
      if (dragPosition <= base - step * 0.5) {
        direction = 1;
        target = base - step;
      } else if (dragPosition >= base + step * 0.5) {
        direction = -1;
        target = base + step;
      }
      if (direction) createTransitionGhost(direction);
      busy = true;
      panel.classList.add("is-scrolling");
      setPosition(target, true);
      window.setTimeout(() => {
        if (direction) finishMove(direction);
        else {
          setPosition(getBasePosition());
          removeTransitionGhost();
          busy = false;
          panel.classList.remove("is-scrolling");
        }
      }, 250);
    };
    const startInertia = (initialVelocity) => {
      stopInertia();
      let velocity = Math.max(-2.4, Math.min(2.4, initialVelocity));
      createTransitionGhost(velocity < 0 ? 1 : -1);
      let previousTime = performance.now();
      busy = true;
      panel.classList.add("is-scrolling");
      const tick = (now) => {
        const elapsed = Math.min(32, Math.max(1, now - previousTime));
        previousTime = now;
        dragPosition += velocity * elapsed;
        normalizeDragPosition();
        setPosition(dragPosition);
        velocity *= Math.pow(0.92, elapsed / 16.667);
        if (Math.abs(velocity) > 0.025 && panel.isConnected && !panel.classList.contains("is-static")) {
          inertiaFrame = window.requestAnimationFrame(tick);
          return;
        }
        inertiaFrame = null;
        busy = false;
        settleDragPosition();
      };
      inertiaFrame = window.requestAnimationFrame(tick);
    };

    previousButton.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (stopInertia()) busy = false;
      move(1);
    });
    nextButton.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (stopInertia()) busy = false;
      move(-1);
    });
    viewport.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || track.children.length < 2 || panel.classList.contains("is-static")) return;
      const interruptedInertia = stopInertia();
      if (interruptedInertia) {
        busy = false;
        panel.classList.remove("is-scrolling");
      } else if (busy) return;
      if (!interruptedInertia) refresh();
      activePointerId = event.pointerId;
      startY = event.clientY;
      lastY = event.clientY;
      startTime = performance.now();
      lastMoveTime = startTime;
      if (!interruptedInertia) dragPosition = getBasePosition();
      dragVelocity = 0;
      dragging = false;
      track.style.transition = "none";
    });
    viewport.addEventListener("pointermove", (event) => {
      if (activePointerId !== event.pointerId) return;
      const delta = event.clientY - startY;
      if (!dragging && Math.abs(delta) > 4) {
        dragging = true;
        suppressClick = true;
        panel.classList.add("is-dragging");
        viewport.setPointerCapture?.(event.pointerId);
      }
      if (!dragging) {
        lastY = event.clientY;
        lastMoveTime = performance.now();
        return;
      }
      event.preventDefault();
      const now = performance.now();
      const movement = event.clientY - lastY;
      const instantVelocity = movement / Math.max(1, now - lastMoveTime);
      dragVelocity = dragVelocity * 0.65 + instantVelocity * 0.35;
      dragPosition += movement;
      if (movement) createTransitionGhost(movement < 0 ? 1 : -1);
      normalizeDragPosition();
      lastY = event.clientY;
      lastMoveTime = now;
      setPosition(dragPosition);
    });
    const finishDrag = (event) => {
      if (activePointerId !== event.pointerId) return;
      if (viewport.hasPointerCapture?.(event.pointerId)) viewport.releasePointerCapture(event.pointerId);
      const delta = lastY - startY;
      const elapsed = Math.max(1, performance.now() - startTime);
      const velocity = delta / elapsed;
      activePointerId = null;
      panel.classList.remove("is-dragging");
      if (!dragging) {
        removeTransitionGhost();
        if (Math.abs(dragPosition - getBasePosition()) > 0.5) settleDragPosition();
        return;
      }
      dragging = false;
      const idleTime = Math.max(0, performance.now() - lastMoveTime);
      const recentFactor = Math.max(0, 1 - idleTime / 140);
      const releaseVelocity = Math.max(-2.4, Math.min(2.4, (dragVelocity * 0.82 + velocity * 0.18) * recentFactor));
      if (Math.abs(releaseVelocity) >= 0.045) startInertia(releaseVelocity);
      else settleDragPosition();
      window.setTimeout(() => { suppressClick = false; }, 0);
    };
    viewport.addEventListener("pointerup", finishDrag);
    viewport.addEventListener("pointercancel", finishDrag);
    viewport.addEventListener("click", (event) => {
      if (!suppressClick) return;
      event.preventDefault();
      event.stopImmediatePropagation();
    }, true);
    const resizeObserver = typeof ResizeObserver === "function" ? new ResizeObserver(updateLayoutMode) : null;
    resizeObserver?.observe(menu);
    menu.entryChatCarouselRefresh = updateLayoutMode;
    menu.entryChatCarouselSetOpen = (isOpen) => {
      if (!isOpen) {
        stopInertia();
        removeTransitionGhost();
        busy = false;
        dragging = false;
        activePointerId = null;
        panel.classList.remove("is-dragging", "is-scrolling");
        if (!panel.classList.contains("is-static")) setPosition(getBasePosition());
      }
      window.requestAnimationFrame(updateArrowPosition);
    };
    updateLayoutMode();
  }

  function createImageControl(writer) {
    const control = document.createElement("span");
    control.className = "entry-chat-image-compose";
    control.dataset.entryChatImageControl = "1";
    const button = document.createElement("button");
    button.type = "button";
    button.className = "entry-chat-image-toggle is-ready";
    button.setAttribute("aria-label", "이미지 첨부");
    button.appendChild(createComposeIcon("image"));
    const label = document.createElement("span");
    label.className = "entry-chat-compose-label";
    label.textContent = "이미지";
    button.appendChild(label);
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      const preview = $("[data-entry-chat-image-preview-panel='1']");
      if (preview?.classList.contains("is-visible") && getPendingImageCode()) {
        removeImageAttachment(writer, preview);
        return;
      }
      chooseImage(writer);
    });
    control.appendChild(button);
    return control;
  }

  function closeComposeMoreMenu(menu, animated = true) {
    if (!menu?.classList.contains("is-open")) return;
    if (menu.entryChatComposeAnimationTimer) {
      window.clearTimeout(menu.entryChatComposeAnimationTimer);
      menu.entryChatComposeAnimationTimer = null;
    }
    menu.classList.remove("is-opening", "is-closing");
    if (animated) {
      void menu.querySelector("[data-entry-chat-compose-more-panel='1']")?.offsetHeight;
      menu.classList.add("is-closing");
    }
    menu.classList.remove("is-open");
    menu.entryChatCarouselSetOpen?.(false);
    const toggle = $(".entry-chat-compose-more-toggle", menu);
    toggle?.setAttribute("aria-expanded", "false");
    menu.entryChatComposeAnimationTimer = window.setTimeout(() => {
      menu.classList.remove("is-closing");
      menu.entryChatComposeAnimationTimer = null;
    }, animated ? 360 : 0);
  }

  function openComposeMoreMenu(menu) {
    if (!menu) return;
    $$('[data-entry-chat-compose-more="1"].is-open').forEach((other) => {
      if (other !== menu) closeComposeMoreMenu(other, false);
    });
    if (menu.entryChatComposeAnimationTimer) {
      window.clearTimeout(menu.entryChatComposeAnimationTimer);
      menu.entryChatComposeAnimationTimer = null;
    }
    menu.classList.remove("is-opening", "is-closing", "is-open");
    void menu.querySelector("[data-entry-chat-compose-more-panel='1']")?.offsetHeight;
    menu.classList.add("is-open", "is-opening");
    menu.entryChatCarouselSetOpen?.(true);
    $(".entry-chat-compose-more-toggle", menu)?.setAttribute("aria-expanded", "true");
    menu.entryChatComposeAnimationTimer = window.setTimeout(() => {
      menu.classList.remove("is-opening");
      menu.entryChatComposeAnimationTimer = null;
    }, 360);
  }

  function bindComposeMorePersistenceEvents() {
    if (state.composeMenuEventsBound) return;
    state.composeMenuEventsBound = true;
    document.addEventListener("keydown", (event) => {
      if (event.key !== "Escape" || !$('[data-entry-chat-compose-more="1"].is-open')) return;
      event.preventDefault();
      event.stopImmediatePropagation();
    }, true);
  }

  function createComposeMoreMenu(writer) {
    bindComposeMorePersistenceEvents();
    const menu = document.createElement("span");
    menu.className = "entry-chat-compose-more";
    menu.dataset.entryChatComposeMore = "1";
    const toggle = document.createElement("button");
    toggle.type = "button";
    toggle.className = "entry-chat-compose-more-toggle";
    toggle.setAttribute("aria-label", "추가 기능");
    toggle.setAttribute("aria-expanded", "false");
    const toggleIcon = document.createElement("span");
    toggleIcon.className = "entry-chat-compose-more-toggle-icon";
    toggleIcon.setAttribute("aria-hidden", "true");
    toggle.appendChild(toggleIcon);
    toggle.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (state.customModeEditing && menu.classList.contains("is-open")) return;
      if (menu.classList.contains("is-open")) closeComposeMoreMenu(menu);
      else openComposeMoreMenu(menu);
    });
    const panel = document.createElement("span");
    panel.className = "entry-chat-compose-more-panel";
    panel.dataset.entryChatComposeMorePanel = "1";
    const controls = [
      createPollControl(writer, "quiz"),
      createPollControl(writer, "poll"),
      createImageControl(writer),
    ];
    if (!document.documentElement.classList.contains("entry-chat-iframe-viewer")) {
      const repeatedControls = [
        createPollControl(writer, "quiz"),
        createPollControl(writer, "poll"),
        createImageControl(writer),
      ];
      repeatedControls.forEach((control) => {
        control.dataset.entryChatCarouselDuplicate = "1";
      });
      controls.push(...repeatedControls);
    }
    controls.forEach((control, index) => {
      control.dataset.entryChatCarouselOrder = String(index);
    });
    panel.append(...controls);
    menu.append(toggle, panel);
    setupEntryStoryComposeCarousel(menu, panel);
    return menu;
  }

  function createPollControl(writer, type = "poll") {
    const isQuiz = type === "quiz";
    const control = document.createElement("span");
    control.className = `entry-chat-poll-compose${isQuiz ? " entry-chat-quiz-compose" : ""}`;
    control.dataset.entryChatPollControl = "1";
    control.dataset.entryChatPollType = type;
    const button = document.createElement("button");
    button.type = "button";
    button.className = "entry-chat-poll-toggle";
    button.setAttribute("aria-label", `${isQuiz ? "퀴즈" : "투표"} 만들기`);
    button.appendChild(createComposeIcon(isQuiz ? "quiz" : "how_to_vote"));
    const label = document.createElement("span");
    label.className = "entry-chat-compose-label";
    label.textContent = isQuiz ? "퀴즈" : "투표";
    button.appendChild(label);
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      const current = getPollComposer();
      if (current?.dataset.entryChatPollType === type) removePollComposer(current);
      else {
        if (current) removePollComposer(current);
        showPollComposer(writer, type);
      }
    });
    control.appendChild(button);
    return control;
  }

  function getPollComposer() {
    return $("[data-entry-chat-poll-composer='1']");
  }

  function selectQuizCorrectRow(list, row) {
    if (!list || !row) return;
    [...list.children].forEach((item) => item.classList.toggle("is-correct-answer", item === row));
    refreshPollOptionRows(list);
  }

  function addPollOptionRow(list, value = "", correct = false) {
    if (!list || list.children.length >= 5) return;
    const isQuiz = list.dataset.entryChatPollType === "quiz";
    const row = document.createElement("div");
    row.className = "entry-chat-poll-compose-option";
    if (isQuiz && (correct || list.children.length === 0)) row.classList.add("is-correct-answer");
    const correctButton = document.createElement("button");
    correctButton.type = "button";
    correctButton.className = "entry-chat-quiz-correct";
    correctButton.title = "정답으로 설정";
    correctButton.setAttribute("aria-label", "정답으로 설정");
    correctButton.addEventListener("click", () => selectQuizCorrectRow(list, row));
    const input = document.createElement("input");
    input.type = "text";
    input.maxLength = 100;
    input.value = value;
    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "entry-chat-poll-compose-remove";
    remove.title = "선택지 삭제";
    remove.setAttribute("aria-label", "선택지 삭제");
    remove.appendChild(createComposeIcon("close", "entry-chat-poll-compose-remove-icon"));
    remove.addEventListener("click", () => {
      if (list.children.length <= 2) return;
      row.remove();
      refreshPollOptionRows(list);
    });
    if (isQuiz) row.append(correctButton);
    row.append(input, remove);
    list.appendChild(row);
    refreshPollOptionRows(list);
  }

  function refreshPollOptionRows(list) {
    const isQuiz = list?.dataset.entryChatPollType === "quiz";
    if (isQuiz && ![...(list?.children || [])].some((row) => row.classList.contains("is-correct-answer"))) {
      list.firstElementChild?.classList.add("is-correct-answer");
    }
    [...(list?.children || [])].forEach((row, index) => {
      const input = $("input", row);
      const remove = $(".entry-chat-poll-compose-remove", row);
      const correct = $(".entry-chat-quiz-correct", row);
      if (input) input.placeholder = `선택지 ${index + 1}`;
      if (remove) remove.disabled = list.children.length <= 2;
      if (correct) {
        const selected = row.classList.contains("is-correct-answer");
        correct.classList.toggle("is-selected", selected);
        correct.setAttribute("aria-pressed", selected ? "true" : "false");
        correct.replaceChildren(createComposeIcon(
          selected ? "check_circle" : "radio_button_unchecked",
          "entry-chat-quiz-correct-icon"
        ));
      }
    });
    const panel = list?.closest?.("[data-entry-chat-poll-composer='1']");
    const add = $("[data-entry-chat-poll-add='1']", panel);
    if (add) add.hidden = list.children.length >= 5;
  }

  function showPollComposer(writer, type = "poll") {
    const isQuiz = type === "quiz";
    const form = writer?.closest(".css-1uvivr9.ed0ret1, [class~='css-1uvivr9'][class~='ed0ret1'], .css-cbwem1.e1lgujxn2, [class~='css-cbwem1'][class~='e1lgujxn2']") || writer?.parentElement;
    if (!writer || !form) return;
    const panel = document.createElement("div");
    panel.className = "entry-chat-poll-compose-panel";
    panel.dataset.entryChatPollComposer = "1";
    panel.dataset.entryChatPollType = type;
    panel.dataset.entryLlnkOwned = "1";
    const header = document.createElement("div");
    header.className = "entry-chat-poll-compose-header";
    const title = document.createElement("strong");
    title.textContent = isQuiz ? "퀴즈" : "투표";
    const close = document.createElement("button");
    close.type = "button";
    close.title = `${isQuiz ? "퀴즈" : "투표"} 취소`;
    close.setAttribute("aria-label", `${isQuiz ? "퀴즈" : "투표"} 취소`);
    close.appendChild(createComposeIcon("close", "entry-chat-poll-compose-close-icon"));
    close.addEventListener("click", () => removePollComposer(panel));
    header.append(title, close);
    const question = document.createElement("input");
    question.type = "text";
    question.className = "entry-chat-poll-compose-question";
    question.maxLength = 160;
    question.placeholder = "질문을 입력해 주세요";
    const list = document.createElement("div");
    list.className = "entry-chat-poll-compose-options";
    list.dataset.entryChatPollType = type;
    const add = document.createElement("button");
    add.type = "button";
    add.className = "entry-chat-poll-compose-add";
    add.dataset.entryChatPollAdd = "1";
    add.append(createComposeIcon("add", "entry-chat-poll-compose-add-icon"), document.createTextNode("선택지 추가"));
    add.addEventListener("click", () => addPollOptionRow(list));
    const status = document.createElement("p");
    status.className = "entry-chat-poll-compose-status";
    status.dataset.entryChatPollStatus = "1";
    panel.append(header, question, list, add, status);
    addPollOptionRow(list, "", isQuiz);
    addPollOptionRow(list);
    const writerLabel = writer.closest("label") || writer.closest(".css-19sv4op.ed0ret2, [class~='css-19sv4op'][class~='ed0ret2']");
    const controls = $(".css-ljggwk.ed0ret3, [class~='css-ljggwk'][class~='ed0ret3']", form);
    if (writerLabel?.parentElement === form) writerLabel.insertAdjacentElement("afterend", panel);
    else if (controls?.parentElement === form) form.insertBefore(panel, controls);
    else form.appendChild(panel);
    syncPollControlState();
    question.focus();
  }

  function removePollComposer(panel = getPollComposer()) {
    panel?.remove();
    syncPollControlState();
  }

  function syncPollControlState() {
    const activeType = getPollComposer()?.dataset.entryChatPollType || "";
    $$('[data-entry-chat-poll-control="1"]').forEach((control) => {
      $(".entry-chat-poll-toggle", control)?.classList.toggle("is-active", control.dataset.entryChatPollType === activeType);
    });
  }

  function setPollComposerStatus(panel, message = "", isError = false) {
    const status = $("[data-entry-chat-poll-status='1']", panel);
    if (!status) return;
    status.textContent = text(message);
    status.classList.toggle("is-error", Boolean(isError));
  }

  function pollShortLink(code, type = "") {
    const normalized = text(code).trim().toLowerCase();
    const expectedPrefix = type === "quiz" ? "q" : type === "poll" ? "v" : "";
    if (!/^[vq][a-z0-9]{7}$/.test(normalized)) return "";
    if (expectedPrefix && !normalized.startsWith(expectedPrefix)) return "";
    return `https://Llnk.kr/${normalized}`;
  }

  function pollComposerValues(panel) {
    const type = panel?.dataset.entryChatPollType === "quiz" ? "quiz" : "poll";
    const question = text($(".entry-chat-poll-compose-question", panel)?.value).trim();
    const rows = $$(".entry-chat-poll-compose-option", panel);
    const options = rows.map((row) => text($("input", row)?.value).trim());
    if (!question) throw new Error("질문을 입력해 주세요.");
    if (Array.from(question).length > 160) throw new Error("질문은 160자 이내로 입력해 주세요.");
    if (options.length < 2 || options.length > 5 || options.some((option) => !option)) {
      throw new Error("선택지를 2개 이상 입력해 주세요.");
    }
    if (options.some((option) => Array.from(option).length > 100)) {
      throw new Error("선택지는 각각 100자 이내로 입력해 주세요.");
    }
    const normalized = options.map((option) => option.toLocaleLowerCase("ko-KR"));
    if (new Set(normalized).size !== normalized.length) {
      throw new Error("같은 선택지를 두 번 사용할 수 없습니다.");
    }
    const correctOption = type === "quiz"
      ? rows.findIndex((row) => row.classList.contains("is-correct-answer")) + 1
      : null;
    if (type === "quiz" && correctOption < 1) throw new Error("정답을 하나 선택해 주세요.");
    return { type, question, options, correctOption };
  }

  function appendPollShortLink(value, shortLink) {
    const source = text(value).trimEnd();
    if (!shortLink || source.includes(shortLink)) return source;
    return source ? `${source} ${shortLink}` : shortLink;
  }

  function setPollComposerBusy(panel, busy) {
    if (!panel) return;
    panel.dataset.pollCreating = busy ? "1" : "0";
    panel.classList.toggle("is-busy", busy);
    $$('input, button', panel).forEach((control) => { control.disabled = busy; });
  }

  function preparePollSubmit(event, writer = getWriter(), submit = getSubmit(writer)) {
    const panel = getPollComposer();
    if (!writer || !submit || !panel) return false;
    event.preventDefault();
    event.stopImmediatePropagation?.();
    if (panel.dataset.pollCreating === "1") return true;
    const isQuiz = panel.dataset.entryChatPollType === "quiz";
    const contentLabel = isQuiz ? "퀴즈" : "투표";
    let values;
    try {
      values = pollComposerValues(panel);
    } catch (error) {
      setPollComposerStatus(panel, error?.message || `${contentLabel} 내용을 확인해 주세요.`, true);
      return true;
    }
    const reservedLength = "https://Llnk.kr/v1234567".length + (text(writer.value).trim() ? 1 : 0);
    if (text(writer.value).trimEnd().length + reservedLength > MAX_POST_LENGTH) {
      setPollComposerStatus(panel, `${contentLabel} 링크를 추가하면 글자 수 제한을 넘습니다.`, true);
      return true;
    }
    setPollComposerBusy(panel, true);
    setPollComposerStatus(panel, `${contentLabel}를 만드는 중…`);
    Ringcl.api("polls.php", {
      method: "POST",
      body: {
        action: "create",
        type: values.type,
        question: values.question,
        options: values.options,
        ...(isQuiz ? { correct_option: values.correctOption } : {}),
      },
    }).then((payload) => {
      const code = text(payload?.poll?.code).trim().toLowerCase();
      const shortLink = pollShortLink(code, values.type);
      if (!shortLink) throw new Error(`${contentLabel} 링크를 받지 못했습니다.`);
      writer.value = appendPollShortLink(writer.value, shortLink);
      writer.dispatchEvent(new Event("input", { bubbles: true }));
      writer.dispatchEvent(new Event("change", { bubbles: true }));
      removePollComposer(panel);
      window.requestAnimationFrame(() => submit.click());
    }).catch((error) => {
      setPollComposerBusy(panel, false);
      refreshPollOptionRows($(".entry-chat-poll-compose-options", panel));
      setPollComposerStatus(panel, error?.message || `${contentLabel}를 만들지 못했습니다.`, true);
    });
    return true;
  }

  function bindWriter(writer) {
    if (writer.dataset.entryLlnkBound === "1") return;
    writer.dataset.entryLlnkBound = "1";
    const update = (event = null) => {
      if (writer.dataset.entryLlnkDraftAnimating !== "1") {
        saveDraft(writer, { allowClear: Boolean(event?.isTrusted) });
      }
      updateCounter(writer);
    };
    writer.addEventListener("input", (event) => {
      update(event);
      if (writer.dataset.entryLlnkDraftAnimating !== "1") scheduleWriterPreview();
    });
    writer.addEventListener("change", (event) => {
      update(event);
      scheduleWriterPreview();
    });
    writer.addEventListener("compositionend", (event) => {
      update(event);
      scheduleWriterPreview();
    });
    writer.addEventListener("blur", update);
  }

  function bindSubmit(writer, submit) {
    if (!submit || submit.dataset.entryLlnkBound === "1") return;
    submit.dataset.entryLlnkBound = "1";
    submit.addEventListener("click", (event) => {
      if (preparePollSubmit(event, writer, submit)) return;
      if (prepareImageSubmit(event, writer)) return;
      const submittedValue = text(writer?.value);
      saveDraft(writer);
      if (submittedValue.trim()) {
        rememberDraftSubmitPending(submittedValue);
        startDraftFailureWatch();
      }
      prepareWriterForSubmit(writer);
      window.setTimeout(renderWriterPreview, 120);
    }, true);
  }

  function draftOwnerId() {
    return text(state.draftOwnerId).trim();
  }

  function readDraftSubmitPending() {
    try {
      const pending = JSON.parse(sessionStorage.getItem(DRAFT_SUBMIT_SESSION_KEY) || "null");
      const value = text(pending?.value);
      const ownerEntryUserId = text(pending?.ownerEntryUserId).trim();
      const expiresAt = Number(pending?.expiresAt || 0);
      const submittedAt = Number(pending?.submittedAt || expiresAt - 35000 || 0);
      if (!value.trim() || !expiresAt || expiresAt <= Date.now()) {
        sessionStorage.removeItem(DRAFT_SUBMIT_SESSION_KEY);
        return null;
      }
      return { value, ownerEntryUserId, expiresAt, submittedAt };
    } catch (_) {
      try { sessionStorage.removeItem(DRAFT_SUBMIT_SESSION_KEY); } catch (_) {}
      return null;
    }
  }

  function clearDraftSubmitPending() {
    state.draftSubmitPendingUntil = 0;
    state.draftSubmittedValue = "";
    state.draftSubmittedAt = 0;
    window.clearInterval(state.draftFailureWatchTimer);
    state.draftFailureWatchTimer = 0;
    try { sessionStorage.removeItem(DRAFT_SUBMIT_SESSION_KEY); } catch (_) {}
  }

  function restoreDraftSubmitPending(ownerEntryUserId = "") {
    const pending = readDraftSubmitPending();
    if (!pending) {
      state.draftSubmitPendingUntil = 0;
      state.draftSubmittedValue = "";
      state.draftSubmittedAt = 0;
      return false;
    }
    const owner = text(ownerEntryUserId).trim();
    if (owner && pending.ownerEntryUserId && pending.ownerEntryUserId !== owner) {
      clearDraftSubmitPending();
      return false;
    }
    state.draftSubmitPendingUntil = pending.expiresAt;
    state.draftSubmittedValue = pending.value;
    state.draftSubmittedAt = pending.submittedAt;
    return true;
  }

  function rememberDraftSubmitPending(value) {
    const submittedValue = text(value);
    if (!submittedValue.trim()) return;
    const submittedAt = Date.now();
    const expiresAt = Date.now() + 35000;
    state.draftSubmitPendingUntil = expiresAt;
    state.draftSubmittedValue = submittedValue;
    state.draftSubmittedAt = submittedAt;
    try {
      sessionStorage.setItem(DRAFT_SUBMIT_SESSION_KEY, JSON.stringify({
        value: submittedValue,
        ownerEntryUserId: draftOwnerId(),
        submittedAt,
        expiresAt,
      }));
    } catch (_) {}
  }

  function resetDraftRuntimeForAccount(nextOwnerEntryUserId = "") {
    const nextOwner = text(nextOwnerEntryUserId).trim();
    const previousOwner = draftOwnerId();
    if (previousOwner === nextOwner) return;
    const previousDraft = state.draftValue;
    window.clearTimeout(state.draftPersistTimer);
    state.draftPersistTimer = 0;
    state.draftValue = "";
    state.draftSavedAt = 0;
    state.draftPersistentLoaded = false;
    state.draftOwnerId = nextOwner;
    restoreDraftSubmitPending(nextOwner);
    const writer = getWriter();
    if (writer) {
      const current = text(writer.value);
      const restoredByRingcl = writer.dataset.entryLlnkDraftRestored === "1";
      if (restoredByRingcl || (previousDraft && current === previousDraft)) {
        const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
        if (setter) setter.call(writer, "");
        else writer.value = "";
        writer.dispatchEvent(new Event("input", { bubbles: true }));
        writer.dispatchEvent(new Event("change", { bubbles: true }));
        updateCounter(writer);
        scheduleWriterPreview(0);
      }
      delete writer.dataset.entryLlnkDraftRestored;
    }
    clearDraftRestoreEffects();
  }

  async function refreshDraftOwner(force = false) {
    if (!force && state.draftOwnerCheckedAt && Date.now() - state.draftOwnerCheckedAt < 30000) return draftOwnerId();
    if (state.draftOwnerVerification) return state.draftOwnerVerification;
    state.draftOwnerVerification = Ringcl.resolveEntryIdentity(true)
      .then((identity) => {
        const nextOwner = text(identity?.entryUserId).trim();
        resetDraftRuntimeForAccount(nextOwner);
        state.draftOwnerCheckedAt = Date.now();
        return nextOwner;
      })
      .catch(() => {
        state.draftOwnerCheckedAt = Date.now();
        return draftOwnerId();
      })
      .finally(() => {
        state.draftOwnerVerification = null;
      });
    return state.draftOwnerVerification;
  }

  function saveDraft(writer, options = {}) {
    if (!state.draftEnabled) return;
    const value = text(writer?.value);
    const pendingValue = text(state.draftSubmittedValue);
    if (
      Date.now() < state.draftSubmitPendingUntil
      && pendingValue.trim()
      && encodedPostValue(value) === encodedPostValue(pendingValue)
    ) return;
    if (!value.trim()) {
      if (options.allowClear) clearDraft();
      return;
    }
    const ownerEntryUserId = draftOwnerId();
    if (!ownerEntryUserId) return;
    state.draftValue = value;
    state.draftSavedAt = Date.now();
    try {
      sessionStorage.setItem("entryLlnkEntryStoryDraftSession", value);
      sessionStorage.setItem("entryLlnkEntryStoryDraftSessionAt", String(state.draftSavedAt));
      sessionStorage.setItem("entryLlnkEntryStoryDraftSessionOwner", ownerEntryUserId);
    } catch (_) {}
    window.clearTimeout(state.draftPersistTimer);
    state.draftPersistTimer = window.setTimeout(() => {
      state.draftPersistTimer = 0;
      Ringcl.storageSet({
        [DRAFT_STORAGE_KEY]: { value, savedAt: state.draftSavedAt, ownerEntryUserId },
      }).catch(() => {});
    }, DRAFT_SAVE_DELAY_MS);
  }

  function readDraft() {
    const currentOwner = draftOwnerId();
    if (!currentOwner) return null;
    if (state.draftValue) return { value: state.draftValue, savedAt: state.draftSavedAt };
    try {
      const value = sessionStorage.getItem("entryLlnkEntryStoryDraftSession") || "";
      const savedAt = Number(sessionStorage.getItem("entryLlnkEntryStoryDraftSessionAt") || 0);
      const savedOwner = text(sessionStorage.getItem("entryLlnkEntryStoryDraftSessionOwner") || "").trim();
      if (!value.trim() || !savedAt || Date.now() - savedAt >= DRAFT_TTL_MS || !savedOwner || savedOwner !== currentOwner) return null;
      state.draftValue = value;
      state.draftSavedAt = savedAt;
      return { value, savedAt };
    } catch (_) {
      return null;
    }
  }

  async function readPersistentDraft() {
    if (state.draftPersistentLoaded) return state.draftValue ? { value: state.draftValue, savedAt: state.draftSavedAt } : null;
    state.draftPersistentLoaded = true;
    const saved = await Ringcl.storageGet([DRAFT_STORAGE_KEY]).catch(() => ({}));
    const record = saved?.[DRAFT_STORAGE_KEY];
    if (!record || typeof record !== "object") return null;
    const value = text(record.value);
    const savedAt = Number(record.savedAt || 0);
    const savedOwner = text(record.ownerEntryUserId).trim();
    const currentOwner = draftOwnerId();
    if (!value.trim() || !savedAt || Date.now() - savedAt >= DRAFT_TTL_MS) {
      Ringcl.storageRemove([DRAFT_STORAGE_KEY]).catch(() => {});
      return null;
    }
    if (!currentOwner || !savedOwner || savedOwner !== currentOwner) return null;
    if (!state.draftValue || savedAt > state.draftSavedAt) {
      state.draftValue = value;
      state.draftSavedAt = savedAt;
      try {
        sessionStorage.setItem("entryLlnkEntryStoryDraftSession", value);
        sessionStorage.setItem("entryLlnkEntryStoryDraftSessionAt", String(savedAt));
        sessionStorage.setItem("entryLlnkEntryStoryDraftSessionOwner", savedOwner);
      } catch (_) {}
    }
    return { value: state.draftValue, savedAt: state.draftSavedAt };
  }

  function discardStoredDraft() {
    window.clearTimeout(state.draftPersistTimer);
    state.draftPersistTimer = 0;
    state.draftValue = "";
    state.draftSavedAt = 0;
    state.draftPersistentLoaded = true;
    try {
      sessionStorage.removeItem("entryLlnkEntryStoryDraftSession");
      sessionStorage.removeItem("entryLlnkEntryStoryDraftSessionAt");
      sessionStorage.removeItem("entryLlnkEntryStoryDraftSessionOwner");
    } catch (_) {}
    Ringcl.storageRemove([DRAFT_STORAGE_KEY]).catch(() => {});
  }

  function clearDraft() {
    discardStoredDraft();
    clearDraftSubmitPending();
    clearDraftRestoreEffects();
  }

  async function restoreDraftOnPageLoad(writer = getWriter()) {
    if (!state.draftEnabled) return;
    if (!isEntryStoryListPage() || !writer || writer.dataset.entryLlnkDraftRestored === "1" || text(writer.value).trim()) return;
    if (Date.now() < state.draftSubmitPendingUntil) return;
    const ownerEntryUserId = await refreshDraftOwner();
    if (!ownerEntryUserId || !writer.isConnected || text(writer.value).trim()) return;
    let draft = readDraft();
    if (!draft) draft = await readPersistentDraft();
    if (!draft?.value?.trim() || !writer.isConnected || text(writer.value).trim()) return;
    restoreDraftIntoWriter(writer, draft.value, { announce: true });
  }

  function restoreDraftIntoWriter(writer, value, options = {}) {
    const draftValue = text(value);
    if (
      !writer?.isConnected
      || writer.dataset.entryLlnkDraftAnimating === "1"
      || !draftValue.trim()
      || text(writer.value) === draftValue
    ) return false;
    writer.dataset.entryLlnkDraftRestored = "1";
    if (options.announce) playDraftRestoreAnimation(writer, draftValue);
    else setDraftRestoreValue(writer, draftValue, true);
    return true;
  }

  function setDraftRestoreValue(writer, value, notify = false) {
    if (!writer?.isConnected) return;
    const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
    if (setter) setter.call(writer, value);
    else writer.value = value;
    if (!notify) return;
    writer.dispatchEvent(new Event("input", { bubbles: true }));
    writer.dispatchEvent(new Event("change", { bubbles: true }));
    updateCounter(writer);
    scheduleWriterPreview(0);
  }

  function setDraftRestoreProgress(writer, value) {
    if (!writer?.isConnected) return;
    const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
    if (setter) setter.call(writer, value);
    else writer.value = value;
    writer.dispatchEvent(new Event("input", { bubbles: true }));
    updateCounter(writer);
  }

  function measureDraftTextMetrics(writer, value) {
    if (!writer?.isConnected) return { totalWidth: 0, maxLineWidth: 0, contentWidth: 0, paddingLeft: 0 };
    const canvas = measureDraftTextMetrics.canvas || document.createElement("canvas");
    measureDraftTextMetrics.canvas = canvas;
    const context = canvas.getContext("2d");
    if (!context) return { totalWidth: 0, maxLineWidth: 0, contentWidth: 0, paddingLeft: 0 };
    const style = getComputedStyle(writer);
    context.font = [style.fontStyle, style.fontVariant, style.fontWeight, style.fontSize, style.fontFamily]
      .filter(Boolean)
      .join(" ");
    context.fontKerning = "normal";
    if ("letterSpacing" in context) context.letterSpacing = style.letterSpacing;
    const paddingLeft = Number.parseFloat(style.paddingLeft) || 0;
    const paddingRight = Number.parseFloat(style.paddingRight) || 0;
    const contentWidth = Math.max(1, writer.clientWidth - paddingLeft - paddingRight);
    const letterSpacing = Number.parseFloat(style.letterSpacing) || 0;
    const lineWidths = [];
    for (const paragraph of text(value).replace(/\r\n?/g, "\n").split("\n")) {
      let lineWidth = 0;
      for (const character of Array.from(paragraph)) {
        const characterWidth = context.measureText(character).width + letterSpacing;
        if (lineWidth > 0 && lineWidth + characterWidth > contentWidth) {
          lineWidths.push(lineWidth);
          lineWidth = 0;
        }
        lineWidth += characterWidth;
      }
      lineWidths.push(lineWidth);
    }
    return {
      totalWidth: lineWidths.reduce((total, width) => total + width, 0),
      maxLineWidth: Math.max(0, ...lineWidths),
      contentWidth,
      paddingLeft,
    };
  }

  function draftFlightTiming(characterCount, metrics = {}) {
    const count = Math.max(1, Number(characterCount) || 1);
    const travelWidth = Math.max(count * 8, Number(metrics.totalWidth) || 0);
    const sweepDistance = Math.max(72, Math.min(Number(metrics.contentWidth) || 72, Number(metrics.maxLineWidth) || 72));
    const entryDuration = 660;
    const typingDuration = Math.max(280, Math.min(2350, 220 + travelWidth * 0.22));
    const sweepDuration = Math.max(520, Math.min(2700, typingDuration + 220));
    const exitDuration = 760;
    const duration = entryDuration + sweepDuration + exitDuration;
    return {
      duration,
      entryEnd: entryDuration / duration,
      exitStart: (entryDuration + sweepDuration) / duration,
      typingStart: entryDuration + 90,
      typingDuration,
      sweepDistance,
      paddingLeft: Number(metrics.paddingLeft) || 0,
    };
  }

  function draftFlightPose(writer, progress, timing, writingProgress = 0) {
    const rect = writer.getBoundingClientRect();
    const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
    const mix = (start, end, amount) => start + (end - start) * amount;
    const easeOutCubic = (value) => 1 - (1 - value) ** 3;
    const easeInCubic = (value) => value ** 3;
    const easeOutBack = (value) => {
      const overshoot = 1.28;
      return 1 + (overshoot + 1) * (value - 1) ** 3 + overshoot * (value - 1) ** 2;
    };
    const entryEnd = timing.entryEnd;
    const exitStart = timing.exitStart;
    const flightY = rect.top - 82;
    const sweepStartX = rect.left + timing.paddingLeft - 56;
    const sweepEndX = Math.min(rect.right - 70, sweepStartX + timing.sweepDistance);
    let x = sweepStartX;
    let y = flightY;
    let scale = 0.68;
    let rotate = 0;
    let yaw = 0;
    let opacity = 1;

    if (progress < entryEnd) {
      const local = clamp(progress / entryEnd, 0, 1);
      const eased = easeOutBack(local);
      x = mix(-240, sweepStartX, eased);
      y = mix(rect.bottom + 150, flightY, easeOutCubic(local));
      scale = mix(2.35, 0.68, easeOutCubic(local)) + Math.sin(local * Math.PI) * 0.16;
      rotate = mix(-42, 2, eased) + Math.sin(local * Math.PI * 2) * 5;
      yaw = mix(-28, -4, easeOutCubic(local));
      opacity = clamp(local / 0.12, 0, 1);
    } else if (progress <= exitStart) {
      const local = clamp((progress - entryEnd) / (exitStart - entryEnd), 0, 1);
      const eased = local * local * (3 - 2 * local);
      const writeT = clamp(writingProgress, 0, 1);
      x = mix(sweepStartX, sweepEndX, writeT);
      y = flightY + Math.sin(writeT * Math.PI * 3) * 4;
      scale = 0.68 + Math.sin(writeT * Math.PI) * 0.055;
      rotate = Math.sin(writeT * Math.PI * 2.4) * 3.2;
      yaw = mix(-4, 5, eased);
    } else {
      const local = clamp((progress - exitStart) / (1 - exitStart), 0, 1);
      const eased = easeInCubic(local);
      x = mix(sweepEndX, window.innerWidth + 250, eased);
      y = mix(flightY, rect.top - 160, eased) + Math.sin(local * Math.PI) * 10;
      scale = mix(0.68, 2.55, eased);
      rotate = mix(1, 34, eased);
      yaw = mix(5, 30, eased);
      opacity = local > 0.84 ? clamp((1 - local) / 0.16, 0, 1) : 1;
    }

    const impact = progress < entryEnd
      ? Math.sin(clamp(progress / entryEnd, 0, 1) * Math.PI)
      : progress > exitStart
        ? Math.sin(clamp((progress - exitStart) / (1 - exitStart), 0, 1) * Math.PI)
        : 0.12 + Math.sin(progress * Math.PI * 4) * 0.04;
    return { x, y, scale, rotate, yaw, opacity, impact };
  }

  function draftBeamHeight(writer, pose) {
    const rect = writer.getBoundingClientRect();
    const flightCenter = 56;
    const beamTop = 84;
    const scale = Math.max(0.2, pose.scale);
    const visualBeamTop = pose.y + flightCenter + (beamTop - flightCenter) * scale;
    return Math.max(0, Math.min(168, (rect.bottom - visualBeamTop) / scale));
  }

  async function restoreUnexpectedlyClearedDraft() {
    if (!state.draftEnabled) return;
    if (state.draftGuardRunning || !isEntryStoryListPage() || document.visibilityState === "hidden") return;
    if (Date.now() < state.draftSubmitPendingUntil) return;
    const writer = getWriter();
    if (!writer?.isConnected || writer.dataset.entryLlnkDraftAnimating === "1" || text(writer.value).trim()) return;
    state.draftGuardRunning = true;
    try {
      if (!draftOwnerId()) await refreshDraftOwner();
      let draft = readDraft();
      if (!draft) draft = await readPersistentDraft();
      const currentWriter = getWriter();
      if (
        !draft?.value?.trim()
        || !currentWriter?.isConnected
        || currentWriter.dataset.entryLlnkDraftAnimating === "1"
        || text(currentWriter.value).trim()
        || Date.now() < state.draftSubmitPendingUntil
      ) return;
      restoreDraftIntoWriter(currentWriter, draft.value, { announce: true });
    } finally {
      state.draftGuardRunning = false;
    }
  }

  function startDraftGuardian() {
    if (!state.draftEnabled || state.draftGuardTimer) return;
    state.draftGuardTimer = window.setInterval(() => {
      restoreUnexpectedlyClearedDraft().catch(() => {});
    }, DRAFT_GUARD_INTERVAL_MS);
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") restoreUnexpectedlyClearedDraft().catch(() => {});
    });
  }

  const SUBMIT_FAILURE_TEXT_RE = /도배 방지|게시물 작성이 제한|입력 내용을 확인|보안 정책|금지어|10분 후에 다시 시도|로봇이 아님|로봇인지 확인|사람인지 확인|자동 입력|자동 등록|보안 문자|캡차|captcha|recaptcha/i;
  const ROBOT_CHALLENGE_ATTRIBUTE_RE = /captcha|recaptcha|hcaptcha|turnstile|arkose|robot/i;

  function isSubmitFailureElement(element) {
    if (!(element instanceof Element)) return false;
    const attributes = [
      element.id,
      typeof element.className === "string" ? element.className : "",
      element.getAttribute("title"),
      element.getAttribute("name"),
      element.getAttribute("src"),
      element.getAttribute("aria-label"),
    ].join(" ");
    const isChallengeContainer = /^(IFRAME|OBJECT|EMBED)$/.test(element.tagName)
      || element.matches?.('[role="dialog"], [aria-modal="true"]');
    const isKnownFailureContainer = isChallengeContainer
      || element.matches?.(".css-ye9ri9.e10kbqtd0, [class~='css-ye9ri9'][class~='e10kbqtd0']");
    if (!isKnownFailureContainer) return false;
    return SUBMIT_FAILURE_TEXT_RE.test(text(element.textContent))
      || (isChallengeContainer && ROBOT_CHALLENGE_ATTRIBUTE_RE.test(attributes));
  }

  function findSubmitFailureElement(root = document) {
    const candidates = [
      ...$$('[role="dialog"], [aria-modal="true"], .css-ye9ri9.e10kbqtd0, [class~="css-ye9ri9"][class~="e10kbqtd0"], iframe', root),
    ];
    return candidates.find(isSubmitFailureElement) || null;
  }

  function restoreDraftForSubmitFailure() {
    const failedValue = text(state.draftSubmittedValue || readDraft()?.value);
    if (!failedValue.trim()) return false;
    clearDraftSubmitPending();
    window.setTimeout(() => restoreDraftAfterFailure(failedValue), 120);
    return true;
  }

  function startDraftFailureWatch() {
    window.clearInterval(state.draftFailureWatchTimer);
    state.draftFailureWatchTimer = window.setInterval(() => {
      if (findSubmitFailureElement()) {
        restoreDraftForSubmitFailure();
        return;
      }
      const submittedAt = Number(state.draftSubmittedAt || 0);
      if (
        !submittedAt
        || Date.now() - submittedAt >= SUBMIT_CONFIRM_TIMEOUT_MS
        || Date.now() >= state.draftSubmitPendingUntil
      ) {
        restoreDraftForSubmitFailure();
      }
    }, 250);
  }

  function offerDraftRestore(writer) {
    restoreDraftOnPageLoad(writer).catch(() => {});
    startDraftGuardian();
    if (state.draftObserver) return;
    writer.dataset.entryLlnkDraftOffered = "1";
    let restoreTimer = 0;
    const scheduleRestore = () => {
      window.clearTimeout(restoreTimer);
      restoreTimer = window.setTimeout(() => restoreDraftOnPageLoad().catch(() => {}), 60);
    };
    state.draftObserver = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        const changedElements = [];
        if (mutation.target instanceof Element) changedElements.push(mutation.target);
        else if (mutation.target?.parentElement) changedElements.push(mutation.target.parentElement);
        for (const addedNode of mutation.addedNodes || []) {
          const element = addedNode instanceof Element ? addedNode : addedNode.parentElement;
          if (element) changedElements.push(element);
        }
        for (const node of changedElements) {
          if (node.matches?.(WRITER_SELECTOR) || node.querySelector?.(WRITER_SELECTOR)) scheduleRestore();
          const knownFailure = isSubmitFailureElement(node)
            || Boolean(findSubmitFailureElement(node));
          if (!knownFailure) continue;
          restoreDraftForSubmitFailure();
          return;
        }
      }
    });
    state.draftObserver.observe(document.documentElement, {
      childList: true,
      characterData: true,
      subtree: true,
    });
    window.setTimeout(scheduleRestore, 180);
  }

  function restoreDraftAfterFailure(fallbackValue = "") {
    clearDraftSubmitPending();
    const draft = readDraft();
    const writer = getWriter();
    const value = text(draft?.value || fallbackValue);
    if (!value.trim() || !writer) return;
    const current = text(writer.value);
    if (!current.trim() || current.length < value.length) {
      restoreDraftIntoWriter(writer, value, { announce: true });
    }
  }

  function playDraftRestoreAnimation(writer, value) {
    const draftValue = text(value);
    clearDraftRestoreEffects();
    if (!writer?.isConnected || !draftValue) return;
    if (!spaceshipMotionAllowed() || window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
      setDraftRestoreValue(writer, draftValue, true);
      return;
    }
    const shipUrl = getExtensionUrl("assets/draft-restore/entrybot-spaceship-1.svg");
    if (!shipUrl) {
      setDraftRestoreValue(writer, draftValue, true);
      return;
    }

    const characters = Array.from(draftValue);
    const textMetrics = measureDraftTextMetrics(writer, draftValue);
    const timing = draftFlightTiming(characters.length, textMetrics);
    const { duration } = timing;
    const flight = document.createElement("span");
    flight.className = "entry-chat-draft-flight";
    flight.dataset.entryLlnkOwned = "1";
    flight.setAttribute("aria-hidden", "true");
    flight.style.setProperty("--entry-chat-draft-flight-duration", `${duration}ms`);

    const ship = document.createElement("span");
    ship.className = "entry-chat-draft-flight-ship";
    const frame = document.createElement("img");
    frame.className = "entry-chat-draft-flight-frame";
    frame.src = shipUrl;
    frame.alt = "";
    frame.draggable = false;
    ship.appendChild(frame);
    const beam = document.createElement("span");
    beam.className = "entry-chat-draft-flight-beam";
    ship.appendChild(beam);
    flight.appendChild(ship);
    document.body.appendChild(flight);

    const currentValue = text(writer.value);
    const initialCount = draftValue.startsWith(currentValue) ? Array.from(currentValue).length : 0;
    let renderedCount = initialCount;
    let animationFrame = 0;
    let finished = false;
    let cleanup = null;
    const startedAt = Date.now();
    setDraftRestoreValue(writer, characters.slice(0, initialCount).join(""));

    const finish = (complete) => {
      if (finished) return;
      finished = true;
      window.cancelAnimationFrame(animationFrame);
      writer.removeEventListener("beforeinput", interrupt, true);
      writer.removeEventListener("pointerdown", interrupt, true);
      delete writer.dataset.entryLlnkDraftAnimating;
      if (complete && writer.isConnected) setDraftRestoreValue(writer, draftValue, true);
      flight.remove();
      if (state.draftRestoreCleanup === cleanup) state.draftRestoreCleanup = null;
    };
    const interrupt = () => finish(true);
    cleanup = (complete = false) => finish(complete);
    state.draftRestoreCleanup = cleanup;
    writer.dataset.entryLlnkDraftAnimating = "1";
    writer.addEventListener("beforeinput", interrupt, true);
    writer.addEventListener("pointerdown", interrupt, true);
    const renderFrame = () => {
      if (!writer.isConnected) {
        finish(false);
        return;
      }
      const elapsed = Date.now() - startedAt;
      const progress = Math.max(0, Math.min(1, elapsed / duration));
      const typingProgress = Math.max(0, Math.min(1, (elapsed - timing.typingStart) / timing.typingDuration));
      const nextCount = Math.max(initialCount, Math.min(characters.length, Math.floor(characters.length * typingProgress)));
      if (nextCount !== renderedCount) {
        renderedCount = nextCount;
        setDraftRestoreProgress(writer, characters.slice(0, renderedCount).join(""));
      }
      const initialProgress = characters.length ? initialCount / characters.length : 1;
      const motionWritingProgress = Math.max(initialProgress, typingProgress);
      const pose = draftFlightPose(writer, progress, timing, motionWritingProgress);
      flight.style.opacity = String(pose.opacity);
      flight.style.transform = `translate3d(${pose.x}px, ${pose.y}px, 0) perspective(680px) rotateY(${pose.yaw}deg) rotateZ(${pose.rotate}deg) scale(${pose.scale})`;
      ship.style.setProperty("--entry-chat-draft-impact-opacity", String(pose.impact * 0.82));
      ship.style.setProperty("--entry-chat-draft-impact-scale", String(0.72 + pose.impact * 0.52));
      beam.style.height = `${draftBeamHeight(writer, pose)}px`;
      if (elapsed >= duration) {
        finish(true);
        return;
      }
      animationFrame = window.requestAnimationFrame(renderFrame);
    };
    animationFrame = window.requestAnimationFrame(renderFrame);
  }

  function clearDraftRestoreEffects(complete = false) {
    const cleanup = state.draftRestoreCleanup;
    state.draftRestoreCleanup = null;
    cleanup?.(complete);
    $$(".entry-chat-draft-flight[data-entry-llnk-owned='1'], .entry-chat-draft-restore-panel[data-entry-llnk-owned='1'], .entry-chat-draft-restore-particles[data-entry-llnk-owned='1'], .entry-chat-draft-restore-message[data-entry-llnk-owned='1']").forEach((element) => element.remove());
    $$(".entry-chat-draft-restore-effect-host").forEach((element) => element.classList.remove("entry-chat-draft-restore-effect-host"));
  }

  function clearSpaceshipMotionEffects() {
    clearDraftRestoreEffects(true);
    [...state.liveArrivalCleanups].forEach((cleanup) => cleanup());
    state.nativeArrivalPending = 0;
  }

  function encodePostLineBreaks(value) {
    let breaks = 0;
    return text(value).replace(/\r\n?/g, "\n").replace(/\n/g, () => {
      breaks += 1;
      return breaks <= MAX_LINE_BREAKS ? LINE_BREAK_MARKER : " ";
    });
  }

  function encodedPostValue(value) {
    return encodePostLineBreaks(value).trim();
  }

  function prepareWriterForSubmit(writer) {
    const next = encodePostLineBreaks(writer?.value || "");
    if (!writer || next === writer.value) return;
    writer.value = next;
    writer.dispatchEvent(new Event("input", { bubbles: true }));
    writer.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function ensureCounter(writer) {
    const holder = writer.closest(".css-11v8s45, [class~='ed0ret11']") || writer.parentElement || writer;
    let counter = $("[data-entry-chat-upload-counter='1']", holder);
    if (!counter) {
      counter = document.createElement("div");
      counter.className = "entry-chat-upload-counter";
      counter.dataset.entryChatUploadCounter = "1";
      counter.dataset.entryLlnkOwned = "1";
      holder.appendChild(counter);
    }
    updateCounter(writer);
  }

  function updateCounter(writer) {
    const holder = writer.closest(".css-11v8s45, [class~='ed0ret11']") || writer.parentElement || writer;
    const counter = $("[data-entry-chat-upload-counter='1']", holder);
    if (!counter) return;
    const count = [...encodedPostValue(writer.value)].length;
    counter.textContent = `${count}/${MAX_POST_LENGTH}`;
    counter.classList.toggle("is-over", count > MAX_POST_LENGTH);
    counter.dataset.entryChatOverLimit = count > MAX_POST_LENGTH ? "1" : "0";
  }

  function chooseImage(writer) {
    const picker = document.createElement("input");
    picker.type = "file";
    picker.accept = "image/*";
    picker.hidden = true;
    picker.addEventListener("change", () => {
      const file = picker.files?.[0];
      picker.remove();
      if (!file) return;
      if (!/^image\//i.test(file.type)) {
        return;
      }
      uploadImageThroughEntry(writer, file);
    }, { once: true });
    document.documentElement.appendChild(picker);
    picker.click();
  }

  function normalizeEntryImageUrl(value) {
    let source = text(value).trim();
    if (!source || !source.includes("/uploads/")) return "";
    for (let index = 0; index < 2; index += 1) {
      const box = document.createElement("textarea");
      box.innerHTML = source;
      const decoded = box.value;
      if (!decoded || decoded === source) break;
      source = decoded.trim();
    }
    source = source.replace(/^url\((.*)\)$/i, "$1").trim().replace(/^['"]|['"]$/g, "");
    const match = source.match(/(?:(?:https?:)?\/\/playentry\.org)?\/uploads\/[^"'()<>\s]+?\.(?:png|jpe?g|gif|webp|svg)(?:\?[^"'()<>\s]*)?/i);
    if (!match) return "";
    let raw = match[0];
    if (raw.startsWith("//")) raw = `https:${raw}`;
    if (raw.startsWith("/uploads/")) raw = `https://playentry.org${raw}`;
    raw = raw.replace(/&amp;/gi, "&").replace(/[;,]+$/g, "");
    const url = safeHttpUrl(raw, "https://playentry.org");
    if (!url || url.hostname !== "playentry.org" || !url.pathname.startsWith("/uploads/")) return "";
    if (/^\/uploads\/(?:fonts|thumb)\//i.test(url.pathname) || /EmptyImage\.svg$/i.test(url.pathname)) return "";
    return url.href;
  }

  function walkFrameDocuments(doc, callback, depth = 0) {
    if (!doc || depth > 4) return null;
    const result = callback(doc);
    if (result) return result;
    for (const frame of $$('iframe, frame', doc)) {
      try {
        const nested = walkFrameDocuments(frame.contentDocument, callback, depth + 1);
        if (nested) return nested;
      } catch (_) {}
    }
    return null;
  }

  function scanUploadedImage(doc) {
    return walkFrameDocuments(doc, (target) => {
      const roots = $$(".se-component.se-image, .se-section-image, .se-module-image, .__se-module-image", target);
      const candidates = [];
      roots.forEach((root) => {
        $$('[src*="/uploads/"], [src*="playentry.org/uploads/"]', root)
          .forEach((element) => candidates.push(element.getAttribute("src") || ""));
        $$('[srcset*="/uploads/"], [srcset*="playentry.org/uploads/"]', root).forEach((element) => {
          text(element.getAttribute("srcset") || "").split(",")
            .forEach((part) => candidates.push(part.trim().split(/\s+/)[0] || ""));
        });
        $$('[data-src*="/uploads/"], [data-url*="/uploads/"]', root)
          .forEach((element) => candidates.push(element.getAttribute("data-src") || element.getAttribute("data-url") || ""));
        $$('[style*="/uploads/"]', root).forEach((element) => {
          const matches = text(element.getAttribute("style")).match(/url\((['"]?)([^'")]+\/uploads\/[^'")]+)\1\)/gi) || [];
          matches.forEach((item) => candidates.push(item.replace(/^url\((['"]?)/i, "").replace(/(['"]?)\)$/i, "")));
        });
      });
      return candidates.map(normalizeEntryImageUrl).find(Boolean) || "";
    });
  }

  function scanImageUploadError(doc) {
    return walkFrameDocuments(doc, (target) => {
      const nodes = $$('[role="alert"], [role="dialog"], [aria-modal="true"], [aria-live="assertive"], [aria-live="polite"], .css-ye9ri9.e10kbqtd0, [class*="error"], [class*="Error"], [class*="toast"], [class*="Toast"]', target);
      for (const node of nodes) {
        const style = target.defaultView?.getComputedStyle(node);
        if (style?.display === "none" || style?.visibility === "hidden") continue;
        const message = text(node.textContent).replace(/\s+/g, " ").trim();
        if (!message) continue;
        const uploadFailure = /요청을\s*처리하지\s*못했습니다|(?:업로드|파일|이미지).{0,60}(?:실패|오류|초과|불가|지원하지|처리하지|너무\s*(?:크|큽)|제한)|(?:실패|오류|초과|불가|지원하지|처리하지).{0,60}(?:업로드|파일|이미지)|(?:최대|제한).{0,40}(?:MB|KB|GB|용량|크기)/i;
        if (uploadFailure.test(message)) return message.slice(0, 180);
      }
      const invalidInput = $$('input[type="file"]', target).find((input) => input.validity && !input.validity.valid);
      return text(invalidInput?.validationMessage).replace(/\s+/g, " ").trim().slice(0, 180);
    });
  }

  function formatImageUploadError() {
    return "업로드할 수 없는 파일입니다.";
  }

  function showImageUploadError(message) {
    $(".entry-chat-image-upload-error")?.remove();
    const notice = document.createElement("div");
    notice.className = "entry-chat-image-upload-error";
    notice.dataset.entryLlnkOwned = "1";
    notice.setAttribute("role", "alert");

    const ship = document.createElement("img");
    ship.className = "entry-chat-image-upload-error-ship";
    const shipUrl = getExtensionUrl("assets/draft-restore/entrybot-spaceship-1.svg");
    if (shipUrl) ship.src = shipUrl;
    else ship.hidden = true;
    ship.alt = "";
    ship.setAttribute("aria-hidden", "true");

    const card = document.createElement("div");
    card.className = "entry-chat-image-upload-error-card";
    const title = document.createElement("strong");
    title.className = "entry-chat-image-upload-error-title";
    title.textContent = "이미지 업로드 실패";
    const body = document.createElement("p");
    body.className = "entry-chat-image-upload-error-message";
    body.textContent = formatImageUploadError(message);
    card.append(title, body);
    notice.append(ship, card);
    document.body.appendChild(notice);
    notice.addEventListener("animationend", () => notice.remove(), { once: true });
    window.setTimeout(() => notice.remove(), 7200);
  }

  function findImageFileInput(doc, depth = 0) {
    if (!doc || depth > 4) return null;
    const input = $$('input[type="file"]', doc).find((element) => {
      const accept = text(element.getAttribute("accept"));
      const name = text(`${element.name || ""} ${element.id || ""} ${element.className || ""} ${element.getAttribute("aria-label") || ""}`);
      return !element.disabled && (/image|\.(?:png|jpe?g|gif|webp|svg)/i.test(accept) || /image|photo|사진|이미지|file|upload|img/i.test(name));
    });
    if (input) return input;
    for (const frame of $$('iframe, frame', doc)) {
      try {
        const nested = findImageFileInput(frame.contentDocument, depth + 1);
        if (nested) return nested;
      } catch (_) {}
    }
    return null;
  }

  function injectSelectedImageFile(doc, file) {
    const input = findImageFileInput(doc);
    if (!input || input.dataset.entryLlnkInjected === "1") return null;
    try {
      const view = input.ownerDocument?.defaultView || window;
      const Transfer = view.DataTransfer || DataTransfer;
      const transfer = new Transfer();
      transfer.items.add(file);
      input.files = transfer.files;
      input.dataset.entryLlnkInjected = "1";
      input.dispatchEvent(new view.Event("input", { bubbles: true }));
      input.dispatchEvent(new view.Event("change", { bubbles: true }));
      return input;
    } catch (_) {
      return null;
    }
  }

  function findImageToolbarButton(doc) {
    return walkFrameDocuments(doc, (target) => {
      const selectors = [
        'button.se-image-toolbar-button[data-key="image"]',
        'button.se-image-toolbar-button[data-name="image"]',
        'button[data-logcode="dot.img"]',
        'button[data-key="image"][data-type="basic"]',
        'button[title*="사진"]',
      ];
      const usable = (element) => {
        const style = element && target.defaultView?.getComputedStyle(element);
        return element && !element.disabled && style?.display !== "none" && style?.visibility !== "hidden";
      };
      const button = selectors.map((selector) => $(selector, target)).find(usable) || $$('button, [role="button"]', target).find((element) => {
        const label = `${text(element.textContent)} ${element.title || ""} ${element.getAttribute("aria-label") || ""}`;
        return usable(element) && /사진|이미지|image|photo/i.test(label);
      });
      return button || null;
    });
  }

  function clickImageToolbar(doc) {
    const button = findImageToolbarButton(doc);
    if (!button) return null;
    const now = Date.now();
    if (now - Number(button.dataset.entryLlnkLastClickAt || 0) < 900) return null;
    button.dataset.entryLlnkLastClickAt = String(now);
    try {
      const view = button.ownerDocument?.defaultView || window;
      button.scrollIntoView?.({ block: "center", inline: "center" });
      ["pointerdown", "mousedown", "pointerup", "mouseup"].forEach((type) => {
        const EventClass = type.startsWith("pointer") && view.PointerEvent ? view.PointerEvent : view.MouseEvent;
        button.dispatchEvent(new EventClass(type, { bubbles: true, cancelable: true, composed: true, button: 0, view }));
      });
      view.HTMLButtonElement?.prototype?.click?.call(button);
    } catch (_) {
      try { button.click?.(); } catch (_) {}
    }
    return button;
  }

  function uploadImageThroughEntry(writer, file) {
    state.uploadCleanup?.();
    const overlay = document.createElement("div");
    overlay.className = "entry-chat-image-upload-layer entry-chat-image-upload-layer-silent";
    overlay.dataset.entryLlnkOwned = "1";
    const hint = document.createElement("p");
    hint.className = "entry-chat-image-upload-hint";
    hint.textContent = "이미지 업로드를 감지하고 있습니다.";
    const iframe = document.createElement("iframe");
    iframe.className = "entry-chat-image-upload-frame";
    iframe.title = "엔트리 이미지 업로더";
    iframe.setAttribute("aria-hidden", "true");
    iframe.src = `/community/tips/write?entry_llnk_image_upload=${Date.now()}`;
    Object.assign(iframe.style, {
      position: "absolute",
      display: "block",
      left: "0",
      top: "0",
      width: "100%",
      height: "100%",
      border: "0",
      background: "#fff",
      opacity: "0.01",
      pointerEvents: "none",
      zIndex: "-1",
    });
    overlay.append(hint, iframe);
    document.body.appendChild(overlay);
    let timer = 0;
    let timeout = 0;
    let frameObserver = null;
    let messageHandler = null;
    let finished = false;
    let registering = false;
    const cleanup = () => {
      if (finished) return;
      finished = true;
      clearInterval(timer);
      clearTimeout(timeout);
      frameObserver?.disconnect();
      if (messageHandler) window.removeEventListener("message", messageHandler);
      overlay.remove();
      state.uploadCleanup = null;
      syncImageControlState();
    };
    const fail = (message) => {
      if (finished) return;
      cleanup();
      showImageUploadError(message);
    };
    state.uploadCleanup = cleanup;
    syncImageControlState();
    const finish = async (url) => {
      if (finished || registering) return;
      registering = true;
      clearInterval(timer);
      hint.textContent = "이미지를 적용하고 있습니다.";
      showImageAttachmentPreview(writer, url, "");
      cleanup();
      try {
        const payload = await Ringcl.api("images.php", {
          method: "POST",
          body: { image_url: url },
        });
        const code = text(payload.code || "").trim().toLowerCase();
        if (!/^[a-z0-9]{4}$/.test(code)) throw new Error("이미지 링크를 만들지 못했습니다.");
        showImageAttachmentPreview(writer, payload.image_url || url, code);
      } catch (error) {
        registering = false;
        removeImageAttachment(writer, $("[data-entry-chat-image-preview-panel='1']"));
      }
    };
    const detectUploadedUrl = (value) => {
      const url = normalizeEntryImageUrl(value);
      if (url) finish(url);
      return Boolean(url);
    };
    const inspect = () => {
      let doc;
      try { doc = iframe.contentDocument; } catch (_) { return; }
      if (!doc?.documentElement) return;
      const uploaded = scanUploadedImage(doc);
      if (uploaded) {
        finish(uploaded);
        return;
      }
      const uploadError = scanImageUploadError(doc);
      if (uploadError) {
        fail(uploadError);
        return;
      }
      if (!injectSelectedImageFile(doc, file)) {
        clickImageToolbar(doc);
        injectSelectedImageFile(doc, file);
      }
    };
    const observeFrame = () => {
      frameObserver?.disconnect();
      try {
        const doc = iframe.contentDocument;
        if (!doc?.body) return;
        frameObserver = new MutationObserver(inspect);
        frameObserver.observe(doc.body, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ["src", "srcset", "data-src", "data-url", "style", "class"],
        });
      } catch (_) {
        frameObserver = null;
      }
    };
    messageHandler = (event) => {
      if (event.origin !== "https://playentry.org") return;
      const data = event.data || {};
      if (data.source !== "entry-llnk-image-upload") return;
      if (data.error) {
        fail(data.error);
        return;
      }
      detectUploadedUrl(data.imageUrl || "");
    };
    window.addEventListener("message", messageHandler);
    iframe.addEventListener("load", () => {
      observeFrame();
      inspect();
    });
    timer = window.setInterval(inspect, 450);
    timeout = window.setTimeout(() => {
      if (finished) return;
      fail("업로드할 수 없는 파일입니다.");
    }, 30000);
  }

  function getPendingImageCode() {
    const panel = $("[data-entry-chat-image-preview-panel='1'].is-visible");
    const code = text(panel?.dataset.imageCode || "").trim().toLowerCase();
    return /^[a-z0-9]{4}$/.test(code) ? code : "";
  }

  function imageShortLink(code) {
    const normalized = text(code).trim().toLowerCase();
    return /^[a-z0-9]{4}$/.test(normalized) ? `${IMAGE_SHORT_LINK_BASE}${normalized}` : "";
  }

  function getPendingImageShortLink() {
    const panel = $("[data-entry-chat-image-preview-panel='1'].is-visible");
    if (panel?.dataset.imageLinkReady !== "1") return "";
    return imageShortLink(getPendingImageCode());
  }

  function appendPendingImageShortLink(value) {
    const source = text(value);
    const shortLink = getPendingImageShortLink();
    if (!shortLink || source.includes(shortLink)) return source;
    return `${source.trimEnd()} ${shortLink}`;
  }

  function prepareImageSubmit(event, writer = getWriter()) {
    const panel = $("[data-entry-chat-image-preview-panel='1'].is-visible");
    if (!writer || !panel) return false;
    if (!getPendingImageCode()) {
      event.preventDefault();
      event.stopImmediatePropagation?.();
      return true;
    }
    if (!getPendingImageShortLink()) {
      event.preventDefault();
      event.stopImmediatePropagation?.();
      return true;
    }
    const nextValue = appendPendingImageShortLink(writer.value);
    if (nextValue !== writer.value) {
      writer.value = nextValue;
      writer.dispatchEvent(new Event("input", { bubbles: true }));
      writer.dispatchEvent(new Event("change", { bubbles: true }));
    }
    return false;
  }

  function showImageAttachmentPreview(writer, url, code) {
    $("[data-entry-chat-image-preview-panel='1']")?.remove();
    const form = writer.closest(".css-1uvivr9.ed0ret1, [class~='css-1uvivr9'][class~='ed0ret1'], .css-cbwem1.e1lgujxn2, [class~='css-cbwem1'][class~='e1lgujxn2']") || writer.parentElement;
    if (!form) return;
    const panel = document.createElement("div");
    panel.className = "entry-chat-image-compose-preview";
    panel.dataset.entryChatImagePreviewPanel = "1";
    panel.dataset.entryLlnkOwned = "1";
    panel.dataset.imageUrl = url;
    const normalizedCode = text(code).trim().toLowerCase();
    panel.dataset.imageCode = normalizedCode;
    if (/^[a-z0-9]{4}$/.test(normalizedCode)) panel.dataset.imageLinkReady = "1";
    const label = document.createElement("strong");
    label.textContent = normalizedCode ? "이미지 첨부됨" : "이미지 저장 중...";
    const quota = document.createElement("span");
    quota.className = "entry-chat-file-quota-line";
    quota.textContent = "이미지 · LLNKKR";
    const image = document.createElement("img");
    image.src = url;
    image.alt = "업로드된 이미지";
    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "entry-chat-image-preview-remove";
    remove.title = "이미지 첨부 제거";
    remove.setAttribute("aria-label", "이미지 첨부 제거");
    remove.textContent = "×";
    remove.addEventListener("click", () => removeImageAttachment(writer, panel));
    panel.append(label, quota, remove, image);
    const shortLink = imageShortLink(code);
    if (shortLink) {
      panel.dataset.imageShortUrl = shortLink;
    }
    const writerLabel = writer.closest("label") || writer.closest(".css-19sv4op.ed0ret2, [class~='css-19sv4op'][class~='ed0ret2']");
    const controls = $(".css-ljggwk.ed0ret3, [class~='css-ljggwk'][class~='ed0ret3']", form);
    if (writerLabel?.parentElement === form) writerLabel.insertAdjacentElement("afterend", panel);
    else if (controls?.parentElement === form) form.insertBefore(panel, controls);
    else form.appendChild(panel);
    panel.classList.add("is-visible");
    syncImageControlState();
    panel.scrollIntoView?.({ block: "nearest", inline: "nearest" });
  }

  function removeImageAttachment(writer = getWriter(), panel = $("[data-entry-chat-image-preview-panel='1']")) {
    if (!panel) return;
    const phrase = panel.dataset.imagePhrase || "";
    const shortLink = panel.dataset.imageShortUrl || imageShortLink(panel.dataset.imageCode || "");
    if (writer && (phrase || shortLink)) {
      writer.value = text(writer.value)
        .replace(phrase, "")
        .replace(shortLink, "")
        .trim();
      writer.dispatchEvent(new Event("input", { bubbles: true }));
      writer.dispatchEvent(new Event("change", { bubbles: true }));
    }
    panel.remove();
    syncImageControlState();
  }

  function syncImageControlState() {
    const panel = $("[data-entry-chat-image-preview-panel='1'].is-visible");
    const active = Boolean(getPendingImageCode());
    const pending = Boolean((panel && !active) || $(".entry-chat-image-upload-layer"));
    $$('[data-entry-chat-image-control="1"]').forEach((control) => {
      const button = $(".entry-chat-image-toggle", control);
      button?.classList.toggle("is-attached", active);
      button?.classList.toggle("is-loading", pending);
      button?.classList.toggle("is-ready", !pending);
      button?.setAttribute("aria-pressed", active ? "true" : "false");
      if (button) button.title = active
        ? "이미지 첨부 제거"
        : pending
          ? "이미지 단축링크를 준비하고 있습니다."
          : "이미지를 첨부합니다.";
    });
  }

  async function fetchLivePosts(signal) {
    const params = new URLSearchParams(location.search);
    const query = `query SELECT_ENTRYSTORY($pageParam: PageParam, $query: String, $category: String, $term: String, $discussType: String, $searchType: String) {
      discussList(pageParam: $pageParam, query: $query, category: $category, term: $term, discussType: $discussType, searchType: $searchType) {
        list { id content created commentsLength likesLength isLike user { id nickname profileImage { filename imageType } } image { filename imageType } sticker { filename imageType } }
      }
    }`;
    const data = await Ringcl.entryGraphql("SELECT_ENTRYSTORY", query, {
      category: "free",
      searchType: "scroll",
      term: text(params.get("term") || "all"),
      discussType: "entrystory",
      query: text(params.get("query") || params.get("q") || "") || undefined,
      pageParam: { display: 10, sort: "created" },
    }, { signal });
    return Array.isArray(data?.discussList?.list) ? data.discussList.list : [];
  }

  function entryAssetUrl(asset) {
    const filename = text(asset?.filename).trim();
    if (!/^[a-z0-9_-]{4,}$/i.test(filename)) return "";
    const extension = /^[a-z0-9]+$/i.test(text(asset?.imageType)) ? `.${asset.imageType}` : "";
    return `/uploads/${filename.slice(0, 2)}/${filename.slice(2, 4)}/${filename}${extension}`;
  }

  function formatLiveDate(value) {
    const date = new Date(value || 0);
    if (!Number.isFinite(date.getTime())) return "";
    const part = (number) => String(number).padStart(2, "0");
    return `${part(date.getFullYear() % 100)}.${part(date.getMonth() + 1)}.${part(date.getDate())} ・ ${part(date.getHours())}:${part(date.getMinutes())}`;
  }

  function makeLiveElement(tag, className = "", value = "") {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (value !== "") element.textContent = value;
    return element;
  }

  function metricParts(value) {
    const source = text(value);
    const match = source.match(/(-?\d+)\s*$/);
    if (!match) return null;
    return {
      count: Math.max(0, Number(match[1]) || 0),
      prefix: source.slice(0, match.index),
    };
  }

  function metricTextNode(element) {
    const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
    let matched = null;
    let node = walker.nextNode();
    while (node) {
      if (!node.parentElement?.closest(".entry-llnk-metric-dial-layer") && /-?\d+\s*$/.test(node.nodeValue || "")) {
        matched = node;
      }
      node = walker.nextNode();
    }
    return matched;
  }

  function metricBackground(element) {
    let current = element;
    while (current instanceof Element) {
      const color = getComputedStyle(current).backgroundColor;
      const channels = color?.match(/[\d.]+/g)?.map(Number) || [];
      if (color && color !== "transparent" && (channels.length < 4 || channels[3] > 0)) return color;
      current = current.parentElement;
    }
    return getComputedStyle(document.body).backgroundColor || "#fff";
  }

  function metricNumberBox(element, previous, next) {
    const node = metricTextNode(element);
    const source = node?.nodeValue || "";
    const match = source.match(/(-?\d+)\s*$/);
    if (!node || !match) return null;
    const range = document.createRange();
    range.setStart(node, match.index);
    range.setEnd(node, match.index + match[1].length);
    const numberRect = range.getBoundingClientRect();
    const hostRect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    const canvas = metricNumberBox.canvas || (metricNumberBox.canvas = document.createElement("canvas"));
    const context = canvas.getContext("2d");
    if (context) context.font = style.font;
    const measuredWidth = context
      ? Math.max(context.measureText(String(previous)).width, context.measureText(String(next)).width)
      : numberRect.width;
    return {
      top: numberRect.top - hostRect.top,
      left: numberRect.left - hostRect.left,
      width: Math.max(numberRect.width, measuredWidth) + 2,
      height: numberRect.height || hostRect.height,
      background: metricBackground(element),
    };
  }

  function finishMetricDial(element) {
    const timer = metricAnimationTimers.get(element);
    if (timer) window.clearTimeout(timer);
    metricAnimationTimers.delete(element);
    element.querySelector(":scope > .entry-llnk-metric-dial-layer")?.remove();
    element.classList.remove(
      "entry-llnk-metric-dial",
      "entry-llnk-metric-dial-up",
      "entry-llnk-metric-dial-down"
    );
    element.style.removeProperty("--entry-llnk-metric-color");
    element.style.removeProperty("--entry-llnk-metric-top");
    element.style.removeProperty("--entry-llnk-metric-left");
    element.style.removeProperty("--entry-llnk-metric-width");
    element.style.removeProperty("--entry-llnk-metric-height");
    element.style.removeProperty("--entry-llnk-metric-background");
  }

  function animateMetricDial(element, previous, next) {
    if (!(element instanceof Element) || previous === next) return;
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches) return;
    finishMetricDial(element);
    const box = metricNumberBox(element, previous, next);
    if (!box) return;
    element.style.setProperty("--entry-llnk-metric-color", getComputedStyle(element).color);
    element.style.setProperty("--entry-llnk-metric-top", `${box.top}px`);
    element.style.setProperty("--entry-llnk-metric-left", `${box.left}px`);
    element.style.setProperty("--entry-llnk-metric-width", `${box.width}px`);
    element.style.setProperty("--entry-llnk-metric-height", `${box.height}px`);
    element.style.setProperty("--entry-llnk-metric-background", box.background);
    const layer = document.createElement("span");
    layer.className = "entry-llnk-metric-dial-layer";
    layer.dataset.entryLlnkOwned = "1";
    const oldValue = document.createElement("span");
    oldValue.className = "entry-llnk-metric-dial-old";
    oldValue.textContent = String(previous);
    const nextValue = document.createElement("span");
    nextValue.className = "entry-llnk-metric-dial-next";
    nextValue.textContent = String(next);
    layer.append(oldValue, nextValue);
    element.appendChild(layer);
    element.classList.add(
      "entry-llnk-metric-dial",
      next > previous ? "entry-llnk-metric-dial-up" : "entry-llnk-metric-dial-down"
    );
    const timer = window.setTimeout(() => finishMetricDial(element), 390);
    metricAnimationTimers.set(element, timer);
  }

  function syncMetricElement(element) {
    if (!(element instanceof Element)) return;
    if (element.classList.contains("entry-llnk-metric-dial")) finishMetricDial(element);
    const parts = metricParts(element.textContent);
    if (!parts) return;
    const previous = Number(element.dataset.entryLlnkMetricValue);
    element.dataset.entryLlnkMetricValue = String(parts.count);
    if (Number.isFinite(previous) && previous !== parts.count) {
      animateMetricDial(element, previous, parts.count);
    }
  }

  function syncMetricCounters(root = document) {
    if (root instanceof Element && root.closest(".entry-llnk-metric-dial-layer")) return;
    const counters = [];
    if (root instanceof Element) {
      const ownCounter = root.matches(METRIC_SELECTOR) ? root : root.closest(METRIC_SELECTOR);
      if (ownCounter) counters.push(ownCounter);
    }
    counters.push(...$$(METRIC_SELECTOR, root));
    [...new Set(counters)].forEach(syncMetricElement);
  }

  function setMetricCount(element, count) {
    if (!(element instanceof Element)) return;
    const parts = metricParts(element.textContent);
    if (!parts) return;
    element.textContent = `${parts.prefix}${Math.max(0, Number(count) || 0)}`;
    syncMetricElement(element);
  }

  function updateLivePostElement(element, post) {
    if (!element || !post?.id) return;
    element.entryLlnkPost = post;
    element.dataset.entryLlnkLiveId = text(post.id);
    element.dataset.entryChatLivePostId = text(post.id);
    const profileId = text(post.user?.id).trim();
    const profileHref = /^[a-f0-9]{24}$/i.test(profileId) ? `/profile/${profileId}` : "/";
    $$('[data-entry-chat-live-profile="1"]', element).forEach((link) => {
      link.setAttribute("href", profileHref);
    });
    const avatar = $("[data-entry-chat-live-avatar='1']", element);
    if (avatar) {
      avatar.style.backgroundImage = `url("${entryAssetUrl(post.user?.profileImage) || "/img/EmptyImage.svg"}"), url("/img/EmptyImage.svg")`;
    }
    const nickname = $("[data-entry-chat-live-nickname='1']", element);
    if (nickname) nickname.textContent = text(post.user?.nickname || "엔트리");
    const created = $("[data-entry-chat-live-date='1']", element);
    if (created) created.textContent = formatLiveDate(post.created);
    const body = $("[data-entry-chat-live-body='1']", element);
    const content = text(post.content || "");
    if (body && body.dataset.entryLlnkOriginal !== content) {
      body.dataset.entryLlnkOriginal = content;
      body.replaceChildren(...renderContent(content));
    }
    const like = $("[data-entry-chat-live-like='1']", element);
    if (like && like.dataset.entryChatLiveBusy !== "1") {
      setMetricCount(like, post.likesLength);
      like.classList.toggle("active", Boolean(post.isLike));
    }
    const reply = $("[data-entry-chat-live-reply='1']", element);
    if (reply) setMetricCount(reply, post.commentsLength);
    const media = $("[data-entry-chat-live-media='1']", element);
    if (media) {
      media.replaceChildren();
      media.classList.toggle("is-native-reaction", Boolean(post.sticker));
      const asset = post.sticker || post.image || null;
      const assetUrl = entryAssetUrl(asset);
      if (assetUrl) {
        const image = document.createElement("img");
        image.src = assetUrl;
        image.alt = post.sticker ? "sticker" : "image";
        image.loading = "lazy";
        media.appendChild(image);
        media.hidden = false;
      } else {
        media.hidden = true;
      }
    }
    shortenProjectLinks(element);
    applyStoryFilters(element);
  }

  function renderNativePostFromData(element, post) {
    const body = element instanceof Element ? $(BODY_SELECTOR, element) : null;
    const content = text(post?.content || "").trim();
    if (!body || !content) return;
    renderPostBody(body, content, true);
    shortenProjectLinks(element);
    applyStoryFilters(element);
  }

  async function toggleLivePostLike(postId, liked = false) {
    const target = text(postId).trim();
    if (!target) throw new Error("글 정보를 찾을 수 없습니다.");
    if (liked) {
      const query = `mutation UNLIKE($target: String, $groupId: ID) {
        unlike(target: $target, groupId: $groupId) { target targetSubject targetType }
      }`;
      const data = await Ringcl.entryGraphql("UNLIKE", query, { target });
      if (text(data?.unlike?.target).trim() !== target) throw new Error("좋아요 취소 결과를 확인하지 못했습니다.");
      return false;
    }
    const query = `mutation LIKE($target: String, $targetSubject: String, $targetType: String, $groupId: ID) {
      like(target: $target, targetSubject: $targetSubject, targetType: $targetType, groupId: $groupId) {
        target targetSubject targetType
      }
    }`;
    const data = await Ringcl.entryGraphql("LIKE", query, {
      target,
      targetSubject: "discuss",
    });
    if (text(data?.like?.target).trim() !== target) throw new Error("좋아요 결과를 확인하지 못했습니다.");
    return true;
  }

  function createLivePost(post) {
    Ringcl.ensureIconFont?.();
    const item = makeLiveElement("li", "css-tasfte eqmdslz0 entry-chat-live-entry-story-post");
    item.dataset.entryLlnkLiveId = text(post.id);
    item.dataset.entryChatLivePostId = text(post.id);
    item.dataset.entryLlnkOwned = "1";
    const profileId = text(post.user?.id).trim();
    const profileHref = /^[a-f0-9]{24}$/i.test(profileId) ? `/profile/${profileId}` : "/";
    const card = makeLiveElement("div", "css-12e6n38 e1uj27uy0");
    const profile = makeLiveElement("a");
    profile.href = profileHref;
    profile.dataset.entryChatLiveProfile = "1";
    const avatar = makeLiveElement("div", "css-1r40lgp ec9h6r90");
    avatar.dataset.entryChatLiveAvatar = "1";
    avatar.style.backgroundImage = `url("${entryAssetUrl(post.user?.profileImage) || "/img/EmptyImage.svg"}"), url("/img/EmptyImage.svg")`;
    avatar.appendChild(makeLiveElement("span", "blind", "유저 썸네일"));
    profile.appendChild(avatar);

    const author = makeLiveElement("div", "css-lz5fzu e143sozh0");
    const nickname = makeLiveElement("a", "", text(post.user?.nickname || "엔트리"));
    nickname.href = profileHref;
    nickname.dataset.entryChatLiveProfile = "1";
    nickname.dataset.entryChatLiveNickname = "1";
    const created = makeLiveElement("em", "", formatLiveDate(post.created));
    created.dataset.entryChatLiveDate = "1";
    author.append(nickname, created);

    const body = makeLiveElement("div", "css-6wq60h eqt5hs60 entry-chat-markdown-rendered");
    body.dataset.entryChatLiveBody = "1";
    body.dataset.entryLlnkOwned = "1";
    body.dataset.entryLlnkOriginal = text(post.content || "");
    renderContent(post.content || "").forEach((child) => body.appendChild(child));
    const media = makeLiveElement("em", "entry-chat-live-entry-story-media");
    media.dataset.entryChatLiveMedia = "1";
    media.classList.toggle("is-native-reaction", Boolean(post.sticker));
    const assetUrl = entryAssetUrl(post.sticker || post.image);
    if (assetUrl) {
      const image = document.createElement("img");
      image.src = assetUrl;
      image.alt = post.sticker ? "sticker" : "image";
      image.loading = "lazy";
      media.appendChild(image);
    } else {
      media.hidden = true;
    }

    const actions = makeLiveElement("div", "css-1dcwahm e50391u0");
    const likeWrap = makeLiveElement("em");
    const like = makeLiveElement("a", `like${post.isLike ? " active" : ""}`, `좋아요 ${Math.max(0, Number(post.likesLength || 0))}`);
    like.role = "button";
    like.dataset.entryChatLiveLike = "1";
    const replyWrap = makeLiveElement("em");
    const reply = makeLiveElement("a", "reply", `댓글 ${Math.max(0, Number(post.commentsLength || 0))}`);
    reply.role = "button";
    reply.dataset.entryChatLiveReply = "1";
    likeWrap.appendChild(like);
    replyWrap.appendChild(reply);
    actions.append(likeWrap, replyWrap);
    like.addEventListener("click", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (like.dataset.entryChatLiveBusy === "1") return;
      like.dataset.entryChatLiveBusy = "1";
      const currentPost = item.entryLlnkPost || post;
      const previousLiked = Boolean(currentPost.isLike);
      const previousCount = Math.max(0, Number(currentPost.likesLength || 0));
      const nextLiked = !previousLiked;
      const nextCount = Math.max(0, previousCount + (nextLiked ? 1 : -1));
      currentPost.isLike = nextLiked;
      currentPost.likesLength = nextCount;
      like.classList.toggle("active", nextLiked);
      setMetricCount(like, nextCount);
      try {
        currentPost.isLike = await toggleLivePostLike(currentPost.id, previousLiked);
      } catch {
        currentPost.isLike = previousLiked;
        currentPost.likesLength = previousCount;
        like.classList.toggle("active", previousLiked);
        setMetricCount(like, previousCount);
      } finally {
        delete like.dataset.entryChatLiveBusy;
      }
    });
    reply.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      queueLiveReplyOpen(item.entryLlnkPost || post);
    });

    const menu = makeLiveElement("div", "css-c5zb45 e1omy4ml0");
    const refresh = makeLiveElement("button", "entry-chat-live-entry-story-detail");
    refresh.type = "button";
    refresh.title = "페이지 새로고침";
    refresh.setAttribute("aria-label", "페이지 새로고침");
    refresh.appendChild(createComposeIcon("refresh", ""));
    refresh.addEventListener("click", () => location.reload());
    menu.appendChild(refresh);
    card.append(profile, author, body, media, actions, menu);
    item.append(card, document.createElement("div"));
    updateLivePostElement(item, post);
    return item;
  }

  function normalizeLivePostKey(value) {
    return text(value)
      .replace(/https:\/\/llnk\.kr\//gi, "https://llnk.kr/")
      .replace(/[\u00b7\u30fb\u318d]/g, "\u00b7")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 500);
  }

  function getLivePostKeyFromElement(post) {
    if (!(post instanceof Element)) return "";
    const bodyNode = $(BODY_SELECTOR, post);
    const body = text(
      bodyNode?.dataset?.entryChatLiveRaw
      || bodyNode?.dataset?.entryLlnkOriginal
      || bodyNode?.textContent
      || ""
    );
    const author = text($(".css-lz5fzu a[href^='/profile/'], [class~='e143sozh0'] a[href^='/profile/']", post)?.textContent || "");
    const created = text($(".css-lz5fzu em, [class~='e143sozh0'] em", post)?.textContent || "");
    return normalizeLivePostKey(`${author}\n${created}\n${body}`);
  }

  function getLivePostKeyFromData(post) {
    if (!post) return "";
    return normalizeLivePostKey(`${text(post.user?.nickname || "")}\n${formatLiveDate(post.created)}\n${text(post.content || "")}`);
  }

  function queueLiveReplyOpen(post) {
    const pending = {
      id: text(post?.id).trim(),
      key: getLivePostKeyFromData(post),
    };
    if (!pending.id && !pending.key) return;
    try {
      sessionStorage.setItem(LIVE_REPLY_PENDING_SESSION_KEY, JSON.stringify(pending));
    } catch (_) {
    }
    location.reload();
  }

  function readPendingLiveReply() {
    try {
      const pending = JSON.parse(sessionStorage.getItem(LIVE_REPLY_PENDING_SESSION_KEY) || "null");
      return pending && typeof pending === "object"
        ? { id: text(pending.id).trim(), key: text(pending.key).trim() }
        : null;
    } catch (_) {
      return null;
    }
  }

  function openPendingLiveReply(list = getList()) {
    const pending = readPendingLiveReply();
    if (!pending || !list) return false;
    const row = getLiveRows(list).find((candidate) => {
      if (candidate.classList.contains("entry-chat-live-entry-story-post")) return false;
      const candidateId = text(candidate.dataset.entryChatLivePostId).trim();
      return (pending.id && candidateId === pending.id)
        || (pending.key && getLivePostKeyFromElement(candidate) === pending.key);
    });
    const reply = row?.querySelector("a.reply, [class~='reply']");
    if (!(reply instanceof HTMLElement)) return false;
    try {
      sessionStorage.removeItem(LIVE_REPLY_PENDING_SESSION_KEY);
    } catch (_) {
    }
    reply.click();
    row.scrollIntoView({ block: "nearest" });
    return true;
  }

  function getLivePostIdentityFromElement(post) {
    if (!(post instanceof Element)) return "";
    const profileLink = $(".css-lz5fzu a[href^='/profile/'], [class~='e143sozh0'] a[href^='/profile/']", post);
    const profileMatch = text(profileLink?.getAttribute("href") || "").match(/^\/profile\/([a-f0-9]{24})/i);
    const author = text(profileLink?.textContent || "");
    const created = text($(".css-lz5fzu em, [class~='e143sozh0'] em", post)?.textContent || "");
    return normalizeLivePostKey(`${profileMatch?.[1] || author}\n${created}`);
  }

  function getLivePostIdentityFromData(post) {
    if (!post) return "";
    return normalizeLivePostKey(`${text(post.user?.id || post.user?.nickname || "")}\n${formatLiveDate(post.created)}`);
  }

  function maybeClearSubmittedDraft(posts = []) {
    const draft = readDraft();
    const submittedValue = state.draftSubmittedValue || draft?.value || "";
    if (!submittedValue.trim()) return;
    const submittedAt = state.draftSubmittedAt || draft?.savedAt || 0;
    const submitted = posts.some((post) => isPendingSubmittedPost(post, submittedValue, submittedAt));
    if (submitted) resetWriterAfterConfirmedPost(submittedValue);
  }

  function isPendingSubmittedPost(post, submittedValue = state.draftSubmittedValue, savedAt = state.draftSubmittedAt || state.draftSavedAt) {
    const contentKey = normalizeLivePostKey(encodedPostValue(submittedValue));
    if (!post || !contentKey || normalizeLivePostKey(post.content) !== contentKey) return false;
    const ownerEntryUserId = draftOwnerId();
    if (ownerEntryUserId && text(post.user?.id).trim() !== ownerEntryUserId) return false;
    const createdAt = Date.parse(text(post.created));
    return !Number.isFinite(createdAt) || !savedAt || createdAt >= savedAt - 120000;
  }

  function isPendingSubmittedRow(row, submittedValue = state.draftSubmittedValue) {
    if (!(row instanceof Element) || !submittedValue.trim() || Date.now() >= state.draftSubmitPendingUntil) return false;
    const body = $(BODY_SELECTOR, row);
    const content = normalizeLivePostKey(postBodySource(body));
    const expected = normalizeLivePostKey(encodedPostValue(submittedValue));
    if (!content || !expected || content !== expected) return false;
    const profileLink = $(".css-lz5fzu a[href^='/profile/'], [class~='e143sozh0'] a[href^='/profile/']", row);
    const profileId = text(profileLink?.getAttribute("href") || "").match(/^\/profile\/([a-f0-9]{24})/i)?.[1] || "";
    const ownerEntryUserId = draftOwnerId();
    return !ownerEntryUserId || !profileId || profileId === ownerEntryUserId;
  }

  function resetWriterAfterConfirmedPost(expectedValue = "") {
    const writer = getWriter();
    const currentValue = text(writer?.value);
    const expected = normalizeLivePostKey(encodedPostValue(expectedValue));
    const current = normalizeLivePostKey(encodedPostValue(currentValue));
    const shouldResetWriter = !currentValue.trim() || !expected || current === expected;
    const runtimeDraftMatchesExpected = expected
      && normalizeLivePostKey(encodedPostValue(state.draftValue)) === expected;
    clearDraftSubmitPending();
    if (!shouldResetWriter) {
      if (runtimeDraftMatchesExpected) discardStoredDraft();
      saveDraft(writer);
      clearDraftRestoreEffects();
      return true;
    }
    if (writer && !writer.closest(".entry-chat-root")) {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
      if (setter) setter.call(writer, "");
      else writer.value = "";
      writer.dispatchEvent(new Event("input", { bubbles: true }));
      writer.dispatchEvent(new Event("change", { bubbles: true }));
      delete writer.dataset.entryLlnkDraftRestored;
      updateCounter(writer);
      scheduleWriterPreview(0);
    }
    discardStoredDraft();
    clearDraftRestoreEffects();
    removeImageAttachment(null);
    return true;
  }

  function getLiveRows(list = getList()) {
    return list ? [...list.children].filter((element) => element.matches?.(POST_SELECTOR)) : [];
  }

  function snapshotLiveRowPositions(list = getList()) {
    state.liveRowPositions = new Map(getLiveRows(list).map((row) => [row, row.offsetTop]));
  }

  function captureNativeArrivalScrollAnchor(list = getList()) {
    state.nativeArrivalScrollAnchor = null;
    const lockScroll = isStoryToolbarMenuOpen();
    if (!list || (!lockScroll && window.scrollY <= 80)) return;
    const row = getLiveRows(list).find((candidate) => {
      const rect = candidate.getBoundingClientRect();
      return rect.bottom > 0 && rect.top < window.innerHeight;
    });
    if (!row && !lockScroll) return;
    state.nativeArrivalScrollAnchor = {
      row,
      top: row?.getBoundingClientRect().top || 0,
      scrollX: window.scrollX,
      scrollY: window.scrollY,
      lockScroll,
      expiresAt: performance.now() + 4000,
    };
  }

  function restoreNativeArrivalScrollAnchor(consume = false) {
    const anchor = state.nativeArrivalScrollAnchor;
    if (!anchor) return false;
    if (performance.now() > anchor.expiresAt) {
      state.nativeArrivalScrollAnchor = null;
      return false;
    }
    if (anchor.lockScroll) {
      window.scrollTo({ top: anchor.scrollY, left: anchor.scrollX, behavior: "instant" });
      if (consume) state.nativeArrivalScrollAnchor = null;
      return true;
    }
    if (!anchor.row?.isConnected || window.scrollY <= 80) {
      state.nativeArrivalScrollAnchor = null;
      return false;
    }
    const delta = anchor.row.getBoundingClientRect().top - anchor.top;
    if (Math.abs(delta) > 0.5) {
      window.scrollTo({
        top: window.scrollY + delta,
        left: window.scrollX,
        behavior: "instant",
      });
    }
    if (consume) state.nativeArrivalScrollAnchor = null;
    return true;
  }

  function animateExistingRowsForInsertion(rows = [], list = getList()) {
    const inserted = new Set(rows.filter((row) => !state.liveRowPositions.has(row)));
    if (!inserted.size || !state.liveRowPositions.size) {
      snapshotLiveRowPositions(list);
      return;
    }
    const viewportStabilized = restoreNativeArrivalScrollAnchor(true);
    if (!viewportStabilized && !window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
      getLiveRows(list).forEach((row) => {
        if (inserted.has(row) || row.classList.contains("entry-llnk-live-post-arriving")) return;
        const previousTop = state.liveRowPositions.get(row);
        if (!Number.isFinite(previousTop)) return;
        const offset = previousTop - row.offsetTop;
        if (Math.abs(offset) < 1) return;
        row.animate(
          [{ transform: `translate3d(0, ${offset}px, 0)` }, { transform: "translate3d(0, 0, 0)" }],
          { duration: 240, easing: "cubic-bezier(0.22, 1, 0.36, 1)" }
        );
      });
    }
    snapshotLiveRowPositions(list);
  }

  function animateExistingRowsAfterRemoval(list = getList()) {
    if (!state.nativeRemovalPending || !state.liveRowPositions.size) return;
    state.nativeRemovalPending = false;
    if (!window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
      getLiveRows(list).forEach((row) => {
        const previousTop = state.liveRowPositions.get(row);
        if (!Number.isFinite(previousTop)) return;
        const offset = previousTop - row.offsetTop;
        if (Math.abs(offset) < 1) return;
        row.style.setProperty("--entry-llnk-removal-shift", `${offset}px`);
        row.classList.remove("is-moving-after-removal");
        row.classList.add("entry-llnk-moving-after-removal");
        void row.offsetHeight;
        window.requestAnimationFrame(() => {
          if (!row.isConnected) return;
          row.classList.add("is-moving-after-removal");
          window.setTimeout(() => {
            row.classList.remove("entry-llnk-moving-after-removal", "is-moving-after-removal");
            row.style.removeProperty("--entry-llnk-removal-shift");
          }, 280);
        });
      });
    }
  }

  function bindLiveRows(list, posts) {
    const rows = getLiveRows(list).filter((row) => !row.dataset.entryChatLivePostId);
    const postsByKey = new Map();
    posts.forEach((post) => {
      const key = getLivePostKeyFromData(post);
      if (!key) return;
      if (!postsByKey.has(key)) postsByKey.set(key, []);
      postsByKey.get(key).push(post);
    });
    rows.forEach((row) => {
      const matches = postsByKey.get(getLivePostKeyFromElement(row)) || [];
      if (matches.length !== 1) return;
      const id = text(matches[0]?.id || "").trim();
      if (id) row.dataset.entryChatLivePostId = id;
    });
    openPendingLiveReply(list);
  }

  function primeNativeLivePostArrival(detail = {}) {
    const incomingPosts = parseNativeLivePosts(detail);
    if (
      incomingPosts.length
      && Date.now() < state.draftSubmitPendingUntil
      && text(state.draftSubmittedValue).trim()
    ) maybeClearSubmittedDraft(incomingPosts);
    const count = Math.max(0, Number(detail.count) || (Array.isArray(detail.ids) ? detail.ids.length : 0));
    if (count) {
      snapshotLiveRowPositions();
      captureNativeArrivalScrollAnchor();
    }
    getLiveRows().forEach((row) => {
      row.dataset.entryLlnkArrivalDelivered = "1";
    });
    if (!count || window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
      state.nativeArrivalPending = 0;
      return;
    }
    state.nativeArrivalPending = count;
    state.nativeArrivalSequence = 0;
    state.nativeArrivalExpiresAt = performance.now() + 2000;
  }

  function playLivePostArrivalDelivery(row, delay = 0, showShip = true) {
    void showShip;
    if (!row?.isConnected || isStoryPostFiltered(row)) return;
    const reducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    let animation = null;
    let finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      animation?.cancel();
      row.classList.remove("entry-llnk-live-post-arriving");
      row.style.removeProperty("--entry-llnk-live-arrival-delay");
      row.style.removeProperty("opacity");
      state.liveArrivalCleanups.delete(finish);
    };
    if (reducedMotion) {
      finish();
      return;
    }
    state.liveArrivalCleanups.add(finish);
    row.classList.add("entry-llnk-live-post-arriving");
    animation = row.animate(
      [{ opacity: 0 }, { opacity: 1 }],
      {
        duration: 220,
        delay: Math.max(0, Number(delay) || 0),
        easing: "cubic-bezier(.2, .8, .2, 1)",
        fill: "both",
      }
    );
    animation.id = "entry-llnk-live-arrival";
    animation.finished.then(finish, finish);
  }

  function findLiveRowForPost(id, post = null, list = getList()) {
    const postId = text(id).trim();
    const postKey = getLivePostKeyFromData(post);
    const postIdentity = getLivePostIdentityFromData(post);
    return (postId && list?.querySelector?.(`[data-entry-chat-live-post-id="${CSS.escape(postId)}"]`))
      || getLiveRows(list).find((candidate) => postKey && getLivePostKeyFromElement(candidate) === postKey)
      || getLiveRows(list).find((candidate) => postIdentity && getLivePostIdentityFromElement(candidate) === postIdentity)
      || null;
  }

  function releaseLivePostUpdateLayout(row) {
    const layout = state.liveUpdateLayouts.get(row);
    if (!layout) return;
    window.clearTimeout(layout.cleanupTimer);
    const body = layout.body;
    if (body?.isConnected) {
      body.style.height = layout.height;
      body.style.overflow = layout.overflow;
      body.style.transition = layout.transition;
      body.style.willChange = layout.willChange;
    }
    state.liveUpdateLayouts.delete(row);
  }

  function freezeLivePostUpdateLayout(row, body, height) {
    releaseLivePostUpdateLayout(row);
    const layout = {
      body,
      oldHeight: height,
      height: body.style.height,
      overflow: body.style.overflow,
      transition: body.style.transition,
      willChange: body.style.willChange,
      cleanupTimer: 0,
    };
    body.style.transition = "none";
    body.style.height = `${height}px`;
    body.style.overflow = "hidden";
    body.style.willChange = "height, opacity, filter, transform";
    state.liveUpdateLayouts.set(row, layout);
    return layout;
  }

  function resizeLivePostUpdateLayout(row) {
    const layout = state.liveUpdateLayouts.get(row);
    if (!layout) return;
    const body = $(BODY_SELECTOR, row);
    if (!body) return;
    if (body !== layout.body) {
      if (layout.body?.isConnected) {
        layout.body.style.height = layout.height;
        layout.body.style.overflow = layout.overflow;
        layout.body.style.transition = layout.transition;
        layout.body.style.willChange = layout.willChange;
      }
      layout.body = body;
      layout.height = body.style.height;
      layout.overflow = body.style.overflow;
      layout.transition = body.style.transition;
      layout.willChange = body.style.willChange;
    }
    body.style.transition = "none";
    body.style.height = "auto";
    body.style.overflow = "hidden";
    const targetHeight = body.getBoundingClientRect().height;
    body.style.height = `${layout.oldHeight}px`;
    body.style.willChange = "height, opacity, filter, transform";
    void body.offsetHeight;
    body.style.transition = "height 680ms cubic-bezier(0.22, 1, 0.36, 1)";
    window.requestAnimationFrame(() => {
      if (body.isConnected) body.style.height = `${targetHeight}px`;
    });
    layout.cleanupTimer = window.setTimeout(() => releaseLivePostUpdateLayout(row), 760);
  }

  function playLivePostUpdateRestore(row, delay = 0) {
    if (!row?.isConnected || isStoryPostFiltered(row) || !spaceshipMotionAllowed() || window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;
    const body = $(BODY_SELECTOR, row);
    if (!body) return;
    const shipUrl = getExtensionUrl("assets/draft-restore/entrybot-spaceship-1.svg");
    if (!shipUrl) return;
    const flight = document.createElement("span");
    flight.className = "entry-llnk-live-post-flight entry-llnk-live-post-flight-updating";
    flight.dataset.entryLlnkOwned = "1";
    flight.setAttribute("aria-hidden", "true");
    const frame = document.createElement("img");
    frame.src = shipUrl;
    frame.alt = "";
    frame.draggable = false;
    flight.appendChild(frame);
    const beam = document.createElement("span");
    beam.className = "entry-llnk-live-post-flight-beam";
    flight.appendChild(beam);
    const updateField = document.createElement("span");
    updateField.className = "entry-llnk-live-post-update-field";
    updateField.dataset.entryLlnkOwned = "1";
    updateField.setAttribute("aria-hidden", "true");
    document.body.appendChild(flight);
    document.body.appendChild(updateField);
    row.classList.remove("is-restoring-live-update");
    row.classList.add("entry-llnk-live-post-updating");

    const bodyRect = body.getBoundingClientRect();
    freezeLivePostUpdateLayout(row, body, bodyRect.height);
    let trackedLeft = bodyRect.left;
    let trackedTop = bodyRect.top + window.scrollY;
    let trackedWidth = bodyRect.width;
    let trackedHeight = bodyRect.height;
    const outsideX = window.innerWidth + 150;
    const duration = 2200;
    const startsAt = performance.now() + Math.max(0, Number(delay) || 0);
    let animationFrame = 0;
    let finished = false;
    const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
    const mix = (start, end, amount) => start + (end - start) * amount;
    const smooth = (value) => value * value * (3 - 2 * value);
    const finish = () => {
      if (finished) return;
      finished = true;
      window.cancelAnimationFrame(animationFrame);
      row.classList.remove("entry-llnk-live-post-updating", "is-restoring-live-update");
      releaseLivePostUpdateLayout(row);
      flight.remove();
      updateField.remove();
      state.liveArrivalCleanups.delete(finish);
    };
    state.liveArrivalCleanups.add(finish);
    const renderFrame = (now) => {
      if (!row.isConnected) {
        finish();
        return;
      }
      if (now < startsAt) {
        animationFrame = window.requestAnimationFrame(renderFrame);
        return;
      }
      const progress = clamp((now - startsAt) / duration, 0, 1);
      const activeBody = $(BODY_SELECTOR, row);
      if (activeBody) {
        const activeRect = activeBody.getBoundingClientRect();
        trackedLeft = mix(trackedLeft, activeRect.left, 0.2);
        trackedTop = mix(trackedTop, activeRect.top + window.scrollY, 0.2);
        trackedWidth = mix(trackedWidth, activeRect.width, 0.2);
        trackedHeight = mix(trackedHeight, activeRect.height, 0.2);
      }
      const bodyTop = trackedTop - window.scrollY;
      const hoverX = trackedLeft + trackedWidth * 0.5 - 37;
      let shipX = hoverX;
      let shipY = bodyTop - 94;
      let shipScale = 0.74;
      let shipRotate = -6;
      let shipOpacity = 1;
      let beamOpacity = 0;
      if (progress < 0.28) {
        const local = smooth(progress / 0.28);
        shipX = mix(outsideX, hoverX, local);
        shipY += mix(-48, 0, local) - Math.sin(local * Math.PI) * 11;
        shipScale = mix(1.32, 0.74, local);
        shipRotate = mix(22, -6, local);
        shipOpacity = clamp(local / 0.16, 0, 1);
        beamOpacity = 0;
      } else if (progress < 0.76) {
        const local = (progress - 0.28) / 0.48;
        shipX = hoverX + Math.sin(local * Math.PI * 2) * 5;
        shipY -= Math.sin(local * Math.PI * 3) * 4;
        shipScale = 0.74 + Math.sin(local * Math.PI * 2) * 0.018;
        shipRotate = -6 + Math.sin(local * Math.PI * 2) * 1.8;
        beamOpacity = 0.94 * clamp(local / 0.1, 0, 1) * clamp((1 - local) / 0.12, 0, 1);
      } else {
        const local = smooth((progress - 0.76) / 0.24);
        shipX = mix(hoverX, outsideX, local);
        shipY += mix(0, -78, local) - Math.sin(local * Math.PI) * 11;
        shipScale = mix(0.74, 1.34, local);
        shipRotate = mix(-6, 24, local);
        shipOpacity = local > 0.7 ? clamp((1 - local) / 0.3, 0, 1) : 1;
        beamOpacity = 0;
      }
      beam.style.width = `${Math.max(170, trackedWidth + 34)}px`;
      beam.style.height = `${Math.max(46, trackedHeight + 48)}px`;
      beam.style.opacity = String(beamOpacity);
      beam.style.left = `calc(50% + ${-Math.sin(shipRotate * Math.PI / 180) * 16}px)`;
      updateField.style.left = `${trackedLeft - 12}px`;
      updateField.style.top = `${bodyTop - 10}px`;
      updateField.style.width = `${trackedWidth + 24}px`;
      updateField.style.height = `${trackedHeight + 20}px`;
      updateField.style.opacity = String(beamOpacity * 0.78);
      updateField.style.filter = `brightness(${Math.round(progress * 18) % 2 ? 1.06 : 0.98})`;
      flight.style.opacity = String(shipOpacity);
      flight.style.transform = `translate3d(${shipX}px, ${shipY}px, 0) scale(${shipScale})`;
      frame.style.transform = `rotateZ(${shipRotate}deg)`;
      if (progress >= 1) {
        finish();
        return;
      }
      animationFrame = window.requestAnimationFrame(renderFrame);
    };
    animationFrame = window.requestAnimationFrame(renderFrame);
  }

  function parseNativeLivePosts(detail = {}) {
    try {
      const posts = JSON.parse(text(detail.postsJson || "[]"));
      return Array.isArray(posts) ? posts : [];
    } catch {
      return [];
    }
  }

  function primeNativeLivePostUpdate(detail = {}) {
    const ids = Array.isArray(detail.ids) ? detail.ids.map((id) => text(id).trim()).filter(Boolean) : [];
    if (!ids.length || !spaceshipMotionAllowed() || window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;
    const posts = parseNativeLivePosts(detail);
    const list = getList();
    ids.forEach((id, index) => {
      const post = posts.find((item) => text(item?.id) === id);
      const row = findLiveRowForPost(id, post, list);
      if (row && !row.dataset.entryChatLivePostId) row.dataset.entryChatLivePostId = id;
      if (row) playLivePostUpdateRestore(row, Math.min(index * 45, 135));
    });
  }

  function completeNativeLivePostUpdate(detail = {}) {
    const ids = Array.isArray(detail.ids) ? detail.ids.map((id) => text(id).trim()).filter(Boolean) : [];
    if (!ids.length || !spaceshipMotionAllowed() || window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;
    const posts = parseNativeLivePosts(detail);
    window.requestAnimationFrame(() => {
      ids.forEach((id) => {
        const post = posts.find((item) => text(item?.id) === id);
        const row = findLiveRowForPost(id, post);
        if (!row) return;
        resizeLivePostUpdateLayout(row);
        row.classList.remove("is-restoring-live-update");
        void row.offsetHeight;
        row.classList.add("is-restoring-live-update");
      });
    });
  }

  function playLivePostRemovalPickup(row, delay = 0) {
    if (!row?.isConnected || isStoryPostFiltered(row) || !spaceshipMotionAllowed() || window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;
    const shipUrl = getExtensionUrl("assets/draft-restore/entrybot-spaceship-1.svg");
    if (!shipUrl) return;
    const flight = document.createElement("span");
    flight.className = "entry-llnk-live-post-flight entry-llnk-live-post-flight-removing";
    flight.dataset.entryLlnkOwned = "1";
    flight.setAttribute("aria-hidden", "true");
    const frame = document.createElement("img");
    frame.src = shipUrl;
    frame.alt = "";
    frame.draggable = false;
    flight.appendChild(frame);
    const beam = document.createElement("span");
    beam.className = "entry-llnk-live-post-flight-beam";
    flight.appendChild(beam);

    const initialRect = row.getBoundingClientRect();
    const targetDocumentTop = initialRect.top + window.scrollY;
    const targetLeft = initialRect.left;
    const targetWidth = initialRect.width;
    const initialShipX = window.innerWidth + 110;
    const initialShipY = initialRect.top - 89;
    flight.style.opacity = "0";
    flight.style.transform = `translate3d(${initialShipX}px, ${initialShipY}px, 0) rotateZ(14deg) scale(1.08)`;
    flight.style.visibility = "hidden";
    document.body.appendChild(flight);
    const duration = 900;
    const startsAt = performance.now() + Math.max(0, Number(delay) || 0);
    let animationFrame = 0;
    let finished = false;
    const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
    const mix = (start, end, amount) => start + (end - start) * amount;
    const finish = (keepHidden = false) => {
      if (finished) return;
      finished = true;
      window.cancelAnimationFrame(animationFrame);
      if (!keepHidden) {
        row.style.removeProperty("opacity");
        row.style.removeProperty("transform");
      }
      flight.style.visibility = "hidden";
      flight.remove();
      state.liveArrivalCleanups.delete(finish);
    };
    state.liveArrivalCleanups.add(finish);
    const renderFrame = (now) => {
      if (!row.isConnected) {
        finish();
        return;
      }
      if (now < startsAt) {
        animationFrame = window.requestAnimationFrame(renderFrame);
        return;
      }
      const progress = clamp((now - startsAt) / duration, 0, 1);
      const targetTop = targetDocumentTop - window.scrollY;
      const approach = clamp(progress / 0.3, 0, 1);
      const approachEased = 1 - (1 - approach) ** 3;
      const carry = clamp((progress - 0.3) / 0.7, 0, 1);
      const carryEased = carry ** 3;
      const centerX = targetLeft + targetWidth * 0.5 - 37;
      const cardX = mix(0, -Math.max(390, targetLeft + targetWidth + 130), carryEased);
      const cardY = -Math.sin(Math.min(1, carry / 0.72) * Math.PI * 0.5) * 22 - carryEased * 28;
      const cardScale = mix(1, 0.965, carryEased);
      const cardOpacity = 1 - clamp((carry - 0.78) / 0.22, 0, 1);
      const approachX = mix(initialShipX, centerX, approachEased);
      const carryBlend = clamp((progress - 0.28) / 0.08, 0, 1);
      const shipX = mix(approachX, centerX + cardX, carryBlend);
      const shipY = targetTop - 89 + cardY - Math.sin(progress * Math.PI) * 7;
      const shipScale = mix(1.08, 0.72, approachEased) + carryEased * 0.3;
      const shipRotate = mix(14, -5, approachEased) - carryEased * 14;
      row.style.opacity = String(cardOpacity);
      row.style.transform = `translate3d(${cardX}px, ${cardY}px, 0) scale(${cardScale})`;
      beam.style.height = `${Math.max(34, targetTop - (shipY + 57))}px`;
      beam.style.opacity = String(clamp((progress - 0.12) / 0.14, 0, 1) * clamp((0.84 - progress) / 0.18, 0, 1));
      flight.style.opacity = String(clamp(progress / 0.06, 0, 1) * clamp((1 - progress) / 0.12, 0, 1));
      flight.style.visibility = "visible";
      flight.style.transform = `translate3d(${shipX}px, ${shipY}px, 0) rotateZ(${shipRotate}deg) scale(${shipScale})`;
      if (progress >= 1) {
        row.style.opacity = "0";
        flight.style.visibility = "hidden";
        finish(true);
        return;
      }
      animationFrame = window.requestAnimationFrame(renderFrame);
    };
    animationFrame = window.requestAnimationFrame(renderFrame);
  }

  function primeNativeLivePostRemoval(detail = {}) {
    const ids = Array.isArray(detail.ids) ? detail.ids.map((id) => text(id).trim()).filter(Boolean) : [];
    if (!ids.length) return;
    let posts = [];
    try {
      posts = JSON.parse(text(detail.postsJson || "[]"));
    } catch {
      posts = [];
    }
    snapshotLiveRowPositions();
    state.nativeRemovalPending = true;
    if (!spaceshipMotionAllowed() || window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;
    const list = getList();
    ids.forEach((id, index) => {
      const post = posts.find((item) => text(item?.id) === id);
      const postKey = getLivePostKeyFromData(post);
      const postIdentity = getLivePostIdentityFromData(post);
      const row = list?.querySelector?.(`[data-entry-chat-live-post-id="${CSS.escape(id)}"]`)
        || getLiveRows(list).find((candidate) => postKey && getLivePostKeyFromElement(candidate) === postKey)
        || getLiveRows(list).find((candidate) => postIdentity && getLivePostIdentityFromElement(candidate) === postIdentity);
      if (row && !row.dataset.entryChatLivePostId) row.dataset.entryChatLivePostId = id;
      if (row) playLivePostRemovalPickup(row, Math.min(index * 50, 150));
    });
  }

  function animatePendingNativeRows(node) {
    if (state.nativeArrivalPending && performance.now() > state.nativeArrivalExpiresAt) {
      state.nativeArrivalPending = 0;
    }
    const rows = [];
    if (node instanceof Element) {
      if (node.matches(POST_SELECTOR)) rows.push(node);
      node.querySelectorAll?.(POST_SELECTOR).forEach((row) => rows.push(row));
    }
    const uniqueRows = [...new Set(rows)];
    animateExistingRowsForInsertion(uniqueRows.filter((row) => !isStoryPostFiltered(row)));
    uniqueRows.forEach((row) => {
      if (row.dataset.entryLlnkArrivalDelivered === "1") return;
      const submittedValue = text(state.draftSubmittedValue);
      const isSubmittedRow = isPendingSubmittedRow(row, submittedValue);
      if (isStoryPostFiltered(row)) {
        if (state.nativeArrivalPending) {
          state.nativeArrivalPending -= 1;
        }
        if (isSubmittedRow) resetWriterAfterConfirmedPost(submittedValue);
        row.dataset.entryLlnkArrivalDelivered = "1";
        return;
      }
      let sequence = 0;
      if (isSubmittedRow) {
        if (state.nativeArrivalPending) {
          sequence = state.nativeArrivalSequence;
          state.nativeArrivalSequence += 1;
          state.nativeArrivalPending -= 1;
        }
        resetWriterAfterConfirmedPost(submittedValue);
        row.dataset.entryLlnkArrivalDelivered = "1";
        playLivePostArrivalDelivery(row, Math.min(sequence * 24, 72), false);
        return;
      }
      if (row.classList.contains("entry-llnk-live-post-arriving")) return;
      if (state.nativeArrivalPending) {
        sequence = state.nativeArrivalSequence;
        state.nativeArrivalSequence += 1;
        state.nativeArrivalPending -= 1;
      }
      row.dataset.entryLlnkArrivalDelivered = "1";
      playLivePostArrivalDelivery(row, Math.min(sequence * 24, 72), false);
    });
  }

  function reconcileLiveRows(list = getList(), posts = []) {
    if (!list) return 0;
    const rows = getLiveRows(list);
    const liveRows = rows.filter((row) => row.classList.contains("entry-chat-live-entry-story-post"));
    const nativeRows = rows.filter((row) => !row.classList.contains("entry-chat-live-entry-story-post"));
    if (!liveRows.length && !posts.length) return 0;

    const queueBy = (items, keyFor) => {
      const map = new Map();
      items.forEach((item) => {
        const key = keyFor(item);
        if (!key) return;
        if (!map.has(key)) map.set(key, []);
        map.get(key).push(item);
      });
      return map;
    };
    const nativeById = queueBy(nativeRows, (row) => text(row.dataset.entryChatLivePostId || ""));
    const unboundNativeByKey = queueBy(
      nativeRows.filter((row) => !row.dataset.entryChatLivePostId),
      getLivePostKeyFromElement
    );
    const liveById = queueBy(liveRows, (row) => text(row.dataset.entryChatLivePostId || ""));
    const liveByKey = queueBy(liveRows, getLivePostKeyFromElement);
    let removed = 0;

    const removeLiveRows = (items = []) => {
      items.forEach((row) => {
        if (!row?.isConnected) return;
        row.remove();
        removed += 1;
      });
    };

    posts.forEach((post) => {
      const id = text(post?.id || "").trim();
      if (!id) return;
      let nativeRow = (nativeById.get(id) || []).find((row) => row.isConnected) || null;
      if (!nativeRow) {
        const key = getLivePostKeyFromData(post);
        const candidates = unboundNativeByKey.get(key) || [];
        nativeRow = candidates.find((row) => row.isConnected && !row.dataset.entryChatLivePostId) || null;
      }
      if (nativeRow && !nativeRow.dataset.entryChatLivePostId) {
        nativeRow.dataset.entryChatLivePostId = id;
        if (!nativeById.has(id)) nativeById.set(id, []);
        nativeById.get(id).push(nativeRow);
      }
      if (nativeRow) {
        renderNativePostFromData(nativeRow, post);
        removeLiveRows(liveById.get(id) || []);
      }
    });

    nativeRows.forEach((nativeRow) => {
      if (!nativeRow.isConnected || nativeRow.dataset.entryChatLivePostId) return;
      const key = getLivePostKeyFromElement(nativeRow);
      if (!key) return;
      const keyMatches = (liveByKey.get(key) || []).filter((row) => row.isConnected);
      const liveRow = keyMatches.length === 1 ? keyMatches[0] : null;
      if (!liveRow) return;
      const id = text(liveRow.dataset.entryChatLivePostId || "").trim();
      if (id) nativeRow.dataset.entryChatLivePostId = id;
      removeLiveRows([liveRow]);
    });
    openPendingLiveReply(list);
    return removed;
  }

  function scheduleLiveDedupe() {
    if (state.liveDedupeQueued || !state.liveTopId) return;
    state.liveDedupeQueued = true;
    queueMicrotask(() => {
      state.liveDedupeQueued = false;
      if (!isEntryStoryListPage()) return;
      reconcileLiveRows(getList(), state.livePosts);
    });
  }

  function applyLivePosts(posts) {
    if (!posts.length || isStoryToolbarMenuOpen()) return;
    state.livePosts = posts;
    const pendingDraft = readDraft();
    const pendingValue = state.draftSubmittedValue || pendingDraft?.value || "";
    const pendingSavedAt = state.draftSubmittedAt || pendingDraft?.savedAt || 0;
    const locallySubmittedIds = new Set(
      posts
        .filter((post) => isPendingSubmittedPost(post, pendingValue, pendingSavedAt))
        .map((post) => text(post.id))
        .filter(Boolean)
    );
    maybeClearSubmittedDraft(posts);
    const list = getList();
    if (!list) return;
    if (!state.liveTopId) {
      bindLiveRows(list, posts);
      state.liveTopId = text(posts[0].id);
      return;
    }
    reconcileLiveRows(list, posts);
    posts.forEach((post) => {
      const id = text(post.id);
      const existing = id ? $(`[data-entry-chat-live-post-id="${CSS.escape(id)}"]`, list) : null;
      if (existing?.classList.contains("entry-chat-live-entry-story-post")) updateLivePostElement(existing, post);
    });
    const stopIndex = posts.findIndex((post) => text(post.id) === state.liveTopId);
    const fresh = (stopIndex >= 0 ? posts.slice(0, stopIndex) : posts.slice(0, 3))
      .filter((post) => !locallySubmittedIds.has(text(post.id)))
      .filter((post) => !$(`[data-entry-chat-live-post-id="${CSS.escape(text(post.id))}"]`, list));
    state.liveTopId = text(posts[0].id);
    const anchor = [...list.children].find((element) => element.matches?.(POST_SELECTOR) && element.getBoundingClientRect().bottom > 0) || null;
    const anchorTop = anchor?.getBoundingClientRect().top || 0;
    const insertedFresh = [];
    fresh.slice().reverse().forEach((post) => {
      const firstPost = [...list.children].find((element) => element.matches?.(POST_SELECTOR)) || null;
      const row = createLivePost(post);
      list.insertBefore(row, firstPost);
      insertedFresh.push(row);
    });
    reconcileLiveRows(list, posts);
    [...list.querySelectorAll(":scope > .entry-chat-live-entry-story-post")].slice(50).forEach((element) => element.remove());
    if (fresh.length && anchor && window.scrollY > 80) window.scrollBy(0, anchor.getBoundingClientRect().top - anchorTop);
    if (insertedFresh.some(isIndicatorEligibleStoryPost)) {
      const up = $(".entry-chat-entry-story-scroll-top[data-entry-llnk-owned='1']");
      updateNewPostIndicator(up);
    }
  }

  async function refreshLive() {
    if (!isLiveEntryStoryPage() || document.visibilityState === "hidden" || state.liveAbort) return;
    const controller = new AbortController();
    state.liveAbort = controller;
    try {
      applyLivePosts(await fetchLivePosts(controller.signal));
    } catch {
    } finally {
      if (state.liveAbort === controller) state.liveAbort = null;
    }
  }

  function startLiveRefresh() {
    stopLiveRefresh();
  }

  function stopLiveRefresh() {
    state.liveAbort?.abort();
    state.liveAbort = null;
    if (state.liveTimer) window.clearInterval(state.liveTimer);
    state.liveTimer = 0;
    state.liveTopId = "";
    state.livePosts = [];
    state.liveDedupeQueued = false;
  }

  function startObserver() {
    if (state.observer) return;
    const roots = new Set();
    const arrivalRoots = new Set();
    let flushQueued = false;
    let removalObserved = false;
    const flush = () => {
      flushQueued = false;
      if (!roots.size) return;
      const shouldAnimateRemoval = removalObserved;
      removalObserved = false;
      const pendingRoots = [...roots];
      const pendingArrivalRoots = [...arrivalRoots];
      roots.clear();
      arrivalRoots.clear();
      pendingRoots.forEach((root, index) => processRoot(root, { skipPageUi: index < pendingRoots.length - 1 }));
      pendingArrivalRoots.forEach(animatePendingNativeRows);
      scheduleLiveDedupe();
      if (shouldAnimateRemoval) animateExistingRowsAfterRemoval();
      snapshotLiveRowPositions();
      scheduleAutoMoreCheck(120);
    };
    const schedule = (mutations) => {
      let arrivalPostAdded = false;
      mutations.forEach((mutation) => {
        if (mutation.type === "characterData" && mutation.target.parentElement) roots.add(mutation.target.parentElement);
        mutation.addedNodes.forEach((node) => {
          if (node instanceof Element && (node.matches?.(POST_SELECTOR) || node.querySelector?.(POST_SELECTOR))) {
            arrivalPostAdded = true;
          }
          if (node instanceof Element) arrivalRoots.add(node);
          if (node instanceof Element) roots.add(node);
          else if (node.parentElement) roots.add(node.parentElement);
        });
        mutation.removedNodes.forEach((node) => {
          if (node instanceof Element && (node.matches?.(POST_SELECTOR) || node.querySelector?.(POST_SELECTOR))) {
            removalObserved = true;
            roots.add(mutation.target);
          }
        });
      });
      if (arrivalPostAdded) restoreNativeArrivalScrollAnchor();
      if (!roots.size || flushQueued) return;
      flushQueued = true;
      window.requestAnimationFrame(flush);
    };
    state.observer = new MutationObserver(schedule);
    state.observer.observe(document.body || document.documentElement, { childList: true, characterData: true, subtree: true });
  }

  async function init() {
    if (!isEntryStoryPage()) return;
    document.documentElement.dataset.entryLlnkActive = "1";
    document.documentElement.classList.add("entry-chat-page-entrystory", "entry-chat-image-spoiler-enabled");
    Ringcl.ensureIconFont?.();
    restoreDraftSubmitPending();
    processRoot(document);
    snapshotLiveRowPositions();
    startObserver();
    bindReplyFoldScrollStabilizer();
    startLiveRefresh();
    refreshDraftOwner(true).catch(() => {});
    Ringcl.storageGet(["entryLlnkSettings"]).then((saved) => {
      const settings = saved.entryLlnkSettings || {};
      state.pageSettings = normalizePageSettings(settings);
      state.storyFilters = normalizeStoryFilters(settings.storyFilters, settings.hidePromotions);
      state.autoMoreEnabled = settings.autoMore !== false;
      state.liveRefreshEnabled = settings.liveRefresh !== false;
      state.imageSpoilerEnabled = settings.imageSpoiler !== false;
      state.shortenProjectLinksEnabled = settings.shortenProjectLinks !== false;
      state.draftEnabled = settings.draft !== false;
      state.spaceshipMotionEnabled = state.pageSettings.spaceshipMotion === true;
      state.fallModeEnabled = state.pageSettings.fallMode === true;
      state.customModeLayout = normalizeCustomModeLayout(settings.customModeLayout);
      state.customModeDraftLayout = null;
      state.customModeEditing = false;
      if (!spaceshipMotionAllowed()) clearSpaceshipMotionEffects();
      document.documentElement.classList.toggle("entry-chat-image-spoiler-enabled", state.imageSpoilerEnabled);
      if (state.liveRefreshEnabled) startLiveRefresh();
      else stopLiveRefresh();
      if (state.autoMoreEnabled) startAutoMoreWatch();
      else stopAutoMoreWatch();
      processRoot(document);
      shortenProjectLinks(document);
      if (state.fallModeEnabled) syncFallMode();
    }).catch(() => {});
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll, { passive: true });
    const handleRouteChange = () => {
      window.requestAnimationFrame(() => processRoot(document));
    };
    window.addEventListener("entry-llnk-route-change", handleRouteChange);
    window.addEventListener("entry-llnk-native-posts-added", (event) => {
      window.requestAnimationFrame(() => {
        restoreNativeArrivalScrollAnchor();
        updateNewPostIndicatorForArrivals(event.detail || {});
      });
    });
    window.addEventListener("entry-llnk-native-posts-will-add", (event) => {
      primeNativeLivePostArrival(event.detail || {});
    });
    window.addEventListener("entry-llnk-native-posts-will-remove", (event) => {
      primeNativeLivePostRemoval(event.detail || {});
    });
    window.addEventListener("entry-llnk-native-posts-will-update", (event) => {
      primeNativeLivePostUpdate(event.detail || {});
    });
    window.addEventListener("entry-llnk-native-posts-updated", (event) => {
      completeNativeLivePostUpdate(event.detail || {});
    });
    window.addEventListener("focus", () => refreshDraftOwner(true).catch(() => {}));
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !changes.entryLlnkSettings) return;
      const next = changes.entryLlnkSettings.newValue || {};
      const wasFallModeEnabled = state.fallModeEnabled;
      state.pageSettings = normalizePageSettings(next);
      state.storyFilters = normalizeStoryFilters(next.storyFilters, next.hidePromotions);
      state.autoMoreEnabled = next.autoMore !== false;
      state.liveRefreshEnabled = next.liveRefresh !== false;
      state.imageSpoilerEnabled = next.imageSpoiler !== false;
      state.shortenProjectLinksEnabled = next.shortenProjectLinks !== false;
      state.draftEnabled = next.draft !== false;
      state.spaceshipMotionEnabled = state.pageSettings.spaceshipMotion === true;
      state.fallModeEnabled = state.pageSettings.fallMode === true;
      const incomingCustomModeLayout = normalizeCustomModeLayout(next.customModeLayout);
      if (!state.customModeEditing || !wasFallModeEnabled || !state.fallModeEnabled) {
        state.customModeLayout = incomingCustomModeLayout;
      }
      if (!spaceshipMotionAllowed()) clearSpaceshipMotionEffects();
      document.documentElement.classList.toggle("entry-chat-image-spoiler-enabled", state.imageSpoilerEnabled);
      if (state.liveRefreshEnabled) startLiveRefresh();
      else stopLiveRefresh();
      if (state.autoMoreEnabled) startAutoMoreWatch();
      else stopAutoMoreWatch();
      processRoot(document);
      shortenProjectLinks(document);
      if (!state.fallModeEnabled) removeFallModeStage();
      else if (!wasFallModeEnabled) {
        state.customModeDraftLayout = cloneCustomModeLayout(state.customModeLayout);
        state.customModeEditing = true;
        syncFallMode({ replay: true });
      }
      else applyCustomModeLayout();
    });
    startAutoMoreWatch();
    updateScrollUi();
    window.addEventListener("pagehide", () => {
      window.removeEventListener("entry-llnk-route-change", handleRouteChange);
      state.observer?.disconnect();
      state.draftObserver?.disconnect();
      state.lazyObserver?.disconnect();
      stopLiveRefresh();
      stopAutoMoreWatch();
      window.clearTimeout(state.writerPreviewTimer);
      window.clearTimeout(state.autoMoreReleaseTimer);
      window.clearTimeout(state.draftPersistTimer);
      if (state.draftGuardTimer) window.clearInterval(state.draftGuardTimer);
      state.draftGuardTimer = 0;
      if (state.draftValue.trim() && draftOwnerId()) {
        Ringcl.storageSet({
          [DRAFT_STORAGE_KEY]: {
            value: state.draftValue,
            savedAt: state.draftSavedAt || Date.now(),
            ownerEntryUserId: draftOwnerId(),
          },
        }).catch(() => {});
      }
      state.uploadCleanup?.();
      removeFallModeStage();
    }, { once: true });
  }

  init();
})();
